/*
 * OpenIMU300ZI.h
 * Copyright (c) 2020, ZHAW
 * All rights reserved.
 */

#ifndef OPEN_IMU_300_ZI_
#define OPEN_IMU_300_ZI_

#include <cstdlib>
#include <mbed.h>
#include <string>
#include <Callback.h>
#include <SPI.h>
#include "ThreadFlag.h"

#include "DebugOutput.h"


/**
 * This class implements a single wheel of the car. It's responsible to check the encoder in a good time interval
 */
class OpenIMU300ZI: public Thread{
    
    public:
                    OpenIMU300ZI(PinName mosi, PinName miso, PinName sclk, PinName ssel, DigitalOut &reset, string name, DebugOutput * debugSerial = nullptr);
        virtual     ~OpenIMU300ZI();

        void        switchOn();
        void        switchOff();
        bool        isOperational();

        bool        getPositionValues(double &xPosition, double &yPosition, double &zPosition);
        bool        getEulerAngles(double &roll, double &pitch, double &yaw);
        bool        getVelocityValues(double &xVelocity, double &yVelocity, double &zVelocity);
        bool        getAngularVelocityValues(double &xAngularRate, double &yAngularRate, double &zAngularRate);
        double      getYaw();
        double      getRoll();
        double      getPitch();
        double      getAngularVelocityX();
        double      getAngularVelocityY();
        double      getAngularVelocityZ();
        double      getAccelerationX();
        double      getAccelerationY();
        double      getAccelerationZ();

        bool        forcePositionValues(double xPosition, double yPosition, double zPosition);
        bool        forceVelocityValues(double xVelocity, double yVelocity, double zVelocity);       
        void        resetEuler();
        void        resetYaw();

        void        resetAllValues();

        string      getStateString();
                    
        
    private:
        static const int32_t    SPI_FREQUENCY = 1000000;
        static const int16_t    UPDATE_CYCLE_DATA = 5; //Updatecycle for the data in [ms]
        static constexpr double DEG_TO_RAD = 0.017453293; //Factor to change from deg to rad (PI/180)
        static constexpr double RAD_TO_DEG = 57.29577951; //Factor to change from rad to deg (180/PI)
        static constexpr double CONST_2_PI =  2.0 * 3.141592654;
        static constexpr float  PERIOD = 0.005;

        enum State {
            STATE_OFF = 0,
            STATE_INIT = 1,
            STATE_OPERATIONAL = 2,		
            STATE_FAULT = 3
        };

        enum RegisterMap : uint16_t { //Caution due to a firmware issue on OpenIMU300ZI only BURST_READ is implented, see the imu-firmware code
            X_RATE	            = 0X04,
            Y_RATE	            = 0X06,
            Z_RATE	            = 0X08,
            X_ACCEL	            = 0X0A,
            Y_ACCEL	            = 0X0C,
            Z_ACCEL	            = 0X0E,
            X_MAG	            = 0X10,
            Y_MAG	            = 0X12,
            Z_MAG	            = 0X14,
            BOARD_TEMP	        = 0X16,
            SENSOR_TEMP	        = 0X18,
            MAG_SCALE_FACTOR	= 0X32,
            DRDY_RATE	        = 0X37,
            ACCEL_LOW_PASS_FILTER = 0X38,
            BURST_READ_VG	    = 0X3D,
            BURST_READ	        = 0X3E,
            BURST_READ_MAG	    = 0X3F,
            ACEL_SCALE_FACTOR	= 0X46,
            RATE_SCALE_FACTOR	= 0X47,
            MAGX_HARD_IRON	    = 0X48,
            MAGY_HARD_IRON	    = 0X4A,
            MAG_SF_SOFT_IRON	= 0X4C,
            MAG_ANGLE_SOFT	    = 0X4E,
            MAG_ALIGN_COMMAND	= 0X50,
            MAG_ALIGN_STATUS	= 0X51,
            MASTER_STATUS	    = 0X5A,
            HW_STATUS	        = 0X5C,
            SW_STATUS	        = 0X5E,
            ACCEL_RANGE	        = 0X70,
            RATE_RANGE	        = 0X71,
            UNIT_ORIENTATION_MSB= 0X74,
            UNIT_ORIENTATION_LSB= 0X75,
            SAVE_CONFIGURATION  = 0X76,
            RATE__LOW_PASS_FILTER = 0X78,
            HW_VERSION	        = 0X7E,
            SW_VERSION	        = 0X7F
        };

        enum FilterOptions : uint8_t {
            UNFILTERED			= 0X00,
            BARTLETT_40_HZ		= 0X03,
            BARTLETT_20_HZ		= 0X04,
            BARTLETT_10_HZ		= 0X05,
            BARTLETT_5_HZ		= 0X06,
            BUTTERWORTH_50_HZ	= 0X30,
            BUTTERWORTH_20_HZ	= 0X40,
            BUTTERWORTH_10_HZ	= 0X50,
            BUTTERWORTH_5_HZ	= 0X60,
            BUTTERWORTH_40_HZ	= 0X90,
            BUTTERWORTH_25_HZ	= 0X80
        };

        enum UnitOrientation : uint16_t {
            MODE_NORMAL         = 0x0000,
            ALL_INVERTED        = 0x006B,
            CAR_MODELL_CORRECT  = 0x0023
            //Much more options are availaible, but we focus here on the most important ones (see data sheet for more information)
        };

        enum BitMasksMasterStatus : uint16_t { //If bit is set, error of given object occured
            MASTER_FAIL         = 0x01,
            HARDWARE_ERROR      = 0x02,
            SOFTWARE_ERROR      = 0x08,
            SENSOR_ERROR        = 0x1000
        };

        SPI       		spi;
        DebugOutput*         debugSerial;
        DigitalOut      slaveSelectLine;
        DigitalOut      resetIMU; //Active: low;
        string          name;
        DigitalOut      debugLed;
        int32_t         debugCount = 0;
        

        State           state;
        bool            entryState;
        bool            exitState;
        bool            switchOnSet;
        bool            switchOffSet;
        bool            isInitalized;

        //State of the imu-unit
        bool            masterFailSet;
        bool            hardwareErrorSet;
        bool            softwareErrorSet;
        bool            sensorStatusErrorSet;

        int16_t statusRaw;
        int16_t xRateRaw;
        int16_t yRateRaw;
        int16_t zRateRaw;
        int16_t xAccelerationValueRaw;
        int16_t yAccelerationValueRaw;
        int16_t zAccelerationValueRaw;
        int16_t unitTemperatureRaw;
        uint16_t rollRaw;
        uint16_t pitchRaw;
        uint16_t yawRaw;
        
        double xPositionActualValue; //in [m]
        double yPositionActualValue; //in [m]
        double zPositionActualValue; //in [m]

        double xVelocityActualValue; //in [m/s]
        double yVelocityActualValue; //in [m/s]
        double zVelocityActualValue; //in [m/s]
        double xVelocityLastValue; //in [m/s]
        double yVelocityLastValue; //in [m/s]
        double zVelocityLastValue; //in [m/s]

        double xAccelerationActualValue; //in [m/s^2]
        double yAccelerationActualValue; //in [m/s^2]
        double zAccelerationActualValue; //in [m/s^2]
        double xAccelerationLastValue; //in [m/s^2]
        double yAccelerationLastValue; //in [m/s^2]
        double zAccelerationLastValue; //in [m/s^2]

        double xRateActualValue; //in [rad/s]
        double yRateActualValue; //in [rad/s]
        double zRateActualValue; //in [rad/s]
        double xRateLastValue; //in [rad/s]
        double yRateLastValue; //in [rad/s]
        double zRateLastValue; //in [rad/s]


        double roll; //in [rad]
        double pitch; //in [rad]
        double yaw; //in [rad]
        double rollOffset; //offset of angle in [rad], used to reset angle during runtime
        double pitchOffset; //offset of angle in [rad], used to reset angle during runtime
        double yawOffset; //offset of angle in [rad], used to reset angle during runtime



        LowPowerTimer   timeOutTimer;
        LowPowerTimer   watchDogDataReceived;
        LowPowerTimer   debugTimer;
        Timer           stepWidthIntegrationTimer;


        int16_t readDataFromRegister (RegisterMap targetRegister);
        void    writeDataToRegister (RegisterMap targetRegister, uint8_t valueToWrite);
        void    burstRead();
        void    setUnitOrientation( UnitOrientation targetOrientation );
        void timeOut(int empty);
        double integrateTrapezoidal(double lastValue, double actualValue, double stepWidth);
        
        ThreadFlag          threadFlag;
        Thread              thread;
        Ticker              ticker;
        
        void                sendThreadFlag();
        void                run();
};

#endif /* OPEN_IMU_300_ZI_ */