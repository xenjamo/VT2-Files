/*
 * ADCUnit.h
 * Copyright (c) 2020, ZHAW
 * All rights reserved.
 */

#ifndef ADC_UNIT_H_
#define ADC_UNIT_H_

#include <cstdlib>
#include <mbed.h>
#include <string>
#include <Callback.h>

#include "iio/include/LowpassFilter.h"
#include "DebugOutput.h"



/**
 * This class implements a single wheel of the car. It's responsible to check the encoder in a good time interval
 */
class ADCUnit: public Thread{
    
    public:
        
                    ADCUnit(AnalogIn &motorCurrentSensor, AnalogIn &batteryVoltageSensor, AnalogIn &boardCurrentSensor, string name, DebugOutput * debugSerial = nullptr);
        virtual     ~ADCUnit();

        double     readMotorCurrentActuallValue();
        double     readBatteryVoltageActuallValue();
        double     readBoardCurrentActuallValue();
                    
        
    private:
        static const       int16_t  SAMPLE_PERIODE = 50; //ms

        static constexpr   double RESISTOR_VALUE_MOTOR_SHUNT = 0.02; //Ohm, resistance of shunt from inverter (to ground)
        static constexpr   double RESISTOR_VALUE_BOARD_SHUNT = 0.02; //Ohm, resistance of shunt from logic supply  (to ground)
        static const       int16_t HIGH_RESISTOR_VALUE_VOLTAGE_DEVIDER_BATTERY = 4300; //Ohm, see R19 and R16 in schematics of PCB
        static const       int16_t LOW_RESISTOR_VALUE_VOLTAGE_DEVIDER_BATTERY = 270; //Ohm, see R17 and R18 in schematics of PCB

        static constexpr   double FILTER_FREQUENCE_MOTOR_CURRENT = 300; //rad/s cut off frequency
        static constexpr   double FILTER_FREQUENCE_BOARD_CURRENT = 5; //rad/s cut off frequency
        static constexpr   double FILTER_FREQUENCE_BATTERY_VOLTAGE = 5; //rad/s cut off frequency

        LowpassFilter      motorCurrentSensorFiltered;
        LowpassFilter      boardCurrentSensorFiltered;
        LowpassFilter      batteryVoltageSensorFiltered;

        double             latestMotorCurrentSensorValueFiltered;
        double             latestBoardCurrentSensorValueFiltered;
        double             latestBatteryVoltageSensorValueFiltered;

        AnalogIn           motorCurrentSensor;
        AnalogIn           batteryVoltageSensor;
        AnalogIn           boardCurrentSensor;

        DebugOutput*       debugSerial;        
        string             name;
        

        void run ();
};

#endif /* ADC_UNIT_H_ */