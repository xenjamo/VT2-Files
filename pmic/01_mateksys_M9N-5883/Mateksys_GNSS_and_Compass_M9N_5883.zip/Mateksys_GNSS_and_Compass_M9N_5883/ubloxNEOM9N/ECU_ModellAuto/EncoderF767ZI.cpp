/*
 * EncoderCounter.cpp
 * Copyright (c) 2018, ZHAW
 * All rights reserved.
 */

#include "EncoderF767ZI.h"

using namespace std;

/**
 * Creates and initializes the driver to read the quadrature
 * encoder counter of the STM32 microcontroller.
 * @param a the input pin for the channel A.
 * @param b the input pin for the channel B.
 */
EncoderCounter::EncoderCounter(PinName a, PinName b) {
    
    if ((a == PE_9) && (b == PE_11)) {
        
        // pinmap OK for TIM2 CH1 and CH2
        
        TIM = TIM1;
        uint64_t mask = 0;
        
        // configure reset and clock control registers
        RCC->AHB1ENR |= RCC_AHB1ENR_GPIOEEN;    // manually enable port E (port A enabled by mbed library)
        
        // configure general purpose I/O registers
        GPIOE->MODER &= ~GPIO_MODER_MODER9;     // reset port E9
        GPIOE->MODER |= GPIO_MODER_MODER9_1;    // set alternate mode of port E9
        GPIOE->PUPDR &= ~GPIO_PUPDR_PUPDR9;     // reset pull-up/pull-down on port E9
        GPIOE->PUPDR |= GPIO_PUPDR_PUPDR9_1;    // set input as pull-down
        GPIOE->AFR[1] &= ~GPIO_AFRH_AFRH1;       //Reset alternate function of port E9
        GPIOE->AFR[1] |= GPIO_AFRH_AFRH1_0;      //Set alternate function 1 of port E9
  
        GPIOE->MODER &= ~GPIO_MODER_MODER11;     // reset port E11
        GPIOE->MODER |= GPIO_MODER_MODER11_1;    // set alternate mode of port E11
        GPIOE->PUPDR &= ~GPIO_PUPDR_PUPDR11;     // reset pull-up/pull-down on port E11
        GPIOE->PUPDR |= GPIO_PUPDR_PUPDR11_1;    // set input as pull-down
        GPIOE->AFR[1] &= ~GPIO_AFRH_AFRH3;       //Reset alternate function of port E11
        GPIOE->AFR[1] |= GPIO_AFRH_AFRH3_0;      //Set alternate function 1 of port E11

        
        // configure reset and clock control registers

        RCC->APB2RSTR |= RCC_APB2RSTR_TIM1RST;  //reset TIM1 controller
        RCC->APB2RSTR &= ~RCC_APB2RSTR_TIM1RST;
        RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;     // TIM1 clock enable
        
    } else if ((a == PC_6) && (b == PC_7)) {
        
        // pinmap OK for TIM8 CH1 and CH2
        
        TIM = TIM8;
        
        // configure reset and clock control registers
        RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;    // manually enable port C (port A enabled by mbed library)
       
        // configure general purpose I/O registers   
        GPIOC->MODER &= ~GPIO_MODER_MODER6;     // reset port C6
        GPIOC->MODER |= GPIO_MODER_MODER6_1;    // set alternate mode of port C6
        GPIOC->PUPDR &= ~GPIO_PUPDR_PUPDR6;     // reset pull-up/pull-down on port C6
        GPIOC->PUPDR |= GPIO_PUPDR_PUPDR6_1;    // set input as pull-down
        GPIOC->AFR[0] &= ~GPIO_AFRH_AFRH6;       //Reset alternate function of port C6
        GPIOC->AFR[0] |= GPIO_AFRH_AFRH6_0;      //Set alternate function 3 of port C6
        GPIOC->AFR[0] |= GPIO_AFRH_AFRH6_1;      //Set alternate function 3 of port C6
  
        GPIOC->MODER &= ~GPIO_MODER_MODER7;     // reset port C7
        GPIOC->MODER |= GPIO_MODER_MODER7_1;    // set alternate mode of port C7
        GPIOC->PUPDR &= ~GPIO_PUPDR_PUPDR7;     // reset pull-up/pull-down on port C7
        GPIOC->PUPDR |= GPIO_PUPDR_PUPDR7_1;    // set input as pull-down
        GPIOC->AFR[0] &= ~GPIO_AFRH_AFRH7;       //Reset alternate function of port C7
        GPIOC->AFR[0] |= GPIO_AFRH_AFRH7_0;      //Set alternate function 3 of port C7
        GPIOC->AFR[0] |= GPIO_AFRH_AFRH7_1;      //Set alternate function 3 of port C7
        
        // configure reset and clock control registers
        
        RCC->APB2RSTR |= RCC_APB2RSTR_TIM8RST;  //reset TIM3 controller
        RCC->APB2RSTR &= ~RCC_APB2RSTR_TIM8RST;
        
        RCC->APB2ENR |= RCC_APB2ENR_TIM8EN;     // TIM3 clock enable
        
    } else if ((a == PD_12) && (b == PD_13)) { 
        
        // pinmap OK for TIM4 CH1 and CH2
       
        TIM = TIM4;
        
        // configure reset and clock control registers
        
        RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;    // manually enable port B (port A enabled by mbed library)
        
        // configure general purpose I/O registers
        
        GPIOD->MODER &= ~GPIO_MODER_MODER12;     // reset port PD12
        GPIOD->MODER |= GPIO_MODER_MODER12_1;    // set alternate mode of port PD12
        GPIOD->PUPDR &= ~GPIO_PUPDR_PUPDR12;     // reset pull-up/pull-down on port PD12
        GPIOD->PUPDR |= GPIO_PUPDR_PUPDR12_1;    // set input as pull-down 
        GPIOD->AFR[1] &= ~GPIO_AFRH_AFRH4;       //Reset alternate function of port PD12
        GPIOD->AFR[1] |= GPIO_AFRH_AFRH4_1;      //Set alternate function 2 of port PD12
        
        GPIOD->MODER &= ~GPIO_MODER_MODER13;     // reset port PD13
        GPIOD->MODER |= GPIO_MODER_MODER13_1;    // set alternate mode of port PD13
        GPIOD->PUPDR &= ~GPIO_PUPDR_PUPDR13;     // reset pull-up/pull-down on port PD13
        GPIOD->PUPDR |= GPIO_PUPDR_PUPDR13_1;    // set input as pull-down
        GPIOD->AFR[1] &= ~GPIO_AFRH_AFRH5;       //Reset alternate function of port PD13
        GPIOD->AFR[1] |= GPIO_AFRH_AFRH5_1;      //Set alternate function 2 of port PD13
        
        // configure reset and clock control registers
        RCC->APB1RSTR |= RCC_APB1RSTR_TIM4RST;  //reset TIM4 controller
        RCC->APB1RSTR &= ~RCC_APB1RSTR_TIM4RST;   
        RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;     // TIM4 clock enable
        
    } else if ((a == PB_4) && (b == PB_5)) { 
        
        // pinmap OK for TIM5 CH1 and CH2
        
        TIM = TIM3;
        
        // configure reset and clock control registers 
        RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;    // manually enable port B
        
        // configure general purpose I/O registers
        
        GPIOB->MODER &= ~GPIO_MODER_MODER4;     // reset port B4
        GPIOB->MODER |= GPIO_MODER_MODER4_1;    // set alternate mode of port B4
        GPIOB->PUPDR &= ~GPIO_PUPDR_PUPDR4;     // reset pull-up/pull-down on port B4
        GPIOB->PUPDR |= GPIO_PUPDR_PUPDR4_1;    // set input as pull-down
        GPIOB->AFR[0] &= ~GPIO_AFRL_AFRL4;       //Reset alternate function of port B4
        GPIOB->AFR[0] |= GPIO_AFRL_AFRL4_1;      //Set alternate function 2 of port B4
        
        GPIOB->MODER &= ~GPIO_MODER_MODER5;     // reset port B5
        GPIOB->MODER |= GPIO_MODER_MODER5_1;    // set alternate mode of port B5
        GPIOB->PUPDR &= ~GPIO_PUPDR_PUPDR5;     // reset pull-up/pull-down on port B5
        GPIOB->PUPDR |= GPIO_PUPDR_PUPDR5_1;    // set input as pull-down
        GPIOB->AFR[0] &= ~GPIO_AFRL_AFRL5;       //Reset alternate function of port B5
        GPIOB->AFR[0] |= GPIO_AFRL_AFRL5_1;      //Set alternate function 2 of port B5
        
        // configure reset and clock control registers
        
        RCC->APB1RSTR |= RCC_APB1RSTR_TIM3RST;  //reset TIM3 controller
        RCC->APB1RSTR &= ~RCC_APB1RSTR_TIM3RST;
        
        RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;     // TIM3 clock enable
        
    } else {
        
        printf("pinmap not found for peripheral\n");
    }
    
    // configure general purpose timer

    TIM->PSC = 0;
    TIM->CR1 = 0x0000;          // counter disable
    TIM->CR2 = 0x0000;          // reset master mode selection


    TIM->SMCR = TIM_SMCR_SMS_1 | TIM_SMCR_SMS_0; // counting on both TI1 & TI2 edges  
    TIM->CCMR1 = TIM_CCMR1_CC2S_0 | TIM_CCMR1_CC1S_0;
    TIM->CCMR2 = 0x0000;        // reset capture mode register 2
    TIM->CCER = TIM_CCER_CC2E | TIM_CCER_CC1E;
    TIM->CCER &= ~TIM_CCER_CC1P;
    TIM->CCER &= ~TIM_CCER_CC1NP;
    TIM->CCER &= ~TIM_CCER_CC2P;
    TIM->CCER &= ~TIM_CCER_CC2NP;
    TIM->CNT = 0x0000;          // reset counter value
    TIM->ARR = 0xFFFF;          // auto reload register
    TIM->CR1 = TIM_CR1_CEN;     // counter enable

}

EncoderCounter::~EncoderCounter() {}


/**
 * Resets the counter value to zero.
 */
void EncoderCounter::reset() {
    
    TIM->CNT = 0x0000;
}

/**
 * Resets the counter value to a given offset value.
 * @param offset the offset value to reset the counter to.
 */
void EncoderCounter::reset(short offset) {
    
    TIM->CNT = -offset;
}

/**
 * Reads the quadrature encoder counter value.
 * @return the quadrature encoder counter as a signed 16-bit integer value.
 */
short EncoderCounter::read() {
    
    return (short)(-TIM->CNT);
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
EncoderCounter::operator short() {
    
    return read();
}




