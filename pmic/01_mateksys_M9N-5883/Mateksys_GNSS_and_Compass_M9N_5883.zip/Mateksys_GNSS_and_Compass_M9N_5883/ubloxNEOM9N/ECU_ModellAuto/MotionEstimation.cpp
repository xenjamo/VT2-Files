/*
 * MotionEstimation.cpp
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 05.05.2021
 *      Author: Nicolas Borla
 */

#include "MotionEstimation.h"
#include <cstdio>

using namespace std;


MotionEstimation::MotionEstimation(EncoderCounter &rearLeftCounter, EncoderCounter &rearRightCounter, 
                                    OpenIMU300ZI &imu, PX4Flow &px4flow, NEOM9N &neom9n,
                                    Servo &throttle, Servo &steering,
                                    int nData, float *Mes):
                                    rearLeftCounter(rearLeftCounter),rearRightCounter(rearRightCounter),
                                    imu(imu),px4flow(px4flow),neom9n(neom9n),
                                    throttle(throttle), steering(steering),
                                    thread(osPriorityRealtime, STACK_SIZE) {

    
     // initialize lowpass filter objects
    speedRearLeftFilter.setPeriod(PERIOD);
    speedRearLeftFilter.setFrequency(LOWPASS_FILTER_FREQUENCY);
    speedRearRightFilter.setPeriod(PERIOD);
    speedRearRightFilter.setFrequency(LOWPASS_FILTER_FREQUENCY);

    previousValueCounterRearLeft = rearLeftCounter.read();
    previousValueCounterRearRight = rearRightCounter.read();

    actualSpeedRearLeft = 0.0f;
    actualSpeedRearRight = 0.0f;

    // measurement variables
    startMeasure = false;
    measureIndex = 0;
    this->nData = nData;
    this->Mes = Mes;

    thread.start(callback(this, &MotionEstimation::run));
    ticker.attach(callback(this, &MotionEstimation::sendThreadFlag), PERIOD);
}

MotionEstimation::~MotionEstimation() {
    ticker.detach();
}

/**
 * This method is called by the ticker timer interrupt service routine.
 * It sends a flag to the thread to make it run again.
 */
void MotionEstimation::sendThreadFlag() {
    
    thread.flags_set(threadFlag);
}

void MotionEstimation::startMeasurement(){
    if(!startMeasure){
        fileIndex = 0;
        startMeasure = true;
        timer.reset();
        timer.start();
    }
}

void MotionEstimation::resetMeasurement(){
    measureSaved = false;
    startMeasure = false;
    measureIndex = 0;
    timer.reset();
};

void MotionEstimation::saveMeasurement(){
    /*
    if(!measureSaved){
        // save data to sd card
        printf("Write measurements\r\n");
        // name of the file with indexing number
        string filePath = "/fs/data";
        filePath.append(to_string(fileIndex));
        filePath.append(".csv");
        printf("filename: %s\r\n",filePath.c_str());
        // write data to file
        FILE* fp = fopen(filePath.c_str(), "w");                    
        for(int j=0; j<(nData-13); j=j+13) {
            fprintf(fp,"%.7f %.7f %.7f %.7f %.7f %.7f %.7f %.7f %.7f %.7f %.7f %.7f %.7f\r\n",*(Mes+j),*(Mes+j+1),*(Mes+j+2),*(Mes+j+3),*(Mes+j+4),*(Mes+j+5),*(Mes+j+6),*(Mes+j+7),*(Mes+j+8),*(Mes+j+9),*(Mes+j+10),*(Mes+j+11),*(Mes+j+12));
        }
        fclose(fp);
        printf("File saved\r\n");
    }
    measureSaved = true;
    */    
}


float MotionEstimation::getTranslationalVelocity(){

    return actualTranslationalVelocity;
}

float MotionEstimation::getRotationalVelocity(){
    
    return actualRotationalVelocity;
}



void MotionEstimation::matInverse(double A[3][3],double A_inv[3][3]){
    
    double factor = 1/(A[0][0]*A[1][1]*A[2][2] +
                                A[0][1]*A[1][2]*A[2][0] + 
                                A[0][2]*A[1][0]*A[2][1] -
                                A[0][2]*A[1][1]*A[2][0] -
                                A[0][1]*A[1][0]*A[2][2] -
                                A[0][0]*A[1][2]*A[2][1]);
            
            A_inv[0][0] = factor * (A[1][1]*A[2][2] - A[1][2]*A[2][1]);
            A_inv[0][1] = factor * (-(A[0][1]*A[2][2] - A[0][2]*A[2][1]));
            A_inv[0][2] = factor * (A[0][1]*A[1][2] - A[0][2]*A[1][1]);
            A_inv[1][0] = factor * (-(A[1][0]*A[2][2] - A[1][2]*A[2][0]));
            A_inv[1][1] = factor * (A[0][0]*A[2][2] - A[0][2]*A[2][0]);
            A_inv[1][2] = factor * (-(A[0][0]*A[1][2] - A[0][2]*A[1][0]));
            A_inv[2][0] = factor * (A[1][0]*A[2][1] - A[1][1]*A[2][0]);
            A_inv[2][1] = factor * (-(A[0][0]*A[2][1] - A[0][1]*A[2][0]));
            A_inv[2][2] = factor * (A[0][0]*A[1][1] - A[0][1]*A[1][0]);

}


/*
 * 
 */

void MotionEstimation::printMatrix3(double A[3][3]){
    printf("%f %f %f\r\n",A[0][0],A[0][1],A[0][2]);
    printf("%f %f %f\r\n",A[1][0],A[1][1],A[1][2]);
    printf("%f %f %f\r\n",A[2][0],A[2][1],A[2][2]);
}

void MotionEstimation::printVector3(double A[3]){
    printf("%f\r\n",A[0]);
    printf("%f\r\n",A[1]);
    printf("%f\r\n",A[2]);
}

void MotionEstimation::prediction(double x[3],double P[3][3], double u[3], double Q[3][3], double xPred[3], double PPred[3][3]){

    // xPred = f(xk-1)
    xPred[2] = u[2];
    xPred[1] = x[1] + (u[1] - x[0]*x[2])*PERIOD;
    xPred[0] = x[0] + (u[0] + x[1]*x[2])*PERIOD;

    // Fx = Jacobian(f(x))  
    double Fx[3][3];
    Fx[0][0] = 1.0;
    Fx[0][1] = u[2]*PERIOD;
    Fx[0][2] = xPred[1]*PERIOD;
    Fx[1][0] = -u[2]*PERIOD;
    Fx[1][1] = 1.0;
    Fx[1][2] = -xPred[0]*PERIOD;
    Fx[2][0] = 0.0;
    Fx[2][1] = 0.0;
    Fx[2][2] = 1.0;

    // PPred = Fx * PEst * Fx.transpose() + Q;
    PPred[0][0] = Fx[0][0]*(Fx[0][0]*P[0][0] + Fx[0][1]*P[1][0] + Fx[0][2]*P[2][0]) + Fx[0][1]*(Fx[0][0]*P[0][1] + Fx[0][1]*P[1][1] + Fx[0][2]*P[2][1]) + Fx[0][2]*(Fx[0][0]*P[0][2] + Fx[0][1]*P[1][2] + Fx[0][2]*P[2][2]) + Q[0][0];
    PPred[0][1] = Fx[1][0]*(Fx[0][0]*P[0][0] + Fx[0][1]*P[1][0] + Fx[0][2]*P[2][0]) + Fx[1][1]*(Fx[0][0]*P[0][1] + Fx[0][1]*P[1][1] + Fx[0][2]*P[2][1]) + Fx[1][2]*(Fx[0][0]*P[0][2] + Fx[0][1]*P[1][2] + Fx[0][2]*P[2][2]);
    PPred[0][2] = Fx[2][0]*(Fx[0][0]*P[0][0] + Fx[0][1]*P[1][0] + Fx[0][2]*P[2][0]) + Fx[2][1]*(Fx[0][0]*P[0][1] + Fx[0][1]*P[1][1] + Fx[0][2]*P[2][1]) + Fx[2][2]*(Fx[0][0]*P[0][2] + Fx[0][1]*P[1][2] + Fx[0][2]*P[2][2]);

    PPred[1][0] = Fx[0][0]*(Fx[1][0]*P[0][0] + Fx[1][1]*P[1][0] + Fx[1][2]*P[2][0]) + Fx[0][1]*(Fx[1][0]*P[0][1] + Fx[1][1]*P[1][1] + Fx[1][2]*P[2][1]) + Fx[0][2]*(Fx[1][0]*P[0][2] + Fx[1][1]*P[1][2] + Fx[1][2]*P[2][2]);
    PPred[1][1] = Fx[1][0]*(Fx[1][0]*P[0][0] + Fx[1][1]*P[1][0] + Fx[1][2]*P[2][0]) + Fx[1][1]*(Fx[1][0]*P[0][1] + Fx[1][1]*P[1][1] + Fx[1][2]*P[2][1]) + Fx[1][2]*(Fx[1][0]*P[0][2] + Fx[1][1]*P[1][2] + Fx[1][2]*P[2][2]) + Q[1][1];
    PPred[1][2] = Fx[2][0]*(Fx[1][0]*P[0][0] + Fx[1][1]*P[1][0] + Fx[1][2]*P[2][0]) + Fx[2][1]*(Fx[1][0]*P[0][1] + Fx[1][1]*P[1][1] + Fx[1][2]*P[2][1]) + Fx[2][2]*(Fx[1][0]*P[0][2] + Fx[1][1]*P[1][2] + Fx[1][2]*P[2][2]);

    PPred[2][0] = Fx[0][0]*(Fx[2][0]*P[0][0] + Fx[2][1]*P[1][0] + Fx[2][2]*P[2][0]) + Fx[0][1]*(Fx[2][0]*P[0][1] + Fx[2][1]*P[1][1] + Fx[2][2]*P[2][1]) + Fx[0][2]*(Fx[2][0]*P[0][2] + Fx[2][1]*P[1][2] + Fx[2][2]*P[2][2]);
    PPred[2][1] = Fx[1][0]*(Fx[2][0]*P[0][0] + Fx[2][1]*P[1][0] + Fx[2][2]*P[2][0]) + Fx[1][1]*(Fx[2][0]*P[0][1] + Fx[2][1]*P[1][1] + Fx[2][2]*P[2][1]) + Fx[1][2]*(Fx[2][0]*P[0][2] + Fx[2][1]*P[1][2] + Fx[2][2]*P[2][2]);
    PPred[2][2] = Fx[2][0]*(Fx[2][0]*P[0][0] + Fx[2][1]*P[1][0] + Fx[2][2]*P[2][0]) + Fx[2][1]*(Fx[2][0]*P[0][1] + Fx[2][1]*P[1][1] + Fx[2][2]*P[2][1]) + Fx[2][2]*(Fx[2][0]*P[0][2] + Fx[2][1]*P[1][2] + Fx[2][2]*P[2][2]) + Q[2][2];

}

void MotionEstimation::correction(double xPred[3], double PPred[3][3], double z[3], double R[3][3], double xCorr[3], double PCorr[3][3]){

    // zPred = H * xPred
    double zPred[3];
    zPred[0] = xPred[0];
    zPred[1] = xPred[1];
    zPred[2] = xPred[2];

    // y = z - zPred
    double y[3];
    y[0] = z[0] - zPred[0];
    y[1] = z[1] - zPred[1];
    y[2] = z[2] - zPred[2];

    // st = Hx * PPred * Hx.transpose() + R; H = Identity(3)
    double st[3][3];
    st[0][0] = PPred[0][0] + R[0][0];
    st[0][1] = PPred[0][1] + R[0][1];
    st[0][2] = PPred[0][2] + R[0][2];

    st[1][0] = PPred[1][0] + R[1][0];
    st[1][1] = PPred[1][1] + R[1][1];
    st[1][2] = PPred[1][2] + R[1][2];

    st[2][0] = PPred[2][0] + R[2][0];
    st[2][1] = PPred[2][1] + R[2][1];
    st[2][2] = PPred[2][2] + R[2][2];

    double st_inv[3][3];
    matInverse(st,st_inv);

    // K = PPred * Hx.transpose() * st_inv;
    double K[3][3];
    K[0][0] = PPred[0][0]*st_inv[0][0] + PPred[0][1]*st_inv[1][0] + PPred[0][2]*st_inv[2][0];
    K[0][1] = PPred[0][0]*st_inv[0][1] + PPred[0][1]*st_inv[1][1] + PPred[0][2]*st_inv[2][1];
    K[0][2] = PPred[0][0]*st_inv[0][2] + PPred[0][1]*st_inv[1][2] + PPred[0][2]*st_inv[2][2];

    K[1][0] = PPred[1][0]*st_inv[0][0] + PPred[1][1]*st_inv[1][0] + PPred[1][2]*st_inv[2][0];
    K[1][1] = PPred[1][0]*st_inv[0][1] + PPred[1][1]*st_inv[1][1] + PPred[1][2]*st_inv[2][1];
    K[1][2] = PPred[1][0]*st_inv[0][2] + PPred[1][1]*st_inv[1][2] + PPred[1][2]*st_inv[2][2];

    K[2][0] = PPred[2][0]*st_inv[0][0] + PPred[2][1]*st_inv[1][0] + PPred[2][2]*st_inv[2][0];
    K[2][1] = PPred[2][0]*st_inv[0][1] + PPred[2][1]*st_inv[1][1] + PPred[2][2]*st_inv[2][1];
    K[2][2] = PPred[2][0]*st_inv[0][2] + PPred[2][1]*st_inv[1][2] + PPred[2][2]*st_inv[2][2];
            
    // xCorr = xPred + K * y
    xCorr[0] = K[0][0]*y[0] + K[0][1]*y[1] + K[0][2]*y[2] + xPred[0];
    xCorr[1] = K[1][0]*y[0] + K[1][1]*y[1] + K[1][2]*y[2] + xPred[1];
    xCorr[2] = K[2][0]*y[0] + K[2][1]*y[1] + K[2][2]*y[2] + xPred[2];

    // PCorr = PPred - K * Hx * PPred
    PCorr[0][0] = -K[0][0]*PPred[0][0] - K[0][1]*PPred[1][0] - K[0][2]*PPred[2][0] + PPred[0][0];
    PCorr[0][1] = -K[0][0]*PPred[0][1] - K[0][1]*PPred[1][1] - K[0][2]*PPred[2][1] + PPred[0][1];
    PCorr[0][2] = -K[0][0]*PPred[0][2] - K[0][1]*PPred[1][2] - K[0][2]*PPred[2][2] + PPred[0][2];

    PCorr[1][0] = -K[1][0]*PPred[0][0] - K[1][1]*PPred[1][0] - K[1][2]*PPred[2][0] + PPred[1][0];
    PCorr[1][1] = -K[1][0]*PPred[0][1] - K[1][1]*PPred[1][1] - K[1][2]*PPred[2][1] + PPred[1][1];
    PCorr[1][2] = -K[1][0]*PPred[0][2] - K[1][1]*PPred[1][2] - K[1][2]*PPred[2][2] + PPred[1][2];

    PCorr[2][0] = -K[2][0]*PPred[0][0] - K[2][1]*PPred[1][0] - K[2][2]*PPred[2][0] + PPred[2][0];
    PCorr[2][1] = -K[2][0]*PPred[0][1] - K[2][1]*PPred[1][1] - K[2][2]*PPred[2][1] + PPred[2][1];
    PCorr[2][2] = -K[2][0]*PPred[0][2] - K[2][1]*PPred[1][2] - K[2][2]*PPred[2][2] + PPred[2][2];
}

void MotionEstimation::correctionGNSS(double xPred[3], double PPred[3][3], double z, double R, double xCorr[3], double PCorr[3][3]){

    // zPred = H * xPred
    double zPred;
    zPred = xPred[0];

    // y = z - zPred
    double y;
    y = z - zPred;

    // st = Hx * PPred * Hx.transpose() + R; H = Identity(3)
    double st;
    st = PPred[0][0] + R;

    double st_inv = 1/st;


    // K = PPred * Hx.transpose() * st_inv;
    double K[3];
    K[0] = PPred[0][0]*st_inv;
    K[1] = PPred[1][0]*st_inv;
    K[2] = PPred[2][0]*st_inv;

            
    // xCorr = xPred + K * y
    xCorr[0] = xPred[0] + K[0]*y;
    xCorr[1] = xPred[1] + K[1]*y;
    xCorr[2] = xPred[2] + K[2]*y;

    // PCorr = PPred - K * Hx * PPred
    PCorr[0][0] = -K[0]*PPred[0][0] + PPred[0][0];
    PCorr[0][1] = -K[0]*PPred[0][1] + PPred[0][1];
    PCorr[0][2] = -K[0]*PPred[0][2] + PPred[0][2];

    PCorr[1][0] = -K[1]*PPred[0][0] + PPred[1][0];
    PCorr[1][1] = -K[1]*PPred[0][1] + PPred[1][1];
    PCorr[1][2] = -K[1]*PPred[0][2] + PPred[1][2];

    PCorr[2][0] = -K[2]*PPred[0][0] + PPred[2][0];
    PCorr[2][1] = -K[2]*PPred[0][1] + PPred[2][1];
    PCorr[2][2] = -K[2]*PPred[0][2] + PPred[2][2];

}




/**
 * Run method
 */
void MotionEstimation::run() {
    
    timer.reset();
    timer.start();

    int waitCycles = 0;
    int waitCycles2 = 0;

    Timer calculationTimer;
    
    float GNSSspeed, GNSSheading, GNSSspeedAcc, GNSSheadingAcc;

    double zGNSS = 0.0;
    double lastZGNSS = 0.0;

    array<double, 3> xEst_tmp;
    array<array<double, 3>,3> PEst_tmp;
    array<double, 3> u_tmp;
    array<double, 3> z_tmp;

    deque<array<double, 3>> xEstHist;
    deque<array<array<double, 3>,3>> PEstHist;
    deque<array<double, 3>> uHist;
    deque<array<double, 3>> zHist;


    Timer tim;
    tim.start();

    Timer timInv;
    timInv.start();


    int i = 0;

    int timePred = 0;
    int timeCorr = 0;
    int timeCorrGPS = 0;
    int timeInv = 0;

    double xEst_B[3] = {0.0,0.0,0.0};
    double xPred_B[3] = {0.0,0.0,0.0};
    double xCorr_B[3] = {0.0,0.0,0.0};
    double u_B[3] = {0.0,0.0,0.0};
    double z_B[3] = {0.0,0.0,0.0};
    double Q_B[3][3] = { {0.000025,0.0,0.0},
                        {0.0,0.000025,0.0},
                        {0.0,0.0,0.0001}};
    double R_B[3][3] = { {0.01,0.0,0.0},
                        {0.0,0.01,0.0},
                        {0.0,0.0,0.01}};
    double PEst_B[3][3] = {{1.0,0.0,0.0},{0.0,1.0,0.0},{0.0,0.0,1.0}};
    double PPred_B[3][3] = {{1.0,0.0,0.0},{0.0,1.0,0.0},{0.0,0.0,1.0}};
    double PCorr_B[3][3] = {{1.0,0.0,0.0},{0.0,1.0,0.0},{0.0,0.0,1.0}};



    while(true)
    {
        // wait for the periodic thread flag
        ThisThread::flags_wait_any(threadFlag);

        // timer to check the calculation time (PX4Flow update = 0.5ms)
        calculationTimer.reset();
        calculationTimer.start();

        // calculate actual speed of wheels in [rad/s] and angles in [rad]
        short valueCounterRearLeft = rearLeftCounter.read();
        short valueCounterRearRight = rearRightCounter.read();

        short countsInPastPeriodRearLeft = valueCounterRearLeft-previousValueCounterRearLeft;
        short countsInPastPeriodRearRight = valueCounterRearRight-previousValueCounterRearRight;

        previousValueCounterRearLeft = valueCounterRearLeft;
        previousValueCounterRearRight = valueCounterRearRight;

        float actualSpeedRearLeft_NF = countsInPastPeriodRearLeft/COUNTS_PER_TURN/PERIOD*2.0*PI;
        float actualSpeedRearRight_NF = countsInPastPeriodRearRight/COUNTS_PER_TURN/PERIOD*2.0*PI;
        actualSpeedRearLeft = speedRearLeftFilter.filter(actualSpeedRearLeft_NF);
        actualSpeedRearRight = -speedRearRightFilter.filter(actualSpeedRearRight_NF);

        //actualSpeedRearLeft = speedRearLeftFilter.filter(countsInPastPeriodRearLeft/COUNTS_PER_TURN/PERIOD*2.0*PI);
        //actualSpeedRearRight = -speedRearRightFilter.filter(countsInPastPeriodRearRight/COUNTS_PER_TURN/PERIOD*2.0*PI);

        actualAngleRearLeft += actualSpeedRearLeft*PERIOD;
        actualAngleRearRight += actualSpeedRearRight*PERIOD;


        // update kinematik model
        float encoderTranslationalVelocity = (actualSpeedRearLeft+actualSpeedRearRight)/2.0*WHEEL_RADIUS;

        // execute wit 1/2 Frequency (100Hz)
        if(waitCycles>=2){
            
            neom9n.update();
            px4flow.update_integral();

            neom9n.get2DMotion(GNSSspeed, GNSSheading, GNSSspeedAcc, GNSSspeedAcc);
            
            waitCycles = 0;
        }
        waitCycles++;
        
        float motorCurrent = throttle.getTargetValue()*MAX_MOTOR_CURRENT;
        float steeringAngle = steering.getTargetValue()*RAD_PER_PWM;



        // Prediciton
        u_B[0] = -imu.getAccelerationX();
        u_B[1] = -imu.getAccelerationY();
        u_B[2] = -imu.getAngularVelocityZ();

        prediction(xEst_B, PEst_B, u_B, Q_B, xPred_B, PPred_B);

        timePred = tim.read_us();
        tim.reset();

        // Correction
        z_B[0] = encoderTranslationalVelocity;
        z_B[1] = 0.0;
        z_B[2] = -imu.getAngularVelocityZ();

        correction(xPred_B, PPred_B, z_B, R_B, xCorr_B, PCorr_B);

        memcpy(xEst_B, xCorr_B, sizeof(xEst_B));
        memcpy(PEst_B, PCorr_B, sizeof(PEst_B));

        // correction with GNSS
        zGNSS = GNSSspeed;

        // update xEst and PEst history
        xEst_tmp[0] = xEst_B[0];
        xEst_tmp[1] = xEst_B[1];
        xEst_tmp[2] = xEst_B[2];

        PEst_tmp[0][0] = PEst_B[0][0];
        PEst_tmp[0][1] = PEst_B[0][1];
        PEst_tmp[0][2] = PEst_B[0][2];
        PEst_tmp[1][0] = PEst_B[1][0];
        PEst_tmp[1][1] = PEst_B[1][1];
        PEst_tmp[1][2] = PEst_B[1][2];
        PEst_tmp[2][0] = PEst_B[2][0];
        PEst_tmp[2][1] = PEst_B[2][1];
        PEst_tmp[2][2] = PEst_B[2][2];

        u_tmp[0] = u_B[0];
        u_tmp[1] = u_B[1];
        u_tmp[2] = u_B[2];

        z_tmp[0] = z_B[0];
        z_tmp[1] = z_B[1];
        z_tmp[2] = z_B[2];

        if (xEstHist.size() > 40)
        xEstHist.pop_front();
        xEstHist.push_back(xEst_tmp);
        if (PEstHist.size() > 40)
        PEstHist.pop_front();
        PEstHist.push_back(PEst_tmp);
        if (uHist.size() > 40)
        uHist.pop_front();
        uHist.push_back(u_tmp);
        if (zHist.size() > 40)
        zHist.pop_front();
        zHist.push_back(z_tmp);

        timeCorr = tim.read_us();
        tim.reset();

        if (abs(zGNSS - lastZGNSS) > 0.000001 && uHist.size() > 40 && xEst_B[0] > 1.0) { //

            // calculate sensors divergence with encoder mes of 40 steps back
            double mean = (zHist[0][0] + zGNSS)/2.0;
            double variance =  (zHist[0][0] - mean)*(zHist[0][0] - mean) + (zGNSS - mean)*(zGNSS - mean);

            if(variance <= 0.2){
                // use 40 steps back xEst
                xEst_B[0] = xEstHist[0][0];
                xEst_B[1] = xEstHist[0][1];
                xEst_B[2] = xEstHist[0][2];

                PEst_B[0][0] = PEstHist[0][0][0];
                PEst_B[0][1] = PEstHist[0][0][1];
                PEst_B[0][2] = PEstHist[0][0][2];
                PEst_B[1][0] = PEstHist[0][1][0];
                PEst_B[1][1] = PEstHist[0][1][1];
                PEst_B[1][2] = PEstHist[0][1][2];
                PEst_B[2][0] = PEstHist[0][2][0];
                PEst_B[2][1] = PEstHist[0][2][1];
                PEst_B[2][2] = PEstHist[0][2][2];

                // correction with delay
                correctionGNSS(xEst_B, PEst_B, zGNSS, 0.0025, xCorr_B, PCorr_B);
                memcpy(xEst_B, xCorr_B, sizeof(xEst_B));
                memcpy(PEst_B, PCorr_B, sizeof(PEst_B));


                // propagate states with past input
                for(int j=1; j<(uHist.size()); j++){
                    
                    u_B[0] = uHist[j][0];
                    u_B[1] = uHist[j][1];
                    u_B[2] = uHist[j][2];
                    prediction(xEst_B, PEst_B, u_B, Q_B, xPred_B, PPred_B);

                    z_B[0] = zHist[j][0];
                    z_B[1] = zHist[j][1];
                    z_B[2] = zHist[j][2];
                    correction(xPred_B, PPred_B, z_B, R_B, xCorr_B, PCorr_B);
                    
                    memcpy(xEst_B, xCorr_B, sizeof(xEst_B));
                    memcpy(PEst_B, PCorr_B, sizeof(PEst_B));

                }
            }   
        }

    



    lastZGNSS = zGNSS;

    if(encoderTranslationalVelocity < 0.3 && encoderTranslationalVelocity > -0.0001){
        // use simple encoder and IMU if low speed (<0.1m/s) otherwise offset AccX results in little negative speeds
        actualTranslationalVelocity = encoderTranslationalVelocity;
        actualRotationalVelocity = z_B[2];
    } else {
        actualTranslationalVelocity = xEst_B[0];
        actualRotationalVelocity = xEst_B[2];
    }
    












        // save values to array
        if(waitCycles2>=2){ // 2 --> 100Hz

        // Save data
            if (nData != 0 && startMeasure && (measureIndex+14)<nData) {     
                *(Mes+measureIndex++) = timer.read(); //static_cast<float>(timer.read_ms()/1000.0)
                *(Mes+measureIndex++) = motorCurrent;
                *(Mes+measureIndex++) = actualTranslationalVelocity;
                //*(Mes+measureIndex++) = steeringAngle;
                //*(Mes+measureIndex++) = actualSpeedRearLeft;
                //*(Mes+measureIndex++) = actualSpeedRearRight;
                //*(Mes+measureIndex++) = GNSSspeed;
                //*(Mes+measureIndex++) = GNSSheading;
                //*(Mes+measureIndex++) = GNSSspeedAcc;
                //*(Mes+measureIndex++) = GNSSheadingAcc;
                *(Mes+measureIndex++) = static_cast<float>(imu.getAccelerationX());
                //*(Mes+measureIndex++) = static_cast<float>(imu.getAccelerationY());
                //*(Mes+measureIndex++) = static_cast<float>(imu.getAccelerationZ());
                //*(Mes+measureIndex++) = static_cast<float>(imu.getAngularVelocityZ());
                //*(Mes+measureIndex++) = static_cast<float>(imu.getYaw());
                //*(Mes+measureIndex++) = px4flow.avg_flow_x();
                //*(Mes+measureIndex++) = px4flow.avg_flow_y();
                //*(Mes+measureIndex++) = static_cast<float>(px4flow.avg_qual_scaled());
            }

            waitCycles2 = 0;
        }
        waitCycles2++;
        

        // save calculation time to member variable
        calculationTimer.stop();
        calculationTime = calculationTimer.read();

    }

}