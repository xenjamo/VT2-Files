/*
 * Controller.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 03.02.2021
 *      Author: Nicolas Borla
 */

#ifndef CONTROLLER_H_
#define CONTROLLER_H_

#include <cstdint>
#include <cstdlib>
#include <mbed.h>
#include "Motion.h"
#include "LowpassFilter.h"

#include "MotionEstimation.h"
#include "Servo.h"
#include "ThreadFlag.h"
#include "EncoderF767ZI.h"
#include "Timer.h"

/**
 * Template for the speedcontroller, für dich Jonas zu ergänzen ;)
 */
class Controller {

    public:
    
                    Controller(EncoderCounter &frontLeftCounter, EncoderCounter &frontRightCounter, EncoderCounter &rearLeftCounter, EncoderCounter &rearRightCounter,
                                Servo &steeringServo, Servo &throttle, AnalogIn& batteryVoltageSensor, MotionEstimation& motionEstimation,
                                int nData = 0, float *Mes = nullptr);
        virtual     ~Controller();
        void        setCommands(float desiredSteeringAngle, float desiredTranslationalVelocity, float desiredTranslationalAcceleration);
        void        setControllerMode(int16_t desiredControllerMode);
        int16_t     getState();
        void        turnOn();
        void        turnOff();
        float       getActualMotorSpeed();
        float       getTargetMotorSpeed();
        float       getSteeringAngle();
        float       getMotorCurrent();
        float       getMotorVoltage();
        float       getBatteryVoltage();
        float       getActualTranslationalVelocity();
        float       getActualRotationalVelocity();
        float       getActualAveragedDistanceRear();
        float       getActualOrientation();
        void        getActualVelocities(float &FL,float &FR,float &RL,float &RR);
        void        getActualAngles(float &FL,float &FR,float &RL,float &RR);
        float       getActualVelocityFL();
        float       getActualVelocityFR();
        float       getActualVelocityRL();
        float       getActualVelocityRR();

        void        startMeasurement();
        void        resetMeasurement();

        static const int16_t    OFF = 0;
        static const int16_t    ON = 1;
        static const int16_t    MANUAL = 2;
        static const int16_t    SEMI_AUTONOMOUS = 3;
        static const int16_t    AUTONOMOUS = 4;

        
    private:
        
        static const uint32_t   STACK_SIZE = 4096;  // stack size of thread, given in [bytes]
        static const float  PERIOD;
        static const float  PI;
        static const float  WHEEL_BASE;
        static const float  WHEEL_RADIUS;
        static const float  TRACK_WIDTH;
        static const float  COUNTS_PER_TURN;
        static const float  LOWPASS_FILTER_FREQUENCY;
        static const float  KN;
        static const float  KM;
        static const float  GEAR_RATIO;
        static const float  MANUAL_PROFILE_VELOCITY;
        static const float  MANUAL_PROFILE_ACCELERATION;
        static const float  MANUAL_PROFILE_DECELERATION;
        static const float  P_GAIN;
        static const float  RAD_PER_PWM;
        static const float  VEHICLE_MASS;
        static const float  P_GAIN_CURRENT_PER_RPM;
        static const float  MAX_MOTOR_CURRENT;
        static const float  CURRENT_BIAS;
        static const float  CURRENT_PROPOTIONAL_GAIN;
        static const float  STEERING_BACKLASH;
        static const float  STEERING_LOAD_FACTOR;

        EncoderCounter      &frontLeftCounter;
        EncoderCounter      &frontRightCounter;
        EncoderCounter      &rearLeftCounter;
        EncoderCounter      &rearRightCounter;
        Servo               &steeringServo;
        Servo               &throttle;
        AnalogIn&           batteryVoltageSensor;
        MotionEstimation&   motionEstimation;
        
        Motion              manualTranslationalMotion;

        int16_t             stateController;
        int16_t             stateDemandController;
        float               rotationalVelocity;
        float               steeringAngle;
        float               manualSteeringAngle;
        float               remoteSteeringAngle;
        float               actualTranslationalVelocity;
        float               actualRotationalVelocity;
        float               actualMotorSpeed;
        float               targetMotorSpeed;
        float               targetMotorAcceleration;
        short               previousValueCounterFrontLeft;
        short               previousValueCounterFrontRight;
        short               previousValueCounterRearLeft;
        short               previousValueCounterRearRight;
        LowpassFilter       speedFrontLeftFilter;
        LowpassFilter       speedFrontRightFilter;
        LowpassFilter       speedRearLeftFilter;
        LowpassFilter       speedRearRightFilter;
        float               actualSpeedFrontLeft;
        float               actualSpeedFrontRight;
        float               actualSpeedRearLeft;
        float               actualSpeedRearRight;
        float               actualAngleFrontLeft;
        float               actualAngleFrontRight;
        float               actualAngleRearLeft;
        float               actualAngleRearRight;
        float               desiredMotorSpeed;
        float               targetPhaseVoltage;
        float               pwm;
        float               currentMotorSaturated;
        float               batteryVoltage;
        float               actualAveragedDistanceRear;
        float               actualOrientation;
        float               targetCurrent;
        float               desiredSteeringAngle;
        float               desiredTranslationalVelocity;
        float               desiredTranslationalAcceleration;

        // pointer to measurement objects
        int                 nData;
        float               *Mes;
        Timer               timer;
        bool                startMeasure;
        int                 measureIndex;

        ThreadFlag          threadFlag;
        Thread              thread;
        Ticker              ticker;
        
        void                sendThreadFlag();
        void                run();
};

#endif /* CONTROLLER_H_ */


