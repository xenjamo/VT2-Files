#ifndef _PX4FLOW_MBED_H
#define _PX4FLOW_MBED_H

# include <stdint.h>
# include "mbed.h"
# include "ThreadFlag.h"

// 7 Bit I2C Address of the Flow Module: Default 0x42 (user selectable bits 0,1,2)
#define PX4FLOW_ADDRESS 0x42<<1

// Commands
#define    INTEGRAL_FRAME 0x16

// integral frame
#define    AVG_FLOW_X        0
#define    AVG_FLOW_Y        2
#define    AVG_QUAL          4
#define    VALID_FRAME_COUNT 5
#define    FRAME_COUNT_      6

// Integral frame, only valid with modified firmware, see Git-branch IndNav from the Firmware
typedef struct i2c_integral_frame {
    int16_t avg_flow_x;
    int16_t avg_flow_y;
    uint8_t avg_qual;
    uint8_t valid_frame_count;
    uint8_t frame_count;
} i2c_integral_frame;


class PX4Flow
{
public:
    
    PX4Flow(I2C& i2c);
    
    virtual ~PX4Flow();

    bool update_integral();
    
    float   avg_flow_x();        // avg flow x in mm/s
    float   avg_flow_y();        // avg flow y in mm/s
    uint8_t avg_qual();          // avg 0-255 linear quality measurement 0=bad, 255=best
    uint8_t valid_frame_count(); // nr. of valid frames (qual > 0) between i2c readings
    uint8_t frame_count();       // nr. of frames between i2c readings    
    uint8_t avg_qual_scaled();   // avg 0-255 linear quality measurement 0=bad, 255=best, scaled with N_valid_frame_count/N_frame_count

    
private:



protected:

    I2C &i2c;
    
    // storage for sensordata
    char bufferI[7];

    char i2c_commands;
    
    struct i2c_integral_frame iframe;

    uint8_t  read8(char *buffer, const unsigned int& idx = 0);
    uint16_t read16(char *buffer, const unsigned int& idx = 0);
    uint32_t read32(char *buffer, const unsigned int& idx = 0);
};

#endif
