/*
 * Servo.cpp
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
*/

#include "Servo.h"

using namespace std;

/** 
 * This class implemtens a simple servo. It provides functions to calculate and set the on time of the pulse width.
 * @param pwmOut reference to the pwm object
 * @param invert reverses the servo direction (mirrors pulse duration on center of nominalLowerOnTime & nominalUpperOnTime)
 * @param nominalLowerOnTime lower value of pulse duration in [us] considered as -100 %
 * @param nominalUpperOnTime higher value of pulse duration in [us] considered as +100 %
 * @param lowerLimit limits the input value
 * @param upperLimit limits the input value
 * @param scaleToNominal scaling factor. Maps target value to nominal pulse duration. Default 1.0 (-1.0 -> nominalLowerOnTime / +1.0 -> nominalUpperOnTime)
 * @param defaultValue default target value
 */
Servo::Servo(PwmOut& pwmOut, bool invert, int16_t nominalLowerOnTime, int16_t nominalUpperOnTime,  float lowerLimit, float upperLimit, float scaleToNominal, float defaultValue) : pwmOut(pwmOut) {

    this->nominalLowerOnTime=nominalLowerOnTime;
    this->nominalUpperOnTime=nominalUpperOnTime;
    this->lowerLimit=lowerLimit;
    this->upperLimit=upperLimit;
    this->scaleToNominal=scaleToNominal;
    this->invert=invert;

    nominalCenterOnTime = (nominalLowerOnTime + nominalUpperOnTime) / 2.0;
    timeRange = nominalUpperOnTime - nominalLowerOnTime;
    targetValue = defaultValue;

    pwmOut.period_us(PERIODE_SERVO_SIGNAL);

    writeValue(targetValue);

}

Servo::~Servo() {}

void Servo::writeValue(float targetValue) {

    this->targetValue = targetValue;

    int16_t onTime = mapValueToOnTime(targetValue);

    if (invert) onTime = invertSignal(onTime);

    if (onTime < MINIMAL_ON_TIME_SERVO) onTime = MINIMAL_ON_TIME_SERVO;
    if (onTime > MAXIMAL_ON_TIME_SERVO) onTime = MAXIMAL_ON_TIME_SERVO;

    targetOnTime = onTime;

    int16_t bias = 20; // seems like the on time with "pulsewidth_us" has a bias...
    pwmOut.pulsewidth_us(targetOnTime - bias);

}

int16_t Servo::readOnTime() {

    return targetOnTime;
}

int16_t Servo::mapValueToOnTime(float value) {

    if (value > upperLimit) value = upperLimit;
    else if (value < lowerLimit) value = lowerLimit;

    return nominalCenterOnTime + value/scaleToNominal*(timeRange/2.0);
}

int16_t Servo::invertSignal(int16_t onTime) {

    return nominalUpperOnTime - (onTime - nominalLowerOnTime);
}

float Servo::getTargetValue(){
    
    return this->targetValue;
}