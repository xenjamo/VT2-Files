/*
 * MotionController.cpp
 * Copyright (c) 2019, ZHAW
 * All rights reserved.
 *
 *  Created on: 03.10.2020
 *      Author: Jerome Perdrizat
 */

#include "MotionController.h"

#define C_OUT(varName) cout<<name<<": "<< #varName <<": "<<varName<<endl
#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif

using namespace std;

/**
 * this motion controller should provide functionallity to callculate the target steering angle for the front wheels and the target velocity for the throttle
 * @param pGain P-Gain for the PID-controller which has the distance error as input and the target velocity as ouput
 * @param iGain I-Gain for the PID-controller which has the distance error as input and the target velocity as ouput
 * @param dGain D-Gain for the PID-controller which has the distance error as input and the target velocity as ouput
 * @param headingPGain  P-Gain for the P-controller which has the error of theta as input and the output is the steering angle
 * @param maxVelocity Maximal velocity of the car, given in [m/s]
 * @param maxAcceleration Maximal acceleration of the car, given in [m/s^2]
 * @param maxDeceleration Maximal deceleration of the car, given in [m/s^2]
 * @param maxSteeringAngle the maximal steering angle achiveable by the car, given in [rad]
 */
MotionController::MotionController(double pGain, double iGain, double dGain, double headingPGain, double maxVelocity, double maxAcceleration, double maxDeceleration, double maxSteeringAngle){
        xPositionActualValue = 0;
        yPositionActualValue = 0;
        xPositionLastValue = 0;
        yPositionLastValue = 0;
        xPositionTargetValue = 0;
        yPositionTargetValue = 0;
        thetaActualValue = 0;
        profileVelocity = maxVelocity;

        this->pGain = pGain;
        this->iGain = iGain; 
        this->dGain = dGain; 
        this->headingPGain = headingPGain;
        errorIntegrated = 0;

        this->maxVelocity = maxVelocity;
        this->maxAcceleration = maxAcceleration;
        this->maxDeceleration = maxDeceleration;
        this->maxSteeringAngle = maxSteeringAngle;

        xMotionPlaner.setLimits(static_cast<float>(maxVelocity), static_cast<float>(maxAcceleration), static_cast<float>(maxDeceleration));
        yMotionPlaner.setLimits(static_cast<float>(maxVelocity), static_cast<float>(maxAcceleration), static_cast<float>(maxDeceleration));

        radiusAroundTargetToBeReadyForNextPosition = 1;
}

MotionController::~MotionController(){;}


// /**
//  * @brief MotionController::updatePoseValues Updates the position actual values in the motion controller. 
//  * @warning Caution this overwrites the position last values, do not call this function unless you're planing to increment to a target position
//  * @param xPositionActualValue The actual position in X-Direction, given in [m]
//  * @param yPositionActualValue The actual position in X-Direction, given in [m] 
//  * @param thetaActualValue The current value of theta, given in [rad]
//  */
// void MotionController::updatePoseValues(double xPositionActualValue, double yPositionActualValue, double thetaActualValue){
//     xPositionLastValue = this->xPositionActualValue;
//     yPositionLastValue = this->yPositionActualValue;
//     thetaLastValue = this->thetaActualValue;
//     this->xPositionActualValue = xPositionActualValue;
//     this->yPositionActualValue = yPositionActualValue;
//     this->thetaActualValue = thetaActualValue;
// }


/**
 * @brief MotionController::writeTargetPosition we're heading this point when we're increment to our target
 * @warning This function uses the xPositionActualValue and the yPositionActualValue, so make sure, they are actual
 * @param xPositionTargetValue Target position in x-Direction in coordinates of the cars origin, given in [m]
 * @param yPositionTargetValue Target position in y-Direction in coordinates of the cars origin, given in [m]
 */
void  MotionController::writeTargetPosition(double xPositionTargetValue, double yPositionTargetValue){
    this->xPositionTargetValue = xPositionTargetValue;
    this->yPositionTargetValue = yPositionTargetValue;
    double dX = xPositionTargetValue - xPositionActualValue;
    double dY = yPositionTargetValue - yPositionActualValue;
    float angleToTarget = atan2(dY, dX);
    xMotionPlaner.setLimits( abs(cos(angleToTarget) * profileVelocity) , abs(cos(angleToTarget) * maxAcceleration) , abs(cos(angleToTarget) * maxDeceleration) );
    yMotionPlaner.setLimits( abs(sin(angleToTarget) * profileVelocity) , abs(sin(angleToTarget) * maxAcceleration) , abs(sin(angleToTarget) * maxDeceleration) );
}


/**
 * @brief MotionController::setPoseActualValues Set the position actual value to this class
 * @param xPositionActualValue Actual position value in Y, given in [m]
 * @param yPositionActualValue Actual position value in Y, given in [m]
 * @param thetaActualValue Actual value of theta of car, given in [rad]
 */
void MotionController::setPoseActualValues(double xPositionActualValue, double yPositionActualValue, double thetaActualValue){
    this->xPositionActualValue = xPositionActualValue;
    this->yPositionActualValue = yPositionActualValue;

    //Since the imu sends data from 0...2pi we have to change this here from -pi...pi
    if(thetaActualValue <= M_PI){
        this->thetaActualValue = thetaActualValue;
    } else {
        this->thetaActualValue = thetaActualValue - 2* M_PI;
    }
}


/**
 * @brief MotionController::getDistanceToTarget Get the distance to the target. Only the distance of the x and y axis is taken into account
 * @return Distance to target, returned in [m]
 */
double MotionController::getDistanceToTarget(){
    double dX = xPositionTargetValue - xPositionActualValue;
    double dY = yPositionTargetValue - yPositionActualValue;
    return sqrt(dX * dX + dY * dY);
}

/**
 * @brief MotionController::readyForNextPosition checks if we're nearer than the look ahead distance to our target
 */
bool MotionController::readyForNextPosition(){
    return (radiusAroundTargetToBeReadyForNextPosition >= getDistanceToTarget());
}

/**
 * @brief A function to set the P-Gain of the velocity controller
 * @param pGain The desired P-Gain
 */
void MotionController::setPGain(double pGain){
    this->pGain = pGain;
}

/**
 * @brief A function to set the I-Gain of the velocity controller
 * @param iGain The desired I-Gain
 */
void MotionController::setIGain(double iGain){
    this->iGain = iGain;
}

/**
 * @brief A function to set the D-Gain of the velocity controller
 * @param dGain The desired d-Gain
 */
void MotionController::setDGain(double dGain){
    this->dGain = dGain;
}

/**
 * @brief A function to set the P-Gain of the steereing controller
 * @param pGain The desired P-Gain
 */
void MotionController::setHeadingPGain(double headingPGain){
    this->headingPGain = headingPGain;
}


/**
 * @brief MotionController::writeTargetVelocity Writes the target profile velocity for a movement. This must be > zero and less than the maxVelocity
 * @param velocity given im [m/s]
 */
void MotionController::writeTargetVelocity(double velocity){
    velocity = abs(velocity);
    profileVelocity = min(velocity, maxVelocity);
}

/**
 * @brief MotionController::controll Calculate the controll effort for the velocity and the theta value. This function uses the actual and the last positionValues
 * It also iterates the motion controller to its target, for the duration of a periode
 * @param vEndIsZero We can set this flag to true to let the car stop at the end of the movement. This might will be good, if you don't know your next position when calling the motion controller
 * if this flag is set, we're useing a positionController to the target position, otherwise we're using a velocity controller, in direction of the target.
 * @param period Duration of this periode, given in [s]
 * @param velecityCommandValue A reference to a variable, which will be filled with the velocity for the throttle after this function. The value is in [m/s]
 * @param thetaCommandValuem A reference to a variable, which will be filled with the angle for the steering wheels after this function.
 * @return return false if position is out of reach
 */
bool MotionController::controll(bool vEndIsZero, double period, double &velecityCommandValue, double &thetaCommandValue) {
    bool returnValue = true;
    
    if(vEndIsZero){
        xMotionPlaner.incrementToPosition(xPositionTargetValue, period);
        yMotionPlaner.incrementToPosition(yPositionTargetValue, period);
    } else {
        double dX = xPositionTargetValue - xPositionActualValue;
        double dY = yPositionTargetValue - yPositionActualValue;
        float angleToTarget = atan2(dY, dX);
        xMotionPlaner.incrementToVelocity( cos(angleToTarget) * profileVelocity, period );
        yMotionPlaner.incrementToPosition( sin(angleToTarget) * profileVelocity, period );
    }

    double xPositionError = xMotionPlaner.getPosition() - xPositionActualValue;
    double yPositionError = yMotionPlaner.getPosition() - yPositionActualValue;

    double positionError = sqrt(xPositionError * xPositionError + yPositionError * yPositionError);

    double controllEffortProportional = positionError * pGain;
    errorIntegrated += period * positionError;
    double controllEffortIntegrator = errorIntegrated * iGain;

    //Anti-Wind-Up strategy, controll effort from integrator must be within 0 and MAX_VELOCITY_RATIO_CONTRIBUTED_BY_INTEGRATOR
    //otherwise reduce it by the last element. this avoid hard jumps in case of just setting it to zero
    if(controllEffortIntegrator > MAX_VELOCITY_RATIO_CONTRIBUTED_BY_INTEGRATOR){
        controllEffortIntegrator = MAX_VELOCITY_RATIO_CONTRIBUTED_BY_INTEGRATOR; //[nA] limit to motor rated current
        errorIntegrated -= 10*period * positionError; //[counts]

    } else if(controllEffortIntegrator < 0 ){
        //we must not drive in reverse direction, so this never should happen. And this never can happen, since positionError is always a positive number
        controllEffortIntegrator = 0;
        errorIntegrated = 0;
    } else{} //do nothing

    double dX = xPositionActualValue - xPositionLastValue;
    double dY = yPositionActualValue - yPositionLastValue;
    double velocityActualValue = sqrt(dX * dX + dY * dY) / period;
    xPositionLastValue = xPositionActualValue;
    xPositionLastValue = xPositionActualValue;

    double xVelocityTargetValue = xMotionPlaner.getVelocity();
    double yVelocityTargetValue = yMotionPlaner.getVelocity();
    double velocityTargetValue = sqrt(xVelocityTargetValue * xVelocityTargetValue + yVelocityTargetValue * yVelocityTargetValue);

    double velocityError = velocityTargetValue - velocityActualValue;

    double controllEffortDifferentiator = velocityError * dGain;

    //Currently we're only checking the steering angle, later you can check more stuff here
    

    double headingAngleToGoal = atan2(yPositionError, xPositionError);
    double thetaError = headingAngleToGoal - thetaActualValue;
    
    if(abs(headingAngleToGoal) > maxSteeringAngle ){
        returnValue =  false;
    }
    velecityCommandValue = controllEffortProportional + controllEffortIntegrator + controllEffortDifferentiator;


    thetaCommandValue = (-1)*headingPGain * thetaError;

    
    printf("cmd: %f,   Xact: %f   errorX: %f   ,   yact: %f   errory: %f , THETA  act: %f,    error: %f      heading: %f\r\n",xPositionActualValue, xPositionError, yPositionActualValue, yPositionError, thetaCommandValue, thetaActualValue, thetaError, headingAngleToGoal);
    return returnValue;
}

