/*
 * CANopen.cpp
 * Copyright (c) 2017, ZHAW
 * All rights reserved.
 *
 *  Created on: 16.11.2017
 *      Author: Marcel Honegger
 */

#include "ObjectDictionary.h"
#include "CANopen.h"

using namespace std;

const float CANopen::PERIOD = 0.0001f;  // the period of the timer interrupt, given in [s]

/**
 * Creates a CANopen slave stack object.
 * @param can a reference to the CAN device driver.
 * @param objectDictionary a reference to the CANopen object dictionary of this device.
 */
CANopen::CANopen(CAN& can, ObjectDictionary& objectDictionary) : can(can), objectDictionary(objectDictionary), thread(osPriorityHigh2, STACK_SIZE) {
    
    // initialize local values
    
    producerHeartbeatTimer.start();
    consumer1HeartbeatTimer.stop();
    
    // start thread and timer interrupt
    
    thread.start(callback(this, &CANopen::run));
    ticker.attach(callback(this, &CANopen::sendThreadFlag), PERIOD);
}

/**
 * Deletes the CANopen slave stack object.
 */
CANopen::~CANopen() {
    
    ticker.detach();
}

/**
 * Transmit an emergency message on the CAN bus. This usually needs
 * to be done after an error in the device occured.
 * @param errorCode the type of the error, as listed in the error history of the object dictionary.
 * @param errorRegister the current error register, a copy of the object 0x1001.
 */
void CANopen::transmitEmergencyMessage(uint16_t errorCode, uint8_t errorRegister) {
    
    CANMessage canMessage;
    canMessage.id = EMERGENCY+objectDictionary.nodeID;
    canMessage.type = CANData;
    canMessage.len = 8;
    canMessage.data[0] = static_cast<uint8_t>(errorCode & 0xFF);
    canMessage.data[1] = static_cast<uint8_t>((errorCode >> 8) & 0xFF);
    canMessage.data[2] = errorRegister;
    
    writeMessage(canMessage);
}

/**
 * Writes a CAN message into the output buffer for transmission.
 * @param canMessage the CAN message to transmit.
 */
void CANopen::writeMessage(CANMessage& canMessage) {
    
    mutex.lock();
    
    if (canOutputBuffer.size() < CAN_OUTPUT_BUFFER_SIZE) {
        
        canOutputBuffer.push_back(canMessage);
        
    } else {
        
        // output buffer is full, ignore message
    }
    
    mutex.unlock();
}

/**
 * This method is called by the ticker timer interrupt service routine.
 * It sends a flag to the thread to make it run again.
 */
void CANopen::sendThreadFlag() {
    
    thread.flags_set(threadFlag);
}

/**
 * This <code>run()</code> method contains an infinite loop with the run logic.
 */
void CANopen::run() {
    
    // set CAN bitrate
    
    switch (objectDictionary.canBitrate) {
        case -1:
            can.frequency(2000000);
            break;
        case 0:
            can.frequency(1000000);
            break;
        case 1:
            can.frequency(800000);
            break;
        case 2:
            can.frequency(500000);
            break;
        case 3:
            can.frequency(250000);
            break;
        case 4:
            can.frequency(125000);
            break;
        case 5:
            can.frequency(100000);
            break;
        default:
            can.frequency(1000000);
            break;
    }
    
    CANMessage canMessage;
    
    // enter periodic loop
    
    while (true) {
        
        // wait for the periodic thread flag
        
        ThisThread::flags_wait_any(threadFlag);
        
        // transmit bootup message
        
        if (objectDictionary.canOpenNMTState == STATE_INITIALISATION) {
            
            canMessage.id = NODEGUARD+objectDictionary.nodeID;
            canMessage.type = CANData;
            canMessage.len = 1;
            canMessage.data[0] = STATE_INITIALISATION;
            
            writeMessage(canMessage);
            
            objectDictionary.canOpenNMTState = STATE_PRE_OPERATIONAL;
        }
        
        // transmit heartbeat message
        
        if ((objectDictionary.canOpenNMTState == STATE_PRE_OPERATIONAL) || (objectDictionary.canOpenNMTState == STATE_OPERATIONAL)) {
            
            if ((objectDictionary.producerHeartbeatTime > 0) && (objectDictionary.producerHeartbeatTime <= producerHeartbeatTimer.read_ms())) {
                
                canMessage.id = NODEGUARD+objectDictionary.nodeID;
                canMessage.type = CANData;
                canMessage.len = 1;
                canMessage.data[0] = objectDictionary.canOpenNMTState;
                
                writeMessage(canMessage);
                
                producerHeartbeatTimer.reset();
            }
        }
        
        // update objectDictionary entries
        
        objectDictionary.consumer1HeartbeatTimer = consumer1HeartbeatTimer.read_ms();
        
        // check if new messages were received
        
        while (can.read(canMessage)) {
    
            // process received message
            
            if (canMessage.type == CANRemote) {
                
                // respond to remote transmission request
                
                if (objectDictionary.canOpenNMTState == STATE_OPERATIONAL) {
                    
                    // process RTR on TxPDO 1
                    
                    if ((canMessage.id == (objectDictionary.cobIDTransmitPDO1 & CAN_ID_MASK)) && ((objectDictionary.cobIDTransmitPDO1 & PDO_VALID_MASK) == 0) && ((objectDictionary.cobIDTransmitPDO1 & RTR_ALLOWED_MASK) == 0)) {
                        
                        uint8_t length = 8;
                        uint32_t abortCode = objectDictionary.readTxPDO(1, canMessage.data, length);
                        
                        if (abortCode == NO_COMMUNICATION_ERROR) {
                            
                            canMessage.id = objectDictionary.cobIDTransmitPDO1 & CAN_ID_MASK;
                            canMessage.type = CANData;
                            canMessage.len = length;
                            
                            writeMessage(canMessage);
                        }
                    }
                    
                    // process RTR on TxPDO 2
                    
                    if ((canMessage.id == (objectDictionary.cobIDTransmitPDO2 & CAN_ID_MASK)) && ((objectDictionary.cobIDTransmitPDO2 & PDO_VALID_MASK) == 0) && ((objectDictionary.cobIDTransmitPDO2 & RTR_ALLOWED_MASK) == 0)) {
                        
                        uint8_t length = 8;
                        uint32_t abortCode = objectDictionary.readTxPDO(2, canMessage.data, length);
                        
                        if (abortCode == NO_COMMUNICATION_ERROR) {
                            
                            canMessage.id = objectDictionary.cobIDTransmitPDO2 & CAN_ID_MASK;
                            canMessage.type = CANData;
                            canMessage.len = length;
                            
                            writeMessage(canMessage);
                        }
                    }
                    
                    // process RTR on TxPDO 3
                    
                    if ((canMessage.id == (objectDictionary.cobIDTransmitPDO3 & CAN_ID_MASK)) && ((objectDictionary.cobIDTransmitPDO3 & PDO_VALID_MASK) == 0) && ((objectDictionary.cobIDTransmitPDO3 & RTR_ALLOWED_MASK) == 0)) {
                        
                        uint8_t length = 8;
                        uint32_t abortCode = objectDictionary.readTxPDO(3, canMessage.data, length);
                        
                        if (abortCode == NO_COMMUNICATION_ERROR) {
                            
                            canMessage.id = objectDictionary.cobIDTransmitPDO3 & CAN_ID_MASK;
                            canMessage.type = CANData;
                            canMessage.len = length;
                            
                            writeMessage(canMessage);
                        }
                    }
                    
                    // process RTR on TxPDO 4
                    
                    if ((canMessage.id == (objectDictionary.cobIDTransmitPDO4 & CAN_ID_MASK)) && ((objectDictionary.cobIDTransmitPDO4 & PDO_VALID_MASK) == 0) && ((objectDictionary.cobIDTransmitPDO4 & RTR_ALLOWED_MASK) == 0)) {
                        
                        uint8_t length = 8;
                        uint32_t abortCode = objectDictionary.readTxPDO(4, canMessage.data, length);
                        
                        if (abortCode == NO_COMMUNICATION_ERROR) {
                            
                            canMessage.id = objectDictionary.cobIDTransmitPDO4 & CAN_ID_MASK;
                            canMessage.type = CANData;
                            canMessage.len = length;
                            
                            writeMessage(canMessage);
                        }
                    }
                    
                } else {
                    
                    // wrong CANopen state for process data communication
                }
                
            } else {
                
                if (canMessage.id == static_cast<uint32_t>(NMT)) {
                    
                    // network management message received
                    
                    if (canMessage.len >= 2) {
                        
                        // process network management message
                        
                        uint8_t commandSpecifier = canMessage.data[0];
                        uint8_t nodeID = canMessage.data[1];
                        
                        if ((nodeID == 0) || (nodeID == objectDictionary.nodeID)) {
                            
                            switch (objectDictionary.canOpenNMTState) {
                                case STATE_INITIALISATION:
                                    break;
                                case STATE_PRE_OPERATIONAL:
                                    if (commandSpecifier == START_REMOTE_NODE) {
                                        objectDictionary.configureRxPDOs();
                                        objectDictionary.configureTxPDOs();
                                        objectDictionary.canOpenNMTState = STATE_OPERATIONAL;
                                    } else if (commandSpecifier == STOP_REMOTE_NODE) objectDictionary.canOpenNMTState = STATE_STOPPED;
                                    else if (commandSpecifier == RESET_NODE) objectDictionary.canOpenNMTState = STATE_INITIALISATION;
                                    else if (commandSpecifier == RESET_COMMUNICATION) objectDictionary.canOpenNMTState = STATE_INITIALISATION;
                                    break;
                                case STATE_OPERATIONAL:
                                    if (commandSpecifier == STOP_REMOTE_NODE) objectDictionary.canOpenNMTState = STATE_STOPPED;
                                    else if (commandSpecifier == ENTER_PRE_OPERATIONAL_STATE) objectDictionary.canOpenNMTState = STATE_PRE_OPERATIONAL;
                                    else if (commandSpecifier == RESET_NODE) objectDictionary.canOpenNMTState = STATE_INITIALISATION;
                                    else if (commandSpecifier == RESET_COMMUNICATION) objectDictionary.canOpenNMTState = STATE_INITIALISATION;
                                    break;
                                case STATE_STOPPED:
                                    if (commandSpecifier == START_REMOTE_NODE) {
                                        objectDictionary.configureRxPDOs();
                                        objectDictionary.configureTxPDOs();
                                        objectDictionary.canOpenNMTState = STATE_OPERATIONAL;
                                    } else if (commandSpecifier == ENTER_PRE_OPERATIONAL_STATE) objectDictionary.canOpenNMTState = STATE_PRE_OPERATIONAL;
                                    else if (commandSpecifier == RESET_NODE) objectDictionary.canOpenNMTState = STATE_INITIALISATION;
                                    else if (commandSpecifier == RESET_COMMUNICATION) objectDictionary.canOpenNMTState = STATE_INITIALISATION;
                                    break;
                                default:
                                    break;
                            }
                            
                        } else {
                            
                            // wrong nodeID, ignore message
                        }
                        
                    } else {
                        
                        // wrong message length
                    }
                    
                } else if (canMessage.id == static_cast<uint32_t>(NODEGUARD+((objectDictionary.consumer1HeartbeatTime >> 16) & 0xFF))) {
                    
                    // valid heartbeat message received
                    
                    if ((objectDictionary.consumer1HeartbeatTime & 0xFFFF) > 0) {
                        
                        // consumer heartbeat enabled, resetting timer
                        
                        consumer1HeartbeatTimer.reset();
                        consumer1HeartbeatTimer.start();
                        
                    } else {
                        
                        // consumer heartbeat disabled, ignore message
                    }
                    
                } else if ((canMessage.id == (objectDictionary.cobIDReceivePDO1 & CAN_ID_MASK)) && ((objectDictionary.cobIDReceivePDO1 & PDO_VALID_MASK) == 0)) {
                    
                    if (objectDictionary.canOpenNMTState == STATE_OPERATIONAL) {
                        
                        // process RxPDO 1
                        
                        uint8_t length = canMessage.len;
                        objectDictionary.writeRxPDO(1, canMessage.data, length);
                        
                    } else {
                        
                        // wrong CANopen state for process data communication
                    }
                    
                } else if ((canMessage.id == (objectDictionary.cobIDReceivePDO2 & CAN_ID_MASK)) && ((objectDictionary.cobIDReceivePDO2 & PDO_VALID_MASK) == 0)) {
                    
                    if (objectDictionary.canOpenNMTState == STATE_OPERATIONAL) {
                        
                        // process RxPDO 2
                        
                        uint8_t length = canMessage.len;
                        objectDictionary.writeRxPDO(2, canMessage.data, length);
                        
                    } else {
                        
                        // wrong CANopen state for process data communication
                    }
                    
                } else if ((canMessage.id == (objectDictionary.cobIDReceivePDO3 & CAN_ID_MASK)) && ((objectDictionary.cobIDReceivePDO3 & PDO_VALID_MASK) == 0)) {
                    
                    if (objectDictionary.canOpenNMTState == STATE_OPERATIONAL) {
                        
                        // process RxPDO 3
                        
                        uint8_t length = canMessage.len;
                        objectDictionary.writeRxPDO(3, canMessage.data, length);
                        
                    } else {
                        
                        // wrong CANopen state for process data communication
                    }
                    
                } else if ((canMessage.id == (objectDictionary.cobIDReceivePDO4 & CAN_ID_MASK)) && ((objectDictionary.cobIDReceivePDO4 & PDO_VALID_MASK) == 0)) {
                    
                    if (objectDictionary.canOpenNMTState == STATE_OPERATIONAL) {
                        
                        // process RxPDO 4
                        
                        uint8_t length = canMessage.len;
                        objectDictionary.writeRxPDO(4, canMessage.data, length);
                        
                    } else {
                        
                        // wrong CANopen state for process data communication
                    }
                    
                } else if (canMessage.id == SYNC) {
                    
                    if (objectDictionary.canOpenNMTState == STATE_OPERATIONAL) {
                        
                        // process TxPDO 1
                        
                        if ((objectDictionary.cobIDTransmitPDO1 & PDO_VALID_MASK) == 0) {
                            
                            if (objectDictionary.transmissionTypeTransmitPDO1 == 1) {
                                
                                uint8_t length = 8;
                                uint32_t abortCode = objectDictionary.readTxPDO(1, canMessage.data, length);
                                
                                if (abortCode == NO_COMMUNICATION_ERROR) {
                                    
                                    canMessage.id = objectDictionary.cobIDTransmitPDO1 & CAN_ID_MASK;
                                    canMessage.type = CANData;
                                    canMessage.len = length;
                                    
                                    writeMessage(canMessage);
                                }
                                
                            } else {
                                
                                // wrong transmission type, 253 instead of 1
                            }
                            
                        } else {
                            
                            // TxPDO 1 is not valid
                        }
                        
                        // process TxPDO 2
                        
                        if ((objectDictionary.cobIDTransmitPDO2 & PDO_VALID_MASK) == 0) {
                            
                            if (objectDictionary.transmissionTypeTransmitPDO2 == 1) {
                                
                                uint8_t length = 8;
                                uint32_t abortCode = objectDictionary.readTxPDO(2, canMessage.data, length);
                                
                                if (abortCode == NO_COMMUNICATION_ERROR) {
                                    
                                    canMessage.id = objectDictionary.cobIDTransmitPDO2 & CAN_ID_MASK;
                                    canMessage.type = CANData;
                                    canMessage.len = length;
                                    
                                    writeMessage(canMessage);
                                }
                                
                            } else {
                                
                                // wrong transmission type, 253 instead of 1
                            }
                            
                        } else {
                            
                            // TxPDO 2 is not valid
                        }
                        
                        // process TxPDO 3
                        
                        if ((objectDictionary.cobIDTransmitPDO3 & PDO_VALID_MASK) == 0) {
                            
                            if (objectDictionary.transmissionTypeTransmitPDO3 == 1) {
                                
                                uint8_t length = 8;
                                uint32_t abortCode = objectDictionary.readTxPDO(3, canMessage.data, length);
                                
                                if (abortCode == NO_COMMUNICATION_ERROR) {
                                    
                                    canMessage.id = objectDictionary.cobIDTransmitPDO3 & CAN_ID_MASK;
                                    canMessage.type = CANData;
                                    canMessage.len = length;
                                    
                                    writeMessage(canMessage);
                                }
                                
                            } else {
                                
                                // wrong transmission type, 253 instead of 1
                            }
                            
                        } else {
                            
                            // TxPDO 3 is not valid
                        }
                        
                        // process TxPDO 4
                        
                        if ((objectDictionary.cobIDTransmitPDO4 & PDO_VALID_MASK) == 0) {
                            
                            if (objectDictionary.transmissionTypeTransmitPDO4 == 1) {
                                
                                uint8_t length = 8;
                                uint32_t abortCode = objectDictionary.readTxPDO(4, canMessage.data, length);
                                
                                if (abortCode == NO_COMMUNICATION_ERROR) {
                                    
                                    canMessage.id = objectDictionary.cobIDTransmitPDO4 & CAN_ID_MASK;
                                    canMessage.type = CANData;
                                    canMessage.len = length;
                                    
                                    writeMessage(canMessage);
                                }
                                
                            } else {
                                
                                // wrong transmission type, 253 instead of 1
                            }
                            
                        } else {
                            
                            // TxPDO 4 is not valid
                        }
                        
                    } else {
                        
                        // wrong CANopen state for process data communication
                    }
                    
                } else if (canMessage.id == static_cast<uint32_t>(RSDO+objectDictionary.nodeID)) {
                    
                    // SDO request received
                    
                    if ((objectDictionary.canOpenNMTState == STATE_PRE_OPERATIONAL) || (objectDictionary.canOpenNMTState == STATE_OPERATIONAL)) {
                        
                        if ((canMessage.data[0] & (SDO_CCS_MASK | SDO_EXPEDITED_MASK | SDO_SIZE_SPECIFIED_MASK)) == (SDO_CCS_INIT_DOWNLOAD | SDO_EXPEDITED | SDO_SIZE_SPECIFIED)) {
                            
                            // write SDO into object dictionary
                            
                            uint8_t nodeID = objectDictionary.nodeID;
                            uint8_t length = 4-((canMessage.data[0] >> 2) & 0x03);
                            uint16_t index = static_cast<uint16_t>(canMessage.data[1]) | (static_cast<uint16_t>(canMessage.data[2]) << 8);
                            uint8_t subindex = canMessage.data[3];
                            
                            uint32_t abortCode = objectDictionary.writeObject(index, subindex, &(canMessage.data[4]), length);
                            if (abortCode == NO_COMMUNICATION_ERROR) {
                                
                                canMessage.id = TSDO+nodeID;
                                canMessage.type = CANData;
                                canMessage.len = 8;
                                canMessage.data[0] = 0x60;
                                canMessage.data[1] = static_cast<uint8_t>(index & 0xFF);
                                canMessage.data[2] = static_cast<uint8_t>((index >> 8) & 0xFF);
                                canMessage.data[3] = subindex;
                                canMessage.data[4] = 0;
                                canMessage.data[5] = 0;
                                canMessage.data[6] = 0;
                                canMessage.data[7] = 0;
                                
                                writeMessage(canMessage);
                                
                            } else {
                                
                                canMessage.id = TSDO+nodeID;
                                canMessage.type = CANData;
                                canMessage.len = 8;
                                canMessage.data[0] = 0x80;
                                canMessage.data[1] = static_cast<uint8_t>(index & 0xFF);
                                canMessage.data[2] = static_cast<uint8_t>((index >> 8) & 0xFF);
                                canMessage.data[3] = subindex;
                                canMessage.data[4] = static_cast<uint8_t>(abortCode & 0xFF);
                                canMessage.data[5] = static_cast<uint8_t>((abortCode >> 8) & 0xFF);
                                canMessage.data[6] = static_cast<uint8_t>((abortCode >> 16) & 0xFF);
                                canMessage.data[7] = static_cast<uint8_t>((abortCode >> 24) & 0xFF);
                                
                                writeMessage(canMessage);
                            }
                            
                        } else if ((canMessage.data[0] & SDO_CCS_MASK) == SDO_CCS_INIT_UPLOAD) {
                            
                            // read SDO from object dictionary
                            
                            uint16_t index = static_cast<uint16_t>(canMessage.data[1]) | (static_cast<uint16_t>(canMessage.data[2]) << 8);
                            uint8_t subindex = canMessage.data[3];
                            uint8_t buffer[4];
                            uint8_t length = 0;
                            
                            uint32_t abortCode = objectDictionary.readObject(index, subindex, buffer, length);
                            if (abortCode == NO_COMMUNICATION_ERROR) {
                                
                                canMessage.id = TSDO+objectDictionary.nodeID;
                                canMessage.type = CANData;
                                canMessage.len = 8;
                                canMessage.data[0] = SDO_CCS_INIT_UPLOAD | SDO_EXPEDITED | SDO_SIZE_SPECIFIED | ((4-length) << 2);
                                canMessage.data[1] = static_cast<uint8_t>(index & 0xFF);
                                canMessage.data[2] = static_cast<uint8_t>((index >> 8) & 0xFF);
                                canMessage.data[3] = subindex;
                                canMessage.data[4] = (length > 0) ? buffer[0] : 0x00;
                                canMessage.data[5] = (length > 1) ? buffer[1] : 0x00;
                                canMessage.data[6] = (length > 2) ? buffer[2] : 0x00;
                                canMessage.data[7] = (length > 3) ? buffer[3] : 0x00;
                                
                                writeMessage(canMessage);
                                
                            } else {
                                
                                canMessage.id = TSDO+objectDictionary.nodeID;
                                canMessage.type = CANData;
                                canMessage.len = 8;
                                canMessage.data[0] = 0x80;
                                canMessage.data[1] = static_cast<uint8_t>(index & 0xFF);
                                canMessage.data[2] = static_cast<uint8_t>((index >> 8) & 0xFF);
                                canMessage.data[3] = subindex;
                                canMessage.data[4] = static_cast<uint8_t>(abortCode & 0xFF);
                                canMessage.data[5] = static_cast<uint8_t>((abortCode >> 8) & 0xFF);
                                canMessage.data[6] = static_cast<uint8_t>((abortCode >> 16) & 0xFF);
                                canMessage.data[7] = static_cast<uint8_t>((abortCode >> 24) & 0xFF);
                                
                                writeMessage(canMessage);
                            }
                            
                        } else {
                            
                            // unknown SDO command specifier
                        }
                        
                    } else {
                        
                        // wrong CANopen state, ignore SDO request
                    }
                    
                } else {
                    
                    // unknown CAN ID
                }
            }
        }
        
        // try to write a CAN message from the output buffer to the CAN controller
        
        mutex.lock();
        
        if (canOutputBuffer.size() > 0) {
            
            CANMessage canMessage = canOutputBuffer.front();
            int32_t success = static_cast<int32_t>(can.write(canMessage));
            if (success) canOutputBuffer.pop_front();
        }
        
        mutex.unlock();
    }
}
