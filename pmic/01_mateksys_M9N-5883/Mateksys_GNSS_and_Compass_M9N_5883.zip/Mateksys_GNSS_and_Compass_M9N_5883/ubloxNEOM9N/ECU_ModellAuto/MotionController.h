/*
 * MotionController.h
 * Copyright (c) 2019, ZHAW
 * All rights reserved.
 *
 *  Created on: 03.10.2020
 *      Author: Jerome Perdrizat
 */

#ifndef MOTION_CONTROLLER_H
#define MOTION_CONTROLLER_H

#include <stdio.h>
#include <ctime>
#include <chrono>
#include <string>
#include <cmath>
#include <vector>
#include "mbed.h"


#include "Motion.h"

using namespace std;

class MotionController {
    public:
        MotionController(double pGain, double iGain, double dGain, double headingGain, double maxVelocity, double maxAcceleration, double maxDeceleration, double maxSteeringAngle);
        virtual ~MotionController();
        double getDistanceToTarget();
        //void updatePoseValues(double xPositionActualValue, double yPositionActualValue, double thetaActualValue);
        bool readyForNextPosition();
        void writeTargetPosition(double xPositionTargetValue, double yPositionTargetValue);
        void writeTargetVelocity(double velocity);
        bool controll(bool vEndIsZero, double periode, double &velecityTargetValue, double &thetaTargetValue);
        void setPoseActualValues(double xPositionActualValue, double yPositionActualValue, double thetaActualValue);

        void setPGain(double pGain);
        void setIGain(double iGain);
        void setDGain(double dGain);
        void setHeadingPGain(double headingPGain); 




    private:

        static constexpr double MAX_VELOCITY_RATIO_CONTRIBUTED_BY_INTEGRATOR = 2; //Maximal velocity reachable only by integrator

        double xPositionActualValue;
        double yPositionActualValue;
        double xPositionLastValue;
        double yPositionLastValue;
        double xPositionTargetValue;
        double yPositionTargetValue;
        double thetaActualValue;
        double profileVelocity;

        double radiusAroundTargetToBeReadyForNextPosition;

        double pGain;
        double iGain;
        double dGain;
        double headingPGain;
        double errorIntegrated;

        double maxVelocity;
        double maxAcceleration;
        double maxDeceleration;
        double maxSteeringAngle;

        Motion xMotionPlaner;
        Motion yMotionPlaner;


};

#endif // MOTION_CONTROLLER_H
