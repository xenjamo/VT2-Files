# ECU Firmware - 2021
ECU Firmware for the NUCLEO-767ZI. This new version implement a CANopen stack substituing the TCP/IP stack used till now