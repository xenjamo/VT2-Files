/*
 * MotionEstimation.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 05.05.2021
 *      Author: Nicolas Borla
 */

#ifndef MOTION_ESTIMATION_H
#define MOTION_ESTIMATION_H

#include <cstdlib>
#include <stdint.h>
#include <string>
#include "EncoderF767ZI.h"
#include "Mutex.h"
#include "OpenIMU300ZI.h"
#include "PX4Flow.h"
#include "NEOM9N.h"
#include "Servo.h"
#include "LowpassFilter.h"
#include "mbed.h"
#include "ThreadFlag.h"

#include <array>
#include <iostream>
#include <deque>



using namespace std;

/**
 * The <code>MotionEstimation</code> class implement the speed estimation of the car.
 */
class MotionEstimation {
    
    public:

                            MotionEstimation(EncoderCounter &rearLeftCounter, EncoderCounter &rearRightCounter, 
                                            OpenIMU300ZI &imu, PX4Flow &px4flow, NEOM9N &neom9n,
                                            Servo &throttle, Servo &steering,
                                            int nData = 0, float *Mes = nullptr);
        virtual             ~MotionEstimation();

        void        startMeasurement();
        void        resetMeasurement();
        void        saveMeasurement();
        float       getTranslationalVelocity();
        float       getRotationalVelocity();
        

        bool        startMeasure;

        float       calculationTime;
        
    private:

        static const uint32_t   STACK_SIZE = 4096;                  // stack size of thread, given in [bytes]
        static constexpr float  PERIOD = 0.005;
        static constexpr float  LOWPASS_FILTER_FREQUENCY = 300.0f;  // frequency of lowpass filter for actual speed values, given in [rad/s]
        static constexpr float  COUNTS_PER_TURN = 25600.0f;         // resolution of encoder counter
        static constexpr float  PI = 3.14159265f;                   // the constant PI
        static constexpr float  WHEEL_RADIUS = 0.064f;              // radius of wheels, given in [m]
        static constexpr float  MAX_MOTOR_CURRENT = 60.0;           // maximal motor current, set in vesc motor controller in [N] = 0.064f;              // radius of wheels, given in [m]
        static constexpr float  RAD_PER_PWM = -0.2386;              // steering angle in [rad] per normed pwm of servo in [1] = 0.064f;              // radius of wheels, given in [m]


        void        prediction(double x[3],double P[3][3], double u[3], double Q[3][3], double xPred[3], double PPred[3][3]);
        void        correction(double xPred[3], double PPred[3][3], double z[3], double R[3][3], double xCorr[3], double PCorr[3][3]);
        void        correctionGNSS(double xPred[3], double PPred[3][3], double z, double R, double xCorr[3], double PCorr[3][3]);
        void        printMatrix3(double A[3][3]);
        void        printVector3(double A[3]);
        void        matInverse(double A[3][3],double A_inv[3][3]);

        EncoderCounter      &rearLeftCounter;
        EncoderCounter      &rearRightCounter; 
        OpenIMU300ZI        &imu;
        PX4Flow             &px4flow;
        NEOM9N              &neom9n;
        Servo               &throttle;
        Servo               &steering;

        short               previousValueCounterRearLeft;
        short               previousValueCounterRearRight;
        LowpassFilter       speedRearLeftFilter;
        LowpassFilter       speedRearRightFilter;
        float               actualSpeedRearLeft;
        float               actualSpeedRearRight;
        float               actualAngleRearLeft;
        float               actualAngleRearRight;
        float               actualTranslationalVelocity;
        float               actualRotationalVelocity;

        // pointer to measurement objects
        int                 nData;
        float               *Mes;
        Timer               timer;
        
        int                 measureIndex;
        int                 fileIndex=0;
        bool                measureSaved = false;


        

        ThreadFlag          threadFlag;
        Thread              thread;
        Ticker              ticker;
        Mutex               mutex;
        
        void                sendThreadFlag();
        void                run();

};

#endif /* MOTION_ESTIMATION_H */
