/*
 * CANopen.h
 * Copyright (c) 2017, ZHAW
 * All rights reserved.
 *
 *  Created on: 16.11.2017
 *      Author: Marcel Honegger
 */

#ifndef CAN_OPEN_H_
#define CAN_OPEN_H_

#include <cstdlib>
#include <deque>
#include <stdint.h>
#include <mbed.h>
#include "ThreadFlag.h"

class ObjectDictionary;

/**
 * The <code>CANopen</code> class implements a simple CANopen slave stack.
 */
class CANopen {
    
    public:
        
        static const uint8_t    STATE_INITIALISATION = 0x00;    /**< CANopen network management state. */
        static const uint8_t    STATE_PRE_OPERATIONAL = 0x7F;   /**< CANopen network management state. */
        static const uint8_t    STATE_OPERATIONAL = 0x05;       /**< CANopen network management state. */
        static const uint8_t    STATE_STOPPED = 0x04;           /**< CANopen network management state. */
        
        static const uint16_t   NMT = 0x000;        /**< CANopen function code. */
        static const uint16_t   SYNC = 0x080;       /**< CANopen function code. */
        static const uint16_t   EMERGENCY = 0x080;  /**< CANopen function code. */
        static const uint16_t   TPDO1 = 0x180;      /**< CANopen function code. */
        static const uint16_t   RPDO1 = 0x200;      /**< CANopen function code. */
        static const uint16_t   TPDO2 = 0x280;      /**< CANopen function code. */
        static const uint16_t   RPDO2 = 0x300;      /**< CANopen function code. */
        static const uint16_t   TPDO3 = 0x380;      /**< CANopen function code. */
        static const uint16_t   RPDO3 = 0x400;      /**< CANopen function code. */
        static const uint16_t   TPDO4 = 0x480;      /**< CANopen function code. */
        static const uint16_t   RPDO4 = 0x500;      /**< CANopen function code. */
        static const uint16_t   TSDO = 0x580;       /**< CANopen function code. */
        static const uint16_t   RSDO = 0x600;       /**< CANopen function code. */
        static const uint16_t   NODEGUARD = 0x700;  /**< CANopen function code. */
        
        static const uint32_t   CAN_ID_MASK = 0x000007FF;           /**< Bitmask for the CAN ID. */
        static const uint32_t   FUNCTION_CODE_MASK = 0x00000780;    /**< Bitmask for the CANopen function code. */
        static const uint32_t   NODE_ID_MASK = 0x0000007F;          /**< Bitmask for the CANopen node ID. */
        static const uint32_t   PDO_VALID_MASK = 0x80000000;        /**< Bitmask to check if this PDO is valid. */
        static const uint32_t   RTR_ALLOWED_MASK = 0x40000000;      /**< Bitmask to ckeck if RTR requests on this PDO are allowed. */
        
        static const uint8_t    START_REMOTE_NODE = 0x01;           /**< NMT command specifier. */
        static const uint8_t    STOP_REMOTE_NODE = 0x02;            /**< NMT command specifier. */
        static const uint8_t    ENTER_PRE_OPERATIONAL_STATE = 0x80; /**< NMT command specifier. */
        static const uint8_t    RESET_NODE = 0x81;                  /**< NMT command specifier. */
        static const uint8_t    RESET_COMMUNICATION = 0x82;         /**< NMT command specifier. */
        
        static const uint32_t   NO_COMMUNICATION_ERROR = 0x00000000;        /**< Communication Error (Abort Code). */
        static const uint32_t   ACCESS_ERROR = 0x06010000;                  /**< Communication Error (Abort Code). */
        static const uint32_t   WRITE_ONLY = 0x06010001;                    /**< Communication Error (Abort Code). */
        static const uint32_t   READ_ONLY = 0x06010002;                     /**< Communication Error (Abort Code). */
        static const uint32_t   OBJECT_DOES_NOT_EXIST_ERROR = 0x06020000;   /**< Communication Error (Abort Code). */
        static const uint32_t   PDO_MAPPING_ERROR = 0x06040041;             /**< Communication Error (Abort Code). */
        static const uint32_t   PDO_LENGTH_ERROR = 0x06040042;              /**< Communication Error (Abort Code). */
        static const uint32_t   SUBINDEX_DOES_NOT_EXIST = 0x06090011;       /**< Communication Error (Abort Code). */
        static const uint32_t   VALUE_RANGE_ERROR = 0x06090030;             /**< Communication Error (Abort Code). */
        static const uint32_t   VALUE_TOO_HIGH_ERROR = 0x06090031;          /**< Communication Error (Abort Code). */
        static const uint32_t   VALUE_TOO_LOW_ERROR = 0x06090032;           /**< Communication Error (Abort Code). */
        static const uint32_t   GENERAL_ERROR = 0x08000000;                 /**< Communication Error (Abort Code). */
        static const uint32_t   TRANSFER_OR_STORE_ERROR = 0x08000020;       /**< Communication Error (Abort Code). */
        static const uint32_t   WRONG_DEVICE_STATE = 0x08000022;            /**< Communication Error (Abort Code). */
        static const uint32_t   WRONG_NMT_STATE_ERROR = 0x0F00FFC0;         /**< Communication Error (Abort Code). */
        
                        CANopen(CAN& can, ObjectDictionary& objectDictionary);
        virtual         ~CANopen();
        void            transmitEmergencyMessage(uint16_t errorCode, uint8_t errorRegister);
        
    private:
        
        static const uint8_t    SDO_CCS_MASK = 0xE0;
        static const uint8_t    SDO_CCS_INIT_DOWNLOAD = 0x20;
        static const uint8_t    SDO_CCS_INIT_UPLOAD = 0x40;
        static const uint8_t    SDO_CCS_ABORT = 0x80;
        static const uint8_t    SDO_LENGTH_MASK = 0x0C;
        static const uint8_t    SDO_EXPEDITED_MASK = 0x02;
        static const uint8_t    SDO_EXPEDITED = 0x02;
        static const uint8_t    SDO_SIZE_SPECIFIED_MASK = 0x01;
        static const uint8_t    SDO_SIZE_SPECIFIED = 0x01;
        
        static const uint8_t    CAN_OUTPUT_BUFFER_SIZE = 20;    // max. number of outgoing CAN messages to buffer
        
        static const uint32_t   STACK_SIZE = 8192;          // stack size of thread, given in [bytes]
        static const float      PERIOD;                     // the period of the timer interrupt, given in [s]
        
        CAN&                    can;                        // reference to the CAN device driver
        ObjectDictionary&       objectDictionary;           // reference to the CANopen object dictionary of this device
        Timer                   producerHeartbeatTimer;     // timer reset when a heartbeat message was transmitted
        Timer                   consumer1HeartbeatTimer;    // timer reset when a heartbeat message was received
        deque<CANMessage>       canOutputBuffer;            // ouput queue for CAN messages
        Mutex                   mutex;
        ThreadFlag              threadFlag;
        Thread                  thread;
        Ticker                  ticker;
        
        void        writeMessage(CANMessage& canMessage);
        void        sendThreadFlag();
        void        run();
};

#endif /* CAN_OPEN_H_ */
