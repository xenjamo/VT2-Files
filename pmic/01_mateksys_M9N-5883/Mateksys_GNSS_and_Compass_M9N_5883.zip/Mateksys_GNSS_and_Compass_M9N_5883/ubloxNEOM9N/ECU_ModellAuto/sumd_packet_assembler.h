
#ifndef SUMD_PACKET_ASSEMBLER_H_
#define SUMD_PACKET_ASSEMBLER_H_

#include <cstdlib>
#include <mbed.h>


#define MAX_CHANNELS 32
#define HEADER_LENGTH 3
#define MAX_VALUE_LENGTH (2 * MAX_CHANNELS)
#define CRC_LENGTH 2
#define MAX_DATA_LENGTH (HEADER_LENGTH + MAX_VALUE_LENGTH + CRC_LENGTH)

class SumdUnmarshaler {
 public:
  explicit SumdUnmarshaler(uint8_t vendor_id);

  void digestValue(uint8_t value);

  bool IsFailsafe() const;

  bool HasNewValues();

  uint8_t GetChannelCount() const ;
  uint16_t GetChannelValue(uint8_t channel) const;

 private:
  enum State {
    STATE_READ_VENDOR_ID,
    STATE_READ_HEADER,
    STATE_READ_VALUES,
    STATE_READ_CRC,
  };

  static const uint16_t GRAUPNER_ID = 0xA8;

  void AddValue(uint8_t value);
  void SetState(State state, uint8_t value);
  bool CheckCrc();
  void CopyChannelValues();
  uint16_t CalculateCrc(uint16_t crc);
  void Crc(uint8_t value);

  const uint8_t vendor_id_;
  State state_;
  uint8_t index_;
  uint8_t byte_count_;
  uint16_t crc_;
  uint8_t crc_start_offset_;
  uint8_t raw_data_[MAX_DATA_LENGTH];

  bool has_new_values_;
  bool is_fail_safe_;
  uint8_t channel_count_;
  uint16_t channel_values_[MAX_CHANNELS];
};

#endif  // SUMD_PACKET_ASSEMBLER_H_
