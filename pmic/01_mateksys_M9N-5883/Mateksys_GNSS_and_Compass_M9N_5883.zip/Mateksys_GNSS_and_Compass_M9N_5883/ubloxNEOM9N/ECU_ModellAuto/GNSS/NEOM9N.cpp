/*
 * NEOM9N.cpp
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 05.05.2021
 *      Author: Nicolas Borla
 */

#include "NEOM9N.h"
#include <cstdio>

using namespace std;

/**
 * Creates and initializes the driver to read the GNSS sensor
 * @param TX the input pin for the Serial comunication TX.
 * @param RX the input pin for the Serial comunication RX.
 */
NEOM9N::NEOM9N(PinName TX, PinName RX):thread(osPriorityHigh, STACK_SIZE) {
    this->TX = TX;
    this->RX = RX;

    // initialise serial comunication
    this->pGnss = new GnssSerial(TX,RX);
    // initialise
    pGnss->init();
    memset(buffer, 0, sizeof(buffer));
/*
    timingMonitor.reset();
    timingMonitor.start();

    // start periodic task
    thread.start(callback(this, &NEOM9N::run));
    ticker.attach(callback(this, &NEOM9N::sendThreadFlag), PERIOD);
    */
}

NEOM9N::~NEOM9N() {
    pGnss->~GnssSerial();
    }

/**
 * This method return the velocity towards North in NED Coordinate system
 */
float NEOM9N::getSpeedN() {
    
    float speed = static_cast<float>(actualPVT.velN/1000.0); //[m/s]
    return speed;
}

/**
 * This method i...
 */
float NEOM9N::getSpeedE() {
    
    float speed = static_cast<float>(actualPVT.velE/1000.0); //[m/s]
    return speed;
}

/**
 * This method i...
 */
float NEOM9N::getSpeedD() {
    
    float speed = static_cast<float>(actualPVT.velD/1000.0); //[m/s]
    return speed;
}

/**
 * This method return the ground speed of the veichle, the velocity in the veichle direction
 */
float NEOM9N::getSpeed() {
    
    float speed = static_cast<float>(actualPVT.speed/1000.0); //[m/s]
    return speed;
}

/**
 * This method i...
 */
float NEOM9N::getHeading() {
    
    float heading = static_cast<float>(actualPVT.headMot/100000.0)/180.0*M_PI; //[rad]
    return heading;
}

/**
 * This method i...
 */
void NEOM9N::get2DMotion(float& speed, float& heading, float& speedAccuracy, float& headingAccuracy) {
    
    speed = static_cast<float>(actualPVT.speed/1000.0); //[m/s];
    heading = static_cast<float>(actualPVT.headMot/100000.0)/180.0*M_PI; //[rad]
    speedAccuracy = static_cast<float>(actualPVT.sAcc/1000.0); //[m/s];
    headingAccuracy = static_cast<float>(actualPVT.headAcc/100000.0)/180.0*M_PI; //[rad]
    
}

/**
 * This method return the latitude in [°]
 */
float NEOM9N::getLat() {
    
    float lat = static_cast<float>(actualPVT.lat/10000000.0); //[°]
    return lat;
}

/**
 * This method return the longitude in [°]
 */
float NEOM9N::getLon() {
    
    float lon = static_cast<float>(actualPVT.lon/10000000.0); //[°]
    return lon;
}

/**
 * This method return the number of satellites connected to the reciver
 */
int NEOM9N::getNumSat() {
    
    int numberOfSatellites = actualPVT.numSV;
    return numberOfSatellites;
}

/**
 * This method return the GPS time of week of the navigation epoch. (See ublox integration manual)
 */
int NEOM9N::getSatTime() {
    
    int GNSStime = actualPVT.itow; // [ms]
    return GNSStime;
}


/**
 * This method is called by the ticker timer interrupt service routine.
 * It sends a flag to the thread to make it run again.
 */
void NEOM9N::sendThreadFlag() {
    
    thread.flags_set(threadFlag);
}

/**
 * Get last message
 */
int NEOM9N::update() {

    if (((returnCode = pGnss->getMessage(buffer, sizeof(buffer))) > 0) && (PROTOCOL(returnCode) == GnssSerial::UBX) )
    {
        if(buffer[0]==0xb5 && buffer[1]==0x62 && buffer[2]==0x01 && buffer[3]==0x07) // UBX-NAV-PVT Recived
        {
            actualPVT = pGnss->decode_ubx_nav_pvt_msg(buffer);
            return 1;
        }
    }

    return 0;
}

/**
 * Run method
 */
void NEOM9N::run() {
    
    while(true)
    {
        //printf("last return code: %d\r\n",returnCode);

        // wait for the periodic thread flag
        ThisThread::flags_wait_any(threadFlag);

        timingMonitor.reset();

        while (((returnCode = pGnss->getMessage(buffer, sizeof(buffer))) > 0) )
        {
            if ((PROTOCOL(returnCode) == GnssSerial::UBX)) 
            {
                if(buffer[0]==0xb5 && buffer[1]==0x62 && buffer[2]==0x01 && buffer[3]==0x07) // UBX-NAV-PVT Recived
                {
                    actualPVT = pGnss->decode_ubx_nav_pvt_msg(buffer);
                }
            }
        }

        threadExtime = timingMonitor.read_us();
    }

}