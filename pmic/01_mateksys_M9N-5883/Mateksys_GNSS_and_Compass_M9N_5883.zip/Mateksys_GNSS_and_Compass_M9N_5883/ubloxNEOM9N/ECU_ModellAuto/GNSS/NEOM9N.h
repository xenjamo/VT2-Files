/*
 * NEOM9N.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 05.05.2021
 *      Author: Nicolas Borla
 */

#ifndef NEOM9N_H
#define NEOM9N_H

#include <cstdlib>
#include <stdint.h>
#include <string>
#include "PinNames.h"
#include "Timer.h"
#include "mbed.h"
#include "ThreadFlag.h"
#include "gnss.h"


using namespace std;

/**
 * The <code>NEOM9N</code> class implement a serial comunication with the GNSS Module NEO-M9N.
 */
class NEOM9N {
    
    public:

                            NEOM9N(PinName TX, PinName RX);
        virtual             ~NEOM9N();
        //void                init(uint16_t index);

        struct UBX_NAV_PVT actualPVT;
        float               getSpeedN();
        float               getSpeedE();
        float               getSpeedD();
        float               getSpeed();
        float               getHeading();
        void                get2DMotion(float& speed, float& heading, float& speedAccuracy, float& headingAccuracy);
        int                 getNumSat();
        float               getLat();
        float               getLon();
        int                 getSatTime();
        int                 update();

        int threadExtime;

    private:

        static const uint32_t   STACK_SIZE = 4096;      // stack size of thread, given in [bytes]
        static constexpr float  PERIOD = 0.005;
        static constexpr float  M_PI = 3.14159265f;     // the constant PI

        PinName             TX;
        PinName             RX;

        GnssSerial          *pGnss;
        char                buffer[256];
        int                 returnCode;
        Timer               timingMonitor;
        
        

        ThreadFlag          threadFlag;
        Thread              thread;
        Ticker              ticker;
        
        void                sendThreadFlag();
        void                run();

};

#endif /* NEOM9N_H */
