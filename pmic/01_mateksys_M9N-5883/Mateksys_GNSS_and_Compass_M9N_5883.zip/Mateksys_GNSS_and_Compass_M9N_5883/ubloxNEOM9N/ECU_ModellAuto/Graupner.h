/*
 * Graupner.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 19.05.2021
 *      Author: Nicolas Borla
 */

#ifndef GRAUPNER_H_
#define GRAUPNER_H_

#include <cstdint>
#include <cstdlib>
#include <mbed.h>
#include <string>
#include <Callback.h>
#include <vector>
#include "RawSerial.h"
#include "ThreadFlag.h"

#include "Timer.h"
#include "sumd_packet_assembler.h"

/**
 * This class implements a single wheel of the car. It's responsible to check the encoder in a good time interval
 */
class GraupnerReciver {
    
    public:
        
                    GraupnerReciver(RawSerial& serial);
        virtual     ~GraupnerReciver();

        float       getChannelValue(uint8_t channel);
        float       getQuality();
        int         getWatchdogTime();



        static const uint8_t    THROTTLE_CHANNEL = 0;  //Ginen in the setting of the remotcontrol. Caution the remotecontroll is 1 based (and not 0 based)!
        static const uint8_t    STEERING_CHANNEL = 1; //Ginen in the setting of the remotcontrol. Caution the remotecontroll is 1 based (and not 0 based)!
        static const uint8_t    BREAK_CHANNEL = 3; //Ginen in the setting of the remotcontrol. Caution the remotecontroll is 1 based (and not 0 based)!
        static const uint8_t    MEASUREMENT_CHANNEL = 5; //Ginen in the setting of the remotcontrol. Caution the remotecontroll is 1 based (and not 0 based)!
        static const uint8_t    ENABLE_CHANNEL = 7; //Ginen in the setting of the remotcontrol. Caution the remotecontroll is 1 based (and not 0 based)!
        static const uint8_t    MODE_CHANNEL = 6; //Ginen in the setting of the remotcontrol. Caution the remotecontroll is 1 based (and not 0 based)!
        
    private:

        void receiveData();

        static const int32_t    BAUD_RATE_GRAUPNER_SUMD_PROTOCOLL = 115200;
        static const int8_t     LENGTH_OF_HEADER = 3;                       //Length of the header of each transmission
        static const int8_t     LENGTH_OF_CRC = 2;                          //Length of the checksum after each transmission
        static const int8_t     NUMBER_OF_CHANNELS = 8;                     //Number of channels of receiver
        static const int16_t    SIZE_RING_BUFFER = 3*(LENGTH_OF_HEADER+LENGTH_OF_CRC+2*NUMBER_OF_CHANNELS)+1; //Buffer 3 periodes of received values
        static const uint8_t    PERIODE_OF_SIGNAL = 10;                     //Perode of the signal in ms (given by the sumd protocoll)
        static const uint8_t    MAX_NUMBER_OF_FAILED_TRANSMISSONS = 50;     //After this amount of fails in a series, the device will enter state FAULT
        static const uint16_t   MAX_TIME_NO_NEW_DATA_RECEIVED = 200;        //In any case the system is running: After this time without new serial data it changes to STATE_FAULT

        /* Following values are given by SUMD protocoll of Graupner */
        static const uint8_t    GRAUPNER_ID = 0xA8;                         //ID of Grauper, this value starts the data string
        static const uint8_t    FRAME_IS_VALID = 0x01;                      //Got a valid frame
        static const uint8_t    IS_FAIL_SAVE_MODE = 0x81;                   //Receiver is in fail save mode (no connection to controller)
        static const uint16_t   CRC_POLYNOME =  0x1021;                     //CRC Polynome for Received packet

        constexpr static const float      MIN_GRAUPNER_VALUE = 8800;                  //minimum value, read from receiver, considered as -1.0
        constexpr static const float      MAX_GRAUPNER_VALUE = 15200;                 //maximum value, read from receiver, considered as +1.0

        static constexpr float  PERIOD = 0.005;
        

        RawSerial&       serial;
        //SumdUnmarshaler interpreter;
        
        uint16_t        channelData[NUMBER_OF_CHANNELS];
        uint8_t         data[21];
        int             dataCounter;
        int             validRecivedCount;
        int             messageRecivedCount;
        float           quality;

        Timer           watchDogTimer;

};

#endif /* GRAUPNER_H_ */