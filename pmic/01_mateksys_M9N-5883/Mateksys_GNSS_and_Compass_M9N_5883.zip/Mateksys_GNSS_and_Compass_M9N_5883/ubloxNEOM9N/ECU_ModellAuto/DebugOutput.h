/*
 * DebugOutput.h
 * Copyright (c) 2020, ZHAW
 * All rights reserved.
 */

#ifndef DEBUG_OUTPUT_H_
#define DEBUG_OUTPUT_H_

#include <cstdlib>
#include <mbed.h>
#include <string>
#include <vector>


/**
 * This class gives an interface for a debug output. This could be any serial interface. 
 * All messages are just attached in a que and ploted to the interface
 */
class DebugOutput: public Thread{
    
    public:
        
                    DebugOutput(Serial &targetInterface, string name);
        virtual     ~DebugOutput();

        void        write(string message);

      
                    
        
    private:

        static const int16_t    PERIODE_OF_THREAD = 10;         //Periode with which the server will be updated


        Serial          &interface;
        vector<string>  que;
        string          name;
        Mutex           vectorMutex;


        State           state;
        bool            entryState;
        bool            exitState;
        bool            switchOnSet;
        bool            switchOffSet;

        void run ();
};

#endif /* SERVER_JETSON_H_ */