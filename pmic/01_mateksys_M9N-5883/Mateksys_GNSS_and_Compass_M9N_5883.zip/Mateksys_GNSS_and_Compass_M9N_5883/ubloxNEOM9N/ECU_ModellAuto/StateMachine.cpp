/*
 * StateMachine.cpp
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 03.03.2021
 *      Author: Jonas Langenegger
 */

#include "StateMachine.h"
#include "DigitalIn.h"
#include "Graupner.h"
#include "MotionEstimation.h"
#include "ObjectDictionary.h"
#include "ThisThread.h"
#include <cstdint>
#include <cstdio>
#include <string>

using namespace std;

const float StateMachine::PERIOD = 0.001f;                              // the period of the timer interrupt, given in [s]
const float StateMachine::INIT_TIME = 3000; 
const float StateMachine::MAXIMAL_MANUAL_ACCELERATION = 12.0f;           // Equivilant to max current. Maximal manual acceleration im [m/s²] which is proportional to the motor current
const float StateMachine::MAXIMAL_MANUAL_DECELERATION = 12.0f;           // maximal manual acceleration im [m/s²] which is proportional to the motor current
const float StateMachine::MAXIMAL_MANUAL_TRANSLATIONAL_VELOCITY = 12.0f; 
const float StateMachine::RAD_PER_PWM = -0.2386;                        // steering angle in [rad] per normed pwm of servo in [1]
const int   StateMachine::RECEIVER_WATCHDOG_TIMEOUT = 500;              // max time in ms for the receiver to get valid messages, otherweise emergency

/**
 * Creates a TiltAngle object.
 * @param imu a reference to the IMU to use.
 */
StateMachine::StateMachine(Controller& controller, GraupnerReciver& receiver, DigitalIn& emergencyButtonReleased, 
                            DigitalOut& green1, DigitalOut& green2, DigitalOut& orange, DigitalOut& red, Servo& brakeServo,
                            ObjectDictionary& objectDictionary, MotionEstimation& motionEstimation, DigitalIn& blueButton,
                            int nData, float *Mes) : 
                            controller(controller), receiver(receiver), emergencyButtonReleased(emergencyButtonReleased), 
                            green1(green1), green2(green2), orange(orange), red(red), brakeServo(brakeServo),
                            objectDictionary(objectDictionary), motionEstimation(motionEstimation), blueButton(blueButton),
                            thread(osPriorityNormal, STACK_SIZE) {
    
    // initialize local values
    stateDemand = OFF;
    state = INIT;         

    remoteSteeringAngle = 0.0f;
    remoteSteeringAngleVelocity = 0.0f;
    remoteTranslationalVelocity = 0.0f;
    remoteTranslationalAcceleration = 0.0f;

    // initialize timer
    startupTimer.start(); startupTimer.reset();

    // initalize
    brakeServo.writeValue(0.1); // brake vehicle
    red.write(1);

    // measurement variables
    this->nData = nData;
    this->Mes = Mes;
    
    // start thread and timer interrupt
    thread.start(callback(this, &StateMachine::run));
    ticker.attach(callback(this, &StateMachine::sendThreadFlag), PERIOD);
}

/**
 * Deletes the TiltAngle object.
 */
StateMachine::~StateMachine() {
    
    ticker.detach();
}

/**
 * Sets the a demanded state to the state machine
 * @param stateDemand demanded state.
 */
void StateMachine::setState(int16_t stateDemand) {

    this->stateDemand = stateDemand;
}

/**
 * Gets the actual state of the state machine
 */
int16_t StateMachine::getState() {

    return state;
}

/**
 * Sets the desired remote ackermann steering angle
 */
void StateMachine::setRemoteSteeringAngle(float steeringAngle) {

    remoteSteeringAngle = steeringAngle;
}

/**
 * Sets the desired remote ackermann steering angle velocity
 */
void StateMachine::setRemoteSteeringAngleVelocity(float steeringAngleVelocity) {

    remoteSteeringAngleVelocity = steeringAngleVelocity;
}

/**
 * Sets the desired remote ackermann velocity
 */
void StateMachine::setRemoteVelocity(float velocity) {

    remoteTranslationalVelocity = velocity;
}

/**
 * Sets the desired remote ackermann steering angle
 */
void StateMachine::setRemoteAcceleration(float acceleration) {

    remoteTranslationalAcceleration = acceleration;
}

/**
 * This method is called by the ticker timer interrupt service routine.
 * It sends a flag to the thread to make it run again.
 */
void StateMachine::sendThreadFlag() {
    
    thread.flags_set(threadFlag);
}

/**
 * This <code>run()</code> method contains an infinite loop with the run logic.
 */
void StateMachine::run() {

    // initialize variables used in stateMachine
    bool validRcSignal = false;
    float modeChannel = 0.0f;
    float enableChannel = 0.0f;
    bool emergencyStopReleased = false;
    float translationalVelocity = 0.0f;
    float manualSteeringAngle = 0.0f;
    float manualCurrent = 0.0f; 
    float manualTranslationalVelocity = 0.0f;

    int16_t stateController = 0;

    while (true) {
        
        // wait for the periodic thread flag
        ThisThread::flags_wait_any(threadFlag);
        
        // update target values
        this->setRemoteSteeringAngle(static_cast<double>(objectDictionary.desiredSteeringAngle.read()/1000.0));
        this->setRemoteSteeringAngleVelocity(static_cast<double>(objectDictionary.desiredSteeringSpeed.read()/1000.0));
        this->setRemoteVelocity(static_cast<double>(objectDictionary.desiredTranslationalVelocity.read()/1000.0));
        this->setRemoteAcceleration(static_cast<double>(objectDictionary.desiredTranslationalAcceleration.read()/1000.0));
        //printf("Ackerman: steering=%f, steeringSpeed=%f, speed=%f, acceleration=%f \r\n",remoteSteeringAngle, remoteSteeringAngleVelocity, remoteTranslationalVelocity, remoteTranslationalAcceleration);


        // Do the logic

        switch (state) {



            case INIT:

                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;

                if (startupTimer.read_ms() > INIT_TIME && blueButton) {
                    state = OFF;
                    red.write(0);
                    startupTimer.reset();
                }

                break;

            case OFF:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);

                if (blueButton && startupTimer.read_ms() > 1000) {
                    state = TURN_ON;
                    controller.turnOn();
                    brakeServo.writeValue(-1.5); // release brake
                    startupTimer.reset();

                }

                break;
            
            case ON:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                modeChannel = receiver.getChannelValue(GraupnerReciver::MODE_CHANNEL);

                
                state = AUTONOMOUS;
                controller.setControllerMode(Controller::AUTONOMOUS);
                startupTimer.reset();
            

                break;

            case TURN_ON:

                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                emergencyStopReleased = emergencyButtonReleased.read();
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);
                stateController = controller.getState();

                if ( stateController == Controller::ON && blueButton && startupTimer.read_ms() > 1000) {
                    state = ON;
                    orange.write(1);
                    startupTimer.reset();
                }

                break;

            case TURN_OFF:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                translationalVelocity = controller.getActualTranslationalVelocity();
                stateController = controller.getState();

                //change this to entry....
                brakeServo.writeValue(0.05); // brake vehicle

                if (!emergencyStopReleased && translationalVelocity < 0.5f && stateController == Controller::OFF) {
                    state = EMERGENCY;
                    orange.write(0);
                    red.write(1);
                } else if (validRcSignal && translationalVelocity < 0.5f && stateController == Controller::OFF) {
                    state = OFF;
                    red.write(0);
                    orange.write(0);
                }

                break;

            case MANUAL:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);
                modeChannel = receiver.getChannelValue(GraupnerReciver::MODE_CHANNEL);

                manualSteeringAngle = receiver.getChannelValue(GraupnerReciver::STEERING_CHANNEL)*RAD_PER_PWM;
                if (receiver.getChannelValue(GraupnerReciver::THROTTLE_CHANNEL) > 0.0) manualCurrent = receiver.getChannelValue(GraupnerReciver::THROTTLE_CHANNEL)*MAXIMAL_MANUAL_ACCELERATION;
                else manualCurrent = receiver.getChannelValue(GraupnerReciver::THROTTLE_CHANNEL)*MAXIMAL_MANUAL_DECELERATION;
                controller.setCommands(manualSteeringAngle, 0.0f, manualCurrent);
                
                if (!validRcSignal || !emergencyStopReleased || enableChannel < 0.5f) {
                    state = TURN_OFF;
                    controller.turnOff();
                    controller.setCommands(0.0f, 0.0f, 0.0f);
                } else if (modeChannel > -0.5) {
                    state = ON;
                    orange.write(1);
                    controller.setCommands(0.0f, 0.0f, 0.0f);
                } else if(receiver.getChannelValue(GraupnerReciver::MEASUREMENT_CHANNEL) > 0) {

                    printf("START\r\n");
                    motionEstimation.resetMeasurement();
                    motionEstimation.startMeasurement();
                    green1.write(1);
                    ThisThread::sleep_for(200);
                }
            
                break;

            case SEMI_AUTONOMOUS:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);
                modeChannel = receiver.getChannelValue(GraupnerReciver::MODE_CHANNEL);

                // ONLY FOR TESTING SPEEDCONTROLLER - USE REMOTE TO STEER CAR
                manualSteeringAngle = receiver.getChannelValue(GraupnerReciver::STEERING_CHANNEL)*RAD_PER_PWM;
                //manualSteeringAngle = remoteSteeringAngle;
                manualTranslationalVelocity = receiver.getChannelValue(GraupnerReciver::THROTTLE_CHANNEL)*MAXIMAL_MANUAL_TRANSLATIONAL_VELOCITY;
                controller.setCommands(manualSteeringAngle, manualTranslationalVelocity, 0.0f);

                if (!validRcSignal || !emergencyStopReleased || enableChannel < 0.5f) {
                    state = TURN_OFF;
                    controller.turnOff();
                    controller.setCommands(0.0f, 0.0f, 0.0f);
                } else if ( (modeChannel < -0.5) || (modeChannel > 0.5) ) {
                    state = ON;
                    orange.write(1);
                    controller.setCommands(0.0f, 0.0f, 0.0f);
                }
            
                break;

            case AUTONOMOUS:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);
                modeChannel = receiver.getChannelValue(GraupnerReciver::MODE_CHANNEL);

                
                //remoteSteeringAngle = 0.0f;
                //remoteTranslationalVelocity = 0.0f;
                //remoteTranslationalAcceleration = 0.0f;
                // Set values from CANOpen stack...
                controller.setCommands(remoteSteeringAngle, remoteTranslationalVelocity, remoteTranslationalAcceleration);

                if (blueButton.read() && startupTimer.read_ms() > 3000) {
                    state = TURN_OFF;
                    controller.turnOff();
                    controller.setCommands(0.0f, 0.0f, 0.0f); // set steering angle, velocity and acceleration zero..
                    startupTimer.reset();
                } else if ( false ) { //validRcSignal && modeChannel < 0.5
                    state = ON;
                    orange.write(1);
                }

                break;

            case RECEIVER_FAULT:

                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                emergencyStopReleased = emergencyButtonReleased.read();
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);

                // reset Receiver manual by button

                if (validRcSignal && enableChannel < 0.5f) {
                    state = OFF;
                    red.write(0);
                } else if (!emergencyStopReleased) {
                    state = EMERGENCY;
                    red.write(1);
                }

                break;  

            case EMERGENCY:

                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                emergencyStopReleased = emergencyButtonReleased.read();

                if (emergencyStopReleased) {
                    state = INIT;
                    startupTimer.start(); startupTimer.reset();
                }

                break;

            default:

                state = INIT;

        }            
    }
}




/* correct state machine

void StateMachine::run() {

    // initialize variables used in stateMachine
    bool validRcSignal = false;
    float modeChannel = 0.0f;
    float enableChannel = 0.0f;
    bool emergencyStopReleased = false;
    float translationalVelocity = 0.0f;
    float manualSteeringAngle = 0.0f;
    float manualCurrent = 0.0f; 
    float manualTranslationalVelocity = 0.0f;

    int16_t stateController = 0;

    while (true) {
        
        // wait for the periodic thread flag
        ThisThread::flags_wait_any(threadFlag);
        
        // update target values
        this->setRemoteSteeringAngle(static_cast<double>(objectDictionary.desiredSteeringAngle.read()/1000.0));
        this->setRemoteSteeringAngleVelocity(static_cast<double>(objectDictionary.desiredSteeringSpeed.read()/1000.0));
        this->setRemoteVelocity(static_cast<double>(objectDictionary.desiredTranslationalVelocity.read()/1000.0));
        this->setRemoteAcceleration(static_cast<double>(objectDictionary.desiredTranslationalAcceleration.read()/1000.0));
        //printf("Ackerman: steering=%f, steeringSpeed=%f, speed=%f, acceleration=%f \r\n",remoteSteeringAngle, remoteSteeringAngleVelocity, remoteTranslationalVelocity, remoteTranslationalAcceleration);


        // Do the logic

        switch (state) {



            case INIT:

                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;

                if (startupTimer.read_ms() > INIT_TIME && enableChannel < 0.5f && validRcSignal) {
                    state = OFF;
                    red.write(0);
                    startupTimer.stop();
                }

                break;

            case OFF:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);

                if (validRcSignal && enableChannel > 0.5f) {
                    state = TURN_ON;
                    controller.turnOn();
                    brakeServo.writeValue(-1.5); // release brake
                } else if (!validRcSignal) {
                    state = RECEIVER_FAULT;
                    red.write(1);
                } else if (!emergencyStopReleased) {
                    state = EMERGENCY;
                    red.write(1);
                } else if(receiver.getChannelValue(GraupnerReciver::MEASUREMENT_CHANNEL) > 0) {

                    saveMeasure = true;
                }

                break;
            
            case ON:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                modeChannel = receiver.getChannelValue(GraupnerReciver::MODE_CHANNEL);

                if (!validRcSignal || !emergencyStopReleased || enableChannel < 0.5f) {
                    state = TURN_OFF;
                    controller.turnOff();
                } else if (modeChannel < -0.5f) {
                    state = MANUAL;
                    controller.setControllerMode(Controller::MANUAL);
                }
                else if (modeChannel < 0.5f) {
                    state = SEMI_AUTONOMOUS;
                    controller.setControllerMode(Controller::SEMI_AUTONOMOUS);
                }
                else {
                    state = AUTONOMOUS;
                    controller.setControllerMode(Controller::AUTONOMOUS);
                }

                break;

            case TURN_ON:

                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                emergencyStopReleased = emergencyButtonReleased.read();
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);
                stateController = controller.getState();

                if (!validRcSignal || !emergencyStopReleased || enableChannel < 0.5f) {
                    state = TURN_OFF;
                    controller.turnOff();
                } else if ( stateController == Controller::ON && validRcSignal && enableChannel > 0.5f ) {
                    state = ON;
                    orange.write(1);
                }

                break;

            case TURN_OFF:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                translationalVelocity = controller.getActualTranslationalVelocity();
                stateController = controller.getState();

                //change this to entry....
                brakeServo.writeValue(0.05); // brake vehicle

                if (!emergencyStopReleased && translationalVelocity < 0.5f && stateController == Controller::OFF) {
                    state = EMERGENCY;
                    orange.write(0);
                    red.write(1);
                } else if (!validRcSignal && translationalVelocity < 0.5f && stateController == Controller::OFF) {
                    state = RECEIVER_FAULT;
                    orange.write(0);
                    red.write(1);
                } else if (validRcSignal && translationalVelocity < 0.5f && stateController == Controller::OFF) {
                    state = OFF;
                    red.write(0);
                    orange.write(0);
                }

                break;

            case MANUAL:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);
                modeChannel = receiver.getChannelValue(GraupnerReciver::MODE_CHANNEL);

                manualSteeringAngle = receiver.getChannelValue(GraupnerReciver::STEERING_CHANNEL)*RAD_PER_PWM;
                if (receiver.getChannelValue(GraupnerReciver::THROTTLE_CHANNEL) > 0.0) manualCurrent = receiver.getChannelValue(GraupnerReciver::THROTTLE_CHANNEL)*MAXIMAL_MANUAL_ACCELERATION;
                else manualCurrent = receiver.getChannelValue(GraupnerReciver::THROTTLE_CHANNEL)*MAXIMAL_MANUAL_DECELERATION;
                controller.setCommands(manualSteeringAngle, 0.0f, manualCurrent);
                
                if (!validRcSignal || !emergencyStopReleased || enableChannel < 0.5f) {
                    state = TURN_OFF;
                    controller.turnOff();
                    controller.setCommands(0.0f, 0.0f, 0.0f);
                } else if (modeChannel > -0.5) {
                    state = ON;
                    orange.write(1);
                    controller.setCommands(0.0f, 0.0f, 0.0f);
                } else if(receiver.getChannelValue(GraupnerReciver::MEASUREMENT_CHANNEL) > 0) {

                    printf("START\r\n");
                    motionEstimation.resetMeasurement();
                    motionEstimation.startMeasurement();
                    green1.write(1);
                    ThisThread::sleep_for(200);
                }
            
                break;

            case SEMI_AUTONOMOUS:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);
                modeChannel = receiver.getChannelValue(GraupnerReciver::MODE_CHANNEL);

                // ONLY FOR TESTING SPEEDCONTROLLER - USE REMOTE TO STEER CAR
                manualSteeringAngle = receiver.getChannelValue(GraupnerReciver::STEERING_CHANNEL)*RAD_PER_PWM;
                //manualSteeringAngle = remoteSteeringAngle;
                manualTranslationalVelocity = receiver.getChannelValue(GraupnerReciver::THROTTLE_CHANNEL)*MAXIMAL_MANUAL_TRANSLATIONAL_VELOCITY;
                controller.setCommands(manualSteeringAngle, manualTranslationalVelocity, 0.0f);

                if (!validRcSignal || !emergencyStopReleased || enableChannel < 0.5f) {
                    state = TURN_OFF;
                    controller.turnOff();
                    controller.setCommands(0.0f, 0.0f, 0.0f);
                } else if ( (modeChannel < -0.5) || (modeChannel > 0.5) ) {
                    state = ON;
                    orange.write(1);
                    controller.setCommands(0.0f, 0.0f, 0.0f);
                }
            
                break;

            case AUTONOMOUS:

                emergencyStopReleased = emergencyButtonReleased.read();
                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);
                modeChannel = receiver.getChannelValue(GraupnerReciver::MODE_CHANNEL);

                
                //remoteSteeringAngle = 0.0f;
                //remoteTranslationalVelocity = 0.0f;
                //remoteTranslationalAcceleration = 0.0f;
                // Set values from CANOpen stack...
                controller.setCommands(remoteSteeringAngle, remoteTranslationalVelocity, remoteTranslationalAcceleration);

                if (blueButton.read()) {
                    state = TURN_OFF;
                    controller.turnOff();
                    controller.setCommands(0.0f, 0.0f, 0.0f); // set steering angle, velocity and acceleration zero...
                } else if ( false ) { //validRcSignal && modeChannel < 0.5
                    state = ON;
                    orange.write(1);
                }

                break;

            case RECEIVER_FAULT:

                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                emergencyStopReleased = emergencyButtonReleased.read();
                enableChannel = receiver.getChannelValue(GraupnerReciver::ENABLE_CHANNEL);

                // reset Receiver manual by button

                if (validRcSignal && enableChannel < 0.5f) {
                    state = OFF;
                    red.write(0);
                } else if (!emergencyStopReleased) {
                    state = EMERGENCY;
                    red.write(1);
                }

                break;  

            case EMERGENCY:

                validRcSignal = receiver.getWatchdogTime()<RECEIVER_WATCHDOG_TIMEOUT;
                emergencyStopReleased = emergencyButtonReleased.read();

                if (emergencyStopReleased) {
                    state = INIT;
                    startupTimer.start(); startupTimer.reset();
                } else if (!validRcSignal) {
                    state = RECEIVER_FAULT;
                    red.write(1);
                }

                break;

            default:

                state = INIT;

        }            
    }
}
*/
