/*
 * ADCUnit.cpp
 * Copyright (c) 2018, ZHAW
 * All rights reserved.
 */

#include "ADCUnit.h"

using namespace std;

/**
 * This Object simplifies the handling of the analog inputs. It samples always at the same time and profides the filterd values. If the use uf much more input is planed, my you should
 * you should think about the sampling frequency. Currently it does not matter sampling always all ADC's, since there are only three. 
 * Sampling three ADCs tooks around 40 us (means < 1% of duty cycle with 5 ms periode). If there are more, the not important devices shouldnt be sampled every
 * cycle. Consider, this function is made for the current development board with its resistors. You need to change values if you use a new board, with differents parts!
 * This class could be modified to read temperature values if needed.
 * @param motorCurrentSensor Reference to the analog input pin of the motor current. This sensor is a shunt resistor.
 * @param batteryVoltageSensor Reference to the analog input pin of the battery voltage. This is a voltage devider to allow reading volatges from 0 to 50 Volts
 * @param boardCurrentSensor Reference to the analog input pin of the board current. This sensor is a shunt resistor.
 * @warning this pin does not work properly at the moment. there is a huge biase and scale error! 
 * @param name name of this instance
 * @param debugSerial Interface to plot the debug messages
 */
ADCUnit::ADCUnit(AnalogIn &motorCurrentSensor, AnalogIn &batteryVoltageSensor, AnalogIn &boardCurrentSensor, string name, DebugOutput * debugSerial):
    motorCurrentSensor(motorCurrentSensor),
    batteryVoltageSensor(batteryVoltageSensor),
    boardCurrentSensor(boardCurrentSensor),
    Thread(osPriorityBelowNormal, OS_STACK_SIZE, NULL,  name.c_str()){

    this->name = name;
    this->debugSerial = debugSerial;

    latestMotorCurrentSensorValueFiltered = 0;
    latestBoardCurrentSensorValueFiltered = 0;
    latestBatteryVoltageSensorValueFiltered = 0;

    motorCurrentSensorFiltered.setPeriod(1.0*SAMPLE_PERIODE/1000);
    boardCurrentSensorFiltered.setPeriod(1.0*SAMPLE_PERIODE/1000);
    batteryVoltageSensorFiltered.setPeriod(1.0*SAMPLE_PERIODE/1000);

    motorCurrentSensorFiltered.setFrequency(FILTER_FREQUENCE_MOTOR_CURRENT);
    boardCurrentSensorFiltered.setFrequency(FILTER_FREQUENCE_BOARD_CURRENT);
    batteryVoltageSensorFiltered.setFrequency(FILTER_FREQUENCE_BATTERY_VOLTAGE);

    start(callback(this, &ADCUnit::run));

    if(debugSerial){
            debugSerial->write(name+" is running...");
    }
}

ADCUnit::~ADCUnit() {}


/**
 * Here you get the filtered value of the actual motor current
 * @return motor current in [A]
 */
double ADCUnit::readMotorCurrentActuallValue(){
    return 3.3*latestMotorCurrentSensorValueFiltered/RESISTOR_VALUE_MOTOR_SHUNT;
}

/**
 * Here you get the filtered value of the current battery voltage
 * @return battery voltage in [V]
 */
double ADCUnit::readBatteryVoltageActuallValue(){
    /* Factor 3.3: Vcc of board, since read Value is from 0...1 and means 0...3.3 V */
    double uncorrectedValue = 3.3 * latestBatteryVoltageSensorValueFiltered * (1 + HIGH_RESISTOR_VALUE_VOLTAGE_DEVIDER_BATTERY / LOW_RESISTOR_VALUE_VOLTAGE_DEVIDER_BATTERY);
    /* Some tests has shown, that this value is not correct, we have to correct it, in order to get a better accuracy. So there is a linear
    correction function: 
    y = m*x +q
    m and q are empirical identified
    m = 1.07887
    q = -0.14
     */

    return  uncorrectedValue * 1.07887 - 0.14;
}

/**
 * Here you get the filtered value of the actual board current. This supply all parts expect motor and RC-receiver (and servos if connected to receiver)
 * @warning This function currently does not deliver a proper result. There is a high noise and error on the measurement. Somewhere is a misstake in the print or some similar issue
 * @return board current in [A]
 */
double ADCUnit::readBoardCurrentActuallValue(){
    /* Factor 3.3: Vcc of board, since read Value is from 0...1 and means 0...3.3 V */
    return 3.3 * latestBoardCurrentSensorValueFiltered / RESISTOR_VALUE_BOARD_SHUNT;
}

/**
 * The Callback function for the thread.
 */
void ADCUnit::run(){
    while(true){
        /* Input all current values to the filters and update member variables */

        latestMotorCurrentSensorValueFiltered = motorCurrentSensorFiltered.filter(motorCurrentSensor.read());
        latestBoardCurrentSensorValueFiltered = boardCurrentSensorFiltered.filter(boardCurrentSensor.read());
        latestBatteryVoltageSensorValueFiltered = batteryVoltageSensorFiltered.filter(batteryVoltageSensor.read());

        rtos::ThisThread::sleep_for(SAMPLE_PERIODE);
    }
}