/*
 * Server.cpp
 * Copyright (c) 2020, ZHAW
 * All rights reserved.
 *
*/

#include "DebugOutput.h"
#define TRACE if(debugSerial) debugSerial->printf("Trace %s, Time: %d ms, Line: %d\r\n",name.c_str(), debugTimer.read_ms(),__LINE__);

using namespace std;

/** 
 * This class gives an interface for a debug output. This could be any serial interface. 
 * All messages are just attached in a que and ploted to the interface. This interface works as fifo.
 * @param targetInterface: Any kind of serial interface, eg. SD-card or debug console
 */
DebugOutput::DebugOutput(Serial &targetInterface, string name):
    Thread(osPriorityLow, OS_STACK_SIZE*5, NULL,  name.c_str()),
    interface(targetInterface){

    this->name = name;
    //write(" ======= Caution change priority of debugOutput object (debugOutput.cpp) on line 22 to low again");

    start(callback(this, &DebugOutput::run));

}

DebugOutput::~DebugOutput() {}


/**
 * Add a Message to the que, it will be ploted in the next plotting cycle
 * @param message Message to attache as string. Does not need to have \r\n at the end
 */
void DebugOutput::write(string message){
    message += "\r\n";
    vectorMutex.lock();
    que.push_back(message);
    vectorMutex.unlock();
}


/**
 * The Callback function for the thread.
 */
void DebugOutput::run(){
    while(true){
        //vector<string> localCopyQue(que);
        // que.clear();
        // que.shrink_to_fit();

        for(uint32_t count = 0; count < que.size(); count ++){
            vectorMutex.lock();
            string message = que[count];
            vectorMutex.unlock();
            interface.printf("%s", que[count].c_str());
        }

        vectorMutex.lock();
        //clear the vector. Read this for mor information: https://www.techiedelight.com/delete-vector-free-memory-cpp/
        vector<string>().swap(que);
        vectorMutex.unlock();

    } ThisThread::sleep_for(PERIODE_OF_THREAD);
}