/*
 * Servo.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 */

#ifndef SERVO_H_
#define SERVO_H_

// #include <cstdint>
// #include <cstdlib>
#include <mbed.h>
// #include <string>
// #include <limits.h>


/**
 * This class implements a servo, to invert direction, scale and limit the input
 */
class Servo{
    
    public:
        
                    Servo(PwmOut& pwmOut, bool invert = false, int16_t nominalLowerOnTime = Servo::GRAUPNER_NOMINAL_LOW_POSITION, int16_t nominalUpperOnTime = Servo::GRAUPNER_NOMINAL_HIGH_POSITION,  float lowerLimit = -1.0, float upperLimit = 1.0, float scaleToNominal = 1.0, float defaultValue = 0.0);
        virtual     ~Servo();

        void        writeValue(float targetValue);
        int16_t     readOnTime();
        float       getTargetValue();

        static const int16_t   GRAUPNER_EXTENED_LOW_POSITION = 900; //in [us], dependent of manufacteror of servo
        static const int16_t   GRAUPNER_NOMINAL_LOW_POSITION = 1100; //in [us], dependent of manufacteror of servo
        static const int16_t   GRAUPNER_NEUTRAL_POSITION = 1100; //in [us], dependent of manufacteror of servo
        static const int16_t   GRAUPNER_NOMINAL_HIGH_POSITION = 1900; //in [us], dependent of manufacteror of servo
        static const int16_t   GRAUPNER_EXTENDED_HIGH_POSITION = 2100; //in [us], dependent of manufacteror of servo
        
    private:

        static const int16_t   PERIODE_SERVO_SIGNAL = 20000; //Common signal of an RC-Servo in [us]
        static const int16_t   MINIMAL_ON_TIME_SERVO = 900; //in [us], independent of manufacteror of servo 
        static const int16_t   MAXIMAL_ON_TIME_SERVO = 2100; //in [us], independent of manufacteror of servo

        int16_t         nominalLowerOnTime;
        int16_t         nominalUpperOnTime;
        int16_t         nominalCenterOnTime;
        int16_t         timeRange;
        float           lowerLimit;
        float           upperLimit;
        float           scaleToNominal;
        bool            invert;
        float           targetValue;
        int16_t         targetOnTime;
        
        PwmOut&         pwmOut;

        int16_t    mapValueToOnTime(float value);
        int16_t    invertSignal(int16_t onTime);

};

#endif /* SERVO_H */