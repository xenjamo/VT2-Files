/*
 * Controller.cpp
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 03.02.2021
 *      Author: Nicolas Borla
 */

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>
#include "Controller.h"
#include "MotionEstimation.h"
#include "cmsis_os2.h"
#include "stm32f7xx_ll_fmc.h"

using namespace std;

// Maxon motors
const float Controller::PERIOD = 0.001f;                        // period of control task, given in [s]
const float Controller::PI = 3.14159265f;                       // the constant PI
const float Controller::WHEEL_RADIUS = 0.0622;                  // radius of wheels, given in [m]
const float Controller::WHEEL_BASE = 0.507f;                    // distance betwenn front and rear axle in [m]
const float Controller::TRACK_WIDTH = 0.312;                    // Distance betwenn left and right wheels, center in [m]
const float Controller::COUNTS_PER_TURN = 25600.0f;             // resolution of encoder counter
const float Controller::LOWPASS_FILTER_FREQUENCY = 300.0f;      // frequency of lowpass filter for actual speed values, given in [rad/s]
const float Controller::KN = 250;                               // speed constant in [RPM/V]   //  [rads/s / V] = [RPM/V]*[2*PI*min/60s] = 250 * PI/30
const float Controller::KM = 38.2f;                             // torque constant in [mNm/A] (KN * KM = 30000/PI [RPM/V]*[mNm/A])
const float Controller::GEAR_RATIO = 5.72f;                     // gear ration
const float Controller::MANUAL_PROFILE_VELOCITY = 12.0f;        // maximal velocity in semi autonomous mode
const float Controller::MANUAL_PROFILE_ACCELERATION = 10.0f;     // acceleration in semi autonomous mode
const float Controller::MANUAL_PROFILE_DECELERATION = 10.0f;     // deceleration in semi autonomous mode
const float Controller::P_GAIN = 0.01f;                         // P-gain of velocity controller in [V / rpm]
const float Controller::RAD_PER_PWM = -0.2386;                  // steering angle in [rad] per normed pwm of servo in [1]
const float Controller::VEHICLE_MASS = 18.0;                    // vehicle mass in [kg]
const float Controller::P_GAIN_CURRENT_PER_RPM = 0.010;         // 45->20best practice: 0.045 (tau = 0.13 s). P-Gain of velocity controller in [N / rpm]
const float Controller::MAX_MOTOR_CURRENT = 60.0;               // maximal motor current, set in vesc motor controller in [N]
const float Controller::CURRENT_BIAS = 8.0;                    // current to feed forward due to friction in [A]
const float Controller::CURRENT_PROPOTIONAL_GAIN = 8.125;       // current to feed forward proportional to acceleration due to friction in [A / m/s²]  
const float Controller::STEERING_BACKLASH = 0.04;               // backlash in [rad]
const float Controller::STEERING_LOAD_FACTOR = 1.0;            // actual steering angle is smaller due to tire momentum [1]

/**
 * Creates and initializes a Controller object.
 * @param pwmLeft a pwm output object to set the duty cycle for the left motor.
 * @param pwmRight a pwm output object to set the duty cycle for the right motor.
 * @param counterLeft an encoder counter object to read the position of the left motor.
 * @param counterRight an encoder counter object to read the position of the right motor.
 */
Controller::Controller(EncoderCounter &frontLeftCounter, EncoderCounter &frontRightCounter, EncoderCounter &rearLeftCounter, EncoderCounter &rearRightCounter,
                        Servo &steeringServo, Servo &throttle, AnalogIn& batteryVoltageSensor, MotionEstimation& motionEstimation,
                        int nData, float *Mes) : 
                        frontLeftCounter(frontLeftCounter), frontRightCounter(frontRightCounter), 
                        rearLeftCounter(rearLeftCounter), rearRightCounter(rearRightCounter), 
                        steeringServo(steeringServo), throttle(throttle), batteryVoltageSensor(batteryVoltageSensor), motionEstimation(motionEstimation),
                        thread(osPriorityHigh3, STACK_SIZE)
{

    // initialize motion object
    manualTranslationalMotion.setProfileVelocity(MANUAL_PROFILE_VELOCITY);
    manualTranslationalMotion.setProfileAcceleration(MANUAL_PROFILE_ACCELERATION);
    manualTranslationalMotion.setProfileDeceleration(MANUAL_PROFILE_DECELERATION);

    // initialize lowpass filter objects
    speedFrontRightFilter.setPeriod(PERIOD);
    speedFrontRightFilter.setFrequency(LOWPASS_FILTER_FREQUENCY);
    speedFrontLeftFilter.setPeriod(PERIOD);
    speedFrontLeftFilter.setFrequency(LOWPASS_FILTER_FREQUENCY);
    speedRearLeftFilter.setPeriod(PERIOD);
    speedRearLeftFilter.setFrequency(LOWPASS_FILTER_FREQUENCY);
    speedRearRightFilter.setPeriod(PERIOD);
    speedRearRightFilter.setFrequency(LOWPASS_FILTER_FREQUENCY);

    // initialize local variables
    actualTranslationalVelocity = 0.0f;
    actualRotationalVelocity = 0.0f;

    previousValueCounterFrontLeft = frontLeftCounter.read();
    previousValueCounterFrontRight = frontRightCounter.read();
    previousValueCounterRearLeft = rearLeftCounter.read();
    previousValueCounterRearRight = rearRightCounter.read();

    actualRotationalVelocity = 0.0f;
    actualTranslationalVelocity = 0.0f;

    actualSpeedFrontLeft = 0.0f;
    actualSpeedFrontRight = 0.0f;
    actualSpeedRearLeft = 0.0f;
    actualSpeedRearRight = 0.0f;

    actualAngleFrontLeft = 0.0f;
    actualAngleFrontRight = 0.0;
    actualAngleRearLeft = 0.0f;
    actualAngleRearRight = 0.0f;

    actualMotorSpeed = 0.0f;
    targetMotorSpeed = 0.0f;
    targetMotorAcceleration = 0.0f;
    desiredMotorSpeed = 0.0f;
    targetPhaseVoltage = 0.0f;
    steeringAngle = 0.0f;
    manualSteeringAngle = 0.0f;
    remoteSteeringAngle = 0.0f;
    batteryVoltage = 0.0f;
    pwm = 0.0f;
    currentMotorSaturated = 0.0f;
    actualAveragedDistanceRear = 0.0f;
    actualOrientation = 0.0f;
    targetCurrent = 0.0;
    desiredSteeringAngle = 0.0f;
    desiredTranslationalVelocity = 0.0f;
    desiredTranslationalAcceleration = 0.0f;

    stateController = OFF;
    stateDemandController = OFF;

    // measurement variables
    startMeasure = false;
    measureIndex = 0;
    this->nData = nData;
    this->Mes = Mes;

    // start periodic task
    thread.start(callback(this, &Controller::run));
    ticker.attach(callback(this, &Controller::sendThreadFlag), PERIOD);
}

/**
 * Deletes the Controller object and releases all allocated resources.
 */
Controller::~Controller()
{

    ticker.detach();
}

void Controller::setCommands(float desiredSteeringAngle, float desiredTranslationalVelocity, float desiredTranslationalAcceleration)
{
    this->desiredSteeringAngle=desiredSteeringAngle;
    this->desiredTranslationalVelocity=desiredTranslationalVelocity;
    this->desiredTranslationalAcceleration=desiredTranslationalAcceleration;
}

float Controller::getActualMotorSpeed()
{

    return actualMotorSpeed;
}

float Controller::getTargetMotorSpeed()
{

    return targetMotorSpeed;
}

void Controller::turnOn() 
{

    stateDemandController = ON;
}

void Controller::turnOff()
{

    stateDemandController = OFF;
}

void Controller::setControllerMode(int16_t desiredControllerMode)
{

    stateDemandController = desiredControllerMode;
}

int16_t Controller::getState()
{

    return stateController;
}

float Controller::getSteeringAngle()
{

    return steeringAngle;
}

float Controller::getMotorCurrent()
{

    return targetCurrent;
}

// return target motor current for debugging, this value is sent via CANopen and published in ROS as phase voltage. 
// instead of the voltage the target current is sent
float Controller::getMotorVoltage()
{

    return currentMotorSaturated;
}

float Controller::getBatteryVoltage()
{

    return batteryVoltage;
}

/**
 * Gets the actual translational velocity of the robot.
 * @return the actual translational velocity, given in [m/s].
 */
float Controller::getActualTranslationalVelocity()
{

    return actualTranslationalVelocity;
}

/**
 * Gets the actual rotational velocity of the robot.
 * @return the actual rotational velocity, given in [rad/s].
 */
float Controller::getActualRotationalVelocity()
{

    return actualRotationalVelocity;
}

/**
 * Gets the actual traveled distance of the rear axis center
 * @return the actual traveled distance of the rear axis center, given in [m].
 */
float Controller::getActualAveragedDistanceRear() 
{
    
    return actualAveragedDistanceRear;
}

/**
 * Gets the actual orientation calculated by the odometry
 * @return the actual orientation of the car, given in [rad].
 */
float Controller::getActualOrientation() 
{

    return actualOrientation;
}

/**
 * Read the current angle of the Wheels in [rad]
 * @param FL Reference to the angle of the front left wheel
 * @param FR Reference to the angle of the front right wheel
 * @param RL Reference to the angle of the rear left wheel
 * @param RR Reference to the angle of the rear right wheel
 */
void Controller::getActualAngles(float &FL, float &FR, float &RL, float &RR){
    FL = actualAngleFrontLeft;
    FR = actualAngleFrontRight;
    RL = actualAngleRearLeft;
    RR = actualAngleRearRight;
}

/**
 * Read the current velocity of the Wheels in [rad]
 * @param FL Reference to the velocity of the front left wheel
 * @param FR Reference to the velocity of the front right wheel
 * @param RL Reference to the velocity of the rear left wheel
 * @param RR Reference to the velocity of the rear right wheel
 */
void Controller::getActualVelocities(float &FL, float &FR, float &RL, float &RR){
    FL = actualSpeedFrontLeft;
    FR = actualSpeedFrontRight;
    RL = actualSpeedRearLeft;
    RR = actualSpeedRearRight;
}

/**
 * Gets the actual rotational velocity of the front left wheel.
 * @return the actual rotational velocity of the wheel, given in [rad/s].
 */
float Controller::getActualVelocityFL()
{
    return actualSpeedFrontLeft;
}

/**
 * Gets the actual rotational velocity of the front right wheel.
 * @return the actual rotational velocity of the wheel, given in [rad/s].
 */
float Controller::getActualVelocityFR()
{
    return actualSpeedFrontRight;
}

/**
 * Gets the actual rotational velocity of the rear left wheel.
 * @return the actual rotational velocity of the wheel, given in [rad/s].
 */
float Controller::getActualVelocityRL()
{
    return actualSpeedRearLeft;
}

/**
 * Gets the actual rotational velocity of the rear right wheel.
 * @return the actual rotational velocity of the wheel, given in [rad/s].
 */
float Controller::getActualVelocityRR()
{
    return actualSpeedRearRight;
}

/**
 * This method is called by the ticker timer interrupt service routine.
 * It sends a flag to the thread to make it run again.
 */
void Controller::sendThreadFlag() {
    
    thread.flags_set(threadFlag);
}

void Controller::startMeasurement(){
    startMeasure = true;
    timer.reset();
}

void Controller::resetMeasurement(){
    startMeasure = false;
    measureIndex = 0;
    timer.reset();
};

/**
 * This method is called periodically by the ticker object and contains the
 * algorithm of the speed controller.
 */
void Controller::run()
{

    // TODO: delte this, but test...
    steeringServo.writeValue(Servo::GRAUPNER_NEUTRAL_POSITION);
    throttle.writeValue(Servo::GRAUPNER_NEUTRAL_POSITION);

/*
    // variable to perform measurements
    int nData = 7000;
    int * T = new int[nData]();
    float * Mes1 = new float[nData]();
    float * Mes2 = new float[nData]();
    float * Mes3 = new float[nData]();
    int t=0;
    int a=0;
    bool startMeasurement=true;
    float unfilteredSpeed = 0.0;
*/
    timer.reset();
    timer.start();
    
    while(true) {

        // wait for the periodic thread flag
        ThisThread::flags_wait_any(threadFlag);

/*
        // publish measured data when done
        if(t==nData) {
            for(int j=0; j<nData; j++) {
                printf("%d %.7f %.7f %.7f\r\n",*(T+j),*(Mes1+j),*(Mes2+j),*(Mes3+j));
            }
            t = 0;
            startMeasurement = false;
        }
*/

        // calculate battery voltage
        // TODO: recalibrate this
        // float uncorrectedBatteryVoltage = 3.3f * batteryVoltageSensor.read() * (1 + 4300 / 270);
        // batteryVoltage = uncorrectedBatteryVoltage * 1.07887 - 0.14;
        float uncorrectedBatteryVoltage = 3.3f * batteryVoltageSensor.read() * (1 + 4300 / 270);
        batteryVoltage = uncorrectedBatteryVoltage * 1.1675 - 2.1814; // U_true = U_meas * a + b

        // calculate actual speed of wheels in [rad/s] and angles in [rad]
        short valueCounterFrontLeft = frontLeftCounter.read();
        short valueCounterFrontRight = frontRightCounter.read();
        short valueCounterRearLeft = rearLeftCounter.read();
        short valueCounterRearRight = rearRightCounter.read();

        short countsInPastPeriodFrontLeft = valueCounterFrontLeft-previousValueCounterFrontLeft;
        short countsInPastPeriodFrontRight = valueCounterFrontRight-previousValueCounterFrontRight;
        short countsInPastPeriodRearLeft = valueCounterRearLeft-previousValueCounterRearLeft;
        short countsInPastPeriodRearRight = valueCounterRearRight-previousValueCounterRearRight;

        previousValueCounterFrontLeft = valueCounterFrontLeft;
        previousValueCounterFrontRight = valueCounterFrontRight;
        previousValueCounterRearLeft = valueCounterRearLeft;
        previousValueCounterRearRight = valueCounterRearRight;

        actualSpeedFrontLeft = -speedFrontLeftFilter.filter(countsInPastPeriodFrontLeft/COUNTS_PER_TURN/PERIOD*2.0*PI);
        actualSpeedFrontRight = speedFrontRightFilter.filter(countsInPastPeriodFrontRight/COUNTS_PER_TURN/PERIOD*2.0*PI);
        actualSpeedRearLeft = speedRearLeftFilter.filter(countsInPastPeriodRearLeft/COUNTS_PER_TURN/PERIOD*2.0*PI);
        actualSpeedRearRight = -speedRearRightFilter.filter(countsInPastPeriodRearRight/COUNTS_PER_TURN/PERIOD*2.0*PI);

        actualAngleFrontLeft += actualSpeedFrontLeft*PERIOD;
        actualAngleFrontRight += actualSpeedFrontRight*PERIOD;
        actualAngleRearLeft += actualSpeedRearLeft*PERIOD;
        actualAngleRearRight += actualSpeedRearRight*PERIOD;

        // calculate actualTranslationalVelocity in [m/s]
        actualTranslationalVelocity = (actualSpeedRearLeft+actualSpeedRearRight)/2.0f*WHEEL_RADIUS; // Mean value between the rear wheels
        // calculate actualRotationalVelocity using the kinematic model (biycle or 2 wheel robot)
        // actualRotationalVelocity = actualTranslationalVelocity/WHEEL_BASE*tan(steeringAngle); // kinematic bicycle
        actualRotationalVelocity = (actualSpeedRearRight - actualSpeedRearLeft)*WHEEL_RADIUS/TRACK_WIDTH; // 2 wheel


        actualTranslationalVelocity = motionEstimation.getTranslationalVelocity();
        actualRotationalVelocity = motionEstimation.getRotationalVelocity();



        // calculate actual motor speed in [rpm]
        actualMotorSpeed = (actualSpeedRearLeft+actualSpeedRearRight)/2.0f * GEAR_RATIO*60.0f/(2.0f*PI);

        // integrate orientation
        actualOrientation += actualRotationalVelocity*PERIOD;

        // calculate actualAveragedDistanceRear
        actualAveragedDistanceRear = (actualAngleRearLeft + actualAngleRearRight) * WHEEL_RADIUS / 2.0f;

        //variales used in stateController initialized here:
        float limitedDesiredTranlationalVelocity = desiredTranslationalVelocity;
        if (limitedDesiredTranlationalVelocity < 0.0f) limitedDesiredTranlationalVelocity = 0.0f;

        // run controller state machine
        switch (stateController) {

            case OFF:

                targetCurrent = 0.0f;
                steeringAngle = 0.0f;

                if (stateDemandController == ON) {
                    stateController = ON;
                }

                break;

            case ON:

                if (stateDemandController == OFF) {
                    stateController = OFF;
                } else if (stateDemandController == MANUAL) {
                    stateController = MANUAL;
                } else if (stateDemandController == SEMI_AUTONOMOUS) {
                    stateController = SEMI_AUTONOMOUS;
                    manualTranslationalMotion.setVelocity(actualTranslationalVelocity);
                } else if (stateDemandController == AUTONOMOUS) {
                    stateController = AUTONOMOUS;
                }

                break;

            case MANUAL:

                if (stateDemandController == OFF) {
                    stateController = OFF;
                } else if (stateDemandController == SEMI_AUTONOMOUS || stateDemandController == AUTONOMOUS) {
                    stateController = ON;
                }

                // calculate target motor current in [A]
                targetCurrent = desiredTranslationalAcceleration*VEHICLE_MASS*WHEEL_RADIUS*1000/KM/GEAR_RATIO; //*5.1

                // calcultate steering angle
                steeringAngle = desiredSteeringAngle;

                break;

            case SEMI_AUTONOMOUS:

                if (stateDemandController == OFF) {
                    stateController = OFF;
                } else if (stateDemandController == MANUAL || stateDemandController == AUTONOMOUS) {
                    stateController = ON;
                }

                // calculate the planned velocity using the motion planner in [m/s]
                manualTranslationalMotion.incrementToVelocity(limitedDesiredTranlationalVelocity, PERIOD);

                // calculate the target motor speed in [rpm]
                targetMotorSpeed = manualTranslationalMotion.getVelocity()/WHEEL_RADIUS * GEAR_RATIO*60.0f/(2.0f*PI);

                // calculate target motor current in [A] using P-Controller and feedforward using the motion planner acceleration in [m/s²]
                // targetCurrent = (targetMotorSpeed-actualMotorSpeed) * P_GAIN_CURRENT_PER_RPM + manualTranslationalMotion.getAcceleration()*VEHICLE_MASS*WHEEL_RADIUS*1000/KM/GEAR_RATIO;
                targetCurrent = (targetMotorSpeed-actualMotorSpeed) * P_GAIN_CURRENT_PER_RPM;
                if (abs(manualTranslationalMotion.getVelocity()) > 0.1 || abs(manualTranslationalMotion.getAcceleration()) > 0.1 ) {
                    targetCurrent += CURRENT_BIAS + manualTranslationalMotion.getAcceleration() * CURRENT_PROPOTIONAL_GAIN;  // bias for friction and accDepCoeff for gear efficiency/friction (+-5/8.125 = 62%)
                }

                // calcultate steering angle
                steeringAngle = desiredSteeringAngle;

                break;

            case AUTONOMOUS:

                if (stateDemandController == OFF) {
                    stateController = OFF;
                    steeringAngle = 0.0f;
                } else if (stateDemandController == MANUAL || stateDemandController == SEMI_AUTONOMOUS) {
                    stateController = ON;
                }

                // calculate the target motor speed in [rpm]
                targetMotorSpeed = desiredTranslationalVelocity/WHEEL_RADIUS * GEAR_RATIO*60.0f/(2.0f*PI);

                // calculate target motor current in [A]
                //targetCurrent = (targetMotorSpeed-actualMotorSpeed) * P_GAIN_CURRENT_PER_RPM + desiredTranslationalAcceleration*VEHICLE_MASS*WHEEL_RADIUS*1000/KM/GEAR_RATIO;
                targetCurrent = (targetMotorSpeed-actualMotorSpeed) * P_GAIN_CURRENT_PER_RPM;
                if (abs(desiredTranslationalVelocity) > 0.1 || abs(desiredTranslationalAcceleration) > 0.1 ) {
                    targetCurrent += CURRENT_BIAS + desiredTranslationalAcceleration * CURRENT_PROPOTIONAL_GAIN;  // bias for friction and accDepCoeff for gear efficiency/friction (+-5/8.125 = 62%)
                }

                // calcultate steering angle
                steeringAngle = desiredSteeringAngle; // /STEERING_LOAD_FACTOR

                break; 

            default:

                stateController = OFF;
        }

        // calculate target pwm
        pwm = targetCurrent/MAX_MOTOR_CURRENT;

        // limit pwm
        if (pwm > 1.0) pwm = 1.0;
        else if (pwm < -1.0) pwm = -1.0;

        currentMotorSaturated = pwm * MAX_MOTOR_CURRENT;

        // set pwm to controller
        throttle.writeValue(pwm);

        // calculate steering angle and set pwm to servo
        double pwmServo = steeringAngle/RAD_PER_PWM;
        steeringServo.writeValue(pwmServo);

        // Save data
        if (nData != 0 && startMeasure && measureIndex<(nData+3)) {
            *(Mes+measureIndex++) = timer.read();
            *(Mes+measureIndex++) = steeringAngle;
            *(Mes+measureIndex++) = targetPhaseVoltage;
        }
        
    }
}

