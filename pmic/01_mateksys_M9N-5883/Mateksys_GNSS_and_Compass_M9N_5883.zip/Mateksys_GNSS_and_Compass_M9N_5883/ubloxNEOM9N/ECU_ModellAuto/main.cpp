#include "AnalogIn.h"
#include "DigitalIn.h"
#include "DigitalOut.h"
#include "MotionEstimation.h"
#include "EEPROM.h"
#include "Graupner.h"
#include "Motion.h"
#include "PinNames.h"
#include "ThisThread.h"
#include "mbed.h"

#include "mbed_retarget.h"
#include "stm32f767xx.h"
#include "string"
#include "mbed_mktime.h"

#include "Receiver.h"
#include "Servo.h"
#include "OpenIMU300ZI.h"
#include "ADCUnit.h"
#include "DebugOutput.h"


#include "AtmelAT24C04.h"
#include "ONsemiCAT24C256.h"
#include "ObjectDictionary.h"
#include "CANopen.h"
#include "EncoderF767ZI.h"
#include "Controller.h"
#include "StateMachine.h"

#include "SDBlockDevice.h"
#include "FATFileSystem.h"
#include <cstdio>
#include <ctime>

#include "PX4Flow.h"
#include "NEOM9N.h"
#include "MotionEstimation.h"

#define SERVO_INVERTED true
#define SERVO_NON_IVERTED false
	

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif

const int32_t BAUDERATE_DEBUG_SERIAL = 115200;


int main() {

    // /* Serial comunication */
    Serial debugSerial(USBTX, USBRX, "debugSerial", BAUDERATE_DEBUG_SERIAL);

    printf("\r\n\r\nInitialise peripherals...\r\n");

    /* Receiver  */
    //Receiver* gR16Receiver = new Receiver(PD_1, PD_0, "GR16Receiver", LED1);
    //ThisThread::sleep_for(100);
    //gR16Receiver->switchOn();
    RawSerial serialReciver(PD_1, PD_0, 115200);
    GraupnerReciver graupnerReciver(serialReciver);
    
    printf("Reciver initialised\r\n");
    

    /* Encoder  */
    EncoderCounter* frontRightEncoder = new EncoderCounter(PB_4, PB_5);
    EncoderCounter* rearRightEncoder = new EncoderCounter(PD_12, PD_13);
    EncoderCounter* frontLeftEncoder = new EncoderCounter(PC_6, PC_7);
    EncoderCounter* rearLeftEncoder = new EncoderCounter(PE_9, PE_11);

    /* IMU */
    DigitalOut imuNRST(PD_2, 0);
    OpenIMU300ZI* imu = new OpenIMU300ZI(PB_2, PC_11, PC_10, PA_15, imuNRST, "imu"); // mosi, miso, sclk, ss   PC_12
    printf("Switch IMU in...");
    ThisThread::sleep_for(100);
    imu->switchOn();
    //while(!imu->isOperational()){imu->switchOn();ThisThread::sleep_for(200);}; //Wait until unit is operational (tooks around 1 s)
    printf("done\r\n");

    /* Misc. I/O*/
    AnalogIn* boardCurrentSensor = new AnalogIn(PF_5); //Delivers quite bad measurements, maybe follow up later
    AnalogIn* batteryVoltageSensor = new AnalogIn(PA_4);
    AnalogIn* motorCurrentSensor = new AnalogIn(PC_3);
    //ADCUnit*  adcUnit = new ADCUnit(motorCurrentSensor, batteryVoltageSensor, boardCurrentSensor, "ADC-Unit");
    AnalogIn temperatureSteeringServo1(PF_6);
    AnalogIn temperatureSteeringServo2(PF_7);

    DigitalOut* green1 = new DigitalOut(PF_15);
    DigitalOut* green2 = new DigitalOut(PG_0);
    DigitalOut* orange = new DigitalOut(PF_12);
    DigitalOut* red = new DigitalOut(PA_6);

    DigitalIn* emergencyStopReleased = new DigitalIn(PG_1); //is False if the remote is not connected (or the red button has been pressed)
    DigitalIn* userButton = new DigitalIn(USER_BUTTON);

    PwmOut steeringPWM(PA_0);
    PwmOut unusedSteeringPWM(PA_3);
    PwmOut throttlePWM(PE_5);
    PwmOut brakePWM(PE_6);

    /* Servos */
    Servo* steeringServo = new Servo(steeringPWM, false, Servo::GRAUPNER_NOMINAL_LOW_POSITION, Servo::GRAUPNER_NOMINAL_HIGH_POSITION, -1.5, 1.5, 1.0, 0.0);
    Servo* unusedSteeringServo = new Servo(unusedSteeringPWM, false, Servo::GRAUPNER_NOMINAL_LOW_POSITION, Servo::GRAUPNER_NOMINAL_HIGH_POSITION, -1.5, 1.5, 1.0, 0.0); // not used anymore, since both steering servos a connected in hardware by Y-cable
    Servo* throttle = new Servo(throttlePWM, false, 1000, 2000, -1.1, 1.1, 1.0, 0.0);
    Servo* brakeServo = new Servo(brakePWM, false, Servo::GRAUPNER_NOMINAL_LOW_POSITION, Servo::GRAUPNER_NOMINAL_HIGH_POSITION, -1.5, 1.5, 1.0, 0.0);

    // test led's. Turn on -> green1, green2, orange, red -> turn all off
    green1->write(true); ThisThread::sleep_for(100);
    green2->write(true); ThisThread::sleep_for(100);
    orange->write(true); ThisThread::sleep_for(100);
    red->write(true); ThisThread::sleep_for(100);
    green1->write(false); green2->write(false); orange->write(false); red->write(false);


    /* Optical flow sensor PX4Flow*/
    I2C i2c1(PB_11,PB_10);
    i2c1.frequency(400000);
    PX4Flow px4flow(i2c1);

    /* GNSS Sensor NEO-M9N*/
    NEOM9N neom9n(PD_5,PD_6);

    
    // Measurement arrays
    int nData = 80000;
    float * Mes = new float[nData]();
    for(int i=0; i<nData; i++){
        *(Mes+i) = 0.0;
    }
    

    /*Motion estimation - speed filter*/
    MotionEstimation* motionEstimation = new MotionEstimation(*rearLeftEncoder, *rearRightEncoder,*imu,px4flow,neom9n, *throttle, *steeringServo, nData, Mes);

    Controller* controller = new Controller(*frontLeftEncoder, *frontRightEncoder, *rearLeftEncoder, *rearRightEncoder, *steeringServo, *throttle, *batteryVoltageSensor, *motionEstimation);

    // configure CAN
    sleep_manager_lock_deep_sleep(); // disable deep sleep for timer clocks
    CAN* can = new CAN(PB_8, PB_9); // create CAN bus driver

    CAN1->MCR &= ~0x00000010; // reset NART
    CAN1->MCR |= 0x00000040; // set ABOM

    // create Fake EEPROM device driver
    EEPROM* eeprom = NULL;

    printf("Object dictionary in...");
    // create object dictionary and CANopen stack
    ObjectDictionary* objectDictionary = new ObjectDictionary(*eeprom, frontLeftEncoder, frontRightEncoder, rearLeftEncoder, rearRightEncoder, controller, imu, batteryVoltageSensor, motionEstimation);
    objectDictionary->nodeID = 15;
    printf("done\r\n");

    // initialise CANopen
    CANopen* canOpen = new CANopen(*can, *objectDictionary);

    StateMachine* stateMachine = new StateMachine(*controller, graupnerReciver, *emergencyStopReleased, *green1, *green2, *orange, *red, *brakeServo, *objectDictionary, *motionEstimation, *userButton, nData, Mes);


    /*PUTTY: Telenet, 192.168.1.1, port 2000
     go in command mode by typing: "$$$"
     set baudrate with "set uart instant 115200"
     then "exit"*/

    // Initialise WiFi serial port
    Serial wifiSerial(PE_8,PE_7);
    wifiSerial.baud(115200);
    wifiSerial.format(8, SerialBase::None, 1);
    DigitalOut reset(PG_14);
    DigitalOut modes1(PG_9);
    modes1 = 0;
    reset = 1; ThisThread::sleep_for(200);
    reset = 0; ThisThread::sleep_for(200);
    reset = 1; ThisThread::sleep_for(200);
    
    /*
    // initialise SD Card file system
    printf("try start SD...\r\n");
    SDBlockDevice sd(PE_14, PE_13, PE_2, PE_4); // MOSI, MISO, CLK, CS
    FATFileSystem fs("fs", &sd);
    printf("SD Filesystem created\r\n");

    // test sd card read write
    printf("Test writing... ");
    FILE* fp = fopen("/fs/test.csv", "w");
    fprintf(fp, "test %.5f\r\n",1.23);
    fclose(fp);
    printf("done\r\n");
    
    printf("Test reading... ");
    // read from SD card
    fp = fopen("/fs/test.csv", "r");
    if (fp != NULL) {
        char c = fgetc(fp);
        if (c == 't')
            printf("done\r\n");
        else
            printf("incorrect char (%c)!\n", c);
        fclose(fp);
    } else {
        printf("Reading failed!\n");
    }
    */
    DigitalOut nucleoLed3(LED3);
    
    ThisThread::sleep_for(100);
    printf("Initialization done\r\n\r\n");

    bool buttonBefore = userButton;

    while (true) {


        // send data via WLAN module
        if(stateMachine->saveMeasure){
                wifiSerial.printf("Write measurements\r\n");
                //wifiSerial.printf("Time [s],ActualSpeedRearLeft [rad/s],ActualSpeedRearRight [rad/s],GNSSspeed [m/s],GNSSheading [rad],AccX [m/s²],AccY [m/s²],AccZ [m/s²],GyroZ [rad/s], Yaw [rad],Xflow [],Yflow [],FlowQuality [0-255]\r\n");                  
                wifiSerial.printf("Time [s],MotorCurrent [A], TranslationalSpeed [m/s],AccX [m/s²]");                  
                for(int j=0; j<(nData-4); j=j+4) {
                    //wifiSerial.printf("%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f\r\n",*(Mes+j),*(Mes+j+1),*(Mes+j+2),*(Mes+j+3),*(Mes+j+4),*(Mes+j+5),*(Mes+j+6),*(Mes+j+7),*(Mes+j+8),*(Mes+j+9),*(Mes+j+10),*(Mes+j+11),*(Mes+j+12));
                    wifiSerial.printf("%.7f,%.7f,%.7f,%.7f\r\n",*(Mes+j),*(Mes+j+1),*(Mes+j+2),*(Mes+j+3));
            
                    //ThisThread::sleep_for(1);
                }
                wifiSerial.printf("END\r\n");
                stateMachine->saveMeasure = false;
                green1->write(0);
            }
            

/*
        // reset receiver state machine
        bool buttonNow = userButton->read();
        if (buttonNow) {gR16Receiver->switchOff(); printf("pressed\r\n"); }
        if (!buttonNow && buttonBefore) {gR16Receiver->switchOn(); printf("released\r\n"); }
        buttonBefore = buttonNow;   
*/

        // print information
        //printf("Battery voltage: %f\r\n", controller->getBatteryVoltage());
        //printf("Throttle PWM: %f\r\n", gR16Receiver->getChannelValue(Receiver::THROTTLE_CHANNEL));
        //printf("Motor current: %f\r\n", controller->getMotorCurrent());
        // printf("TargetMotorSpeed: %f\r\n", controller->getTargetMotorSpeed());
        // printf("ActualMotorSpeed: %f\r\n", controller->getActualMotorSpeed());
        // printf("Translational Velocity: %f\r\n", controller->getActualTranslationalVelocity());
        // printf("Traveled distance: %f\r\n", controller->getActualAveragedDistanceRear());
        // printf("Orientation: %f\r\n", controller->getActualOrientation());
        //printf("Voltages (phase,battery): %d, %d \r\n",objectDictionary->phaseVoltage.read(), objectDictionary->batteryVoltage.read());
        // printf("emergencyReleased: %d\r\n", emergencyStopReleased->read());
        // printf("actualVelocity: %f\r\n", controller->getActualTranslationalVelocity());
        // printf("steeringAngle: %f\r\n", controller->getSteeringAngle());
        // printf("enableVal: %f\r\n", gR16Receiver->getChannelValue(Receiver::ENABLE_CHANNEL));
        // printf("modeVal: %f\r\n", gR16Receiver->getChannelValue(Receiver::MODE_CHANNEL));
        // printf("isFailSafe: %d\r\n", gR16Receiver->isFailSafe());
        // printf("isOperational: %d\r\n", gR16Receiver->isOperational());
        //printf("State RX: %d\r\n", gR16Receiver->getState());
        printf("State SM: %d, State Controller: %d\r\n", stateMachine->getState(), controller->getState());
        // printf("State Controller: %d\r\n", controller->getState());
        // Test

        //printf("\r\n\r\n");

        //printf("Ackerman: steering=%d, steeringSpeed=%d, speed=%d, acceleration=%d \r\n",objectDictionary->desiredSteeringAngle.read(), objectDictionary->desiredSteeringSpeed.read(), objectDictionary->desiredTranslationalVelocity.read(), objectDictionary->desiredTranslationalAcceleration.read());
        double roll, pitch, yaw;
        imu->getEulerAngles(roll,pitch, yaw);
        printf("IMU: roll: %.3f, pitch: %.3f, yaw: %.3f\r\n",roll,pitch,yaw);
        printf("GPS time: %d, num sat: %d, lat: %d, lon: %d, speed: %d, heading: %d\r\n", neom9n.actualPVT.itow, neom9n.actualPVT.numSV, neom9n.actualPVT.lat, neom9n.actualPVT.lon, neom9n.actualPVT.speed, neom9n.actualPVT.headMot);
        //printf("PX4Flow: avg. flow x: %.3f, y: %.3f   quality: %d/255    val frame count: %d   frame count:%d   qual_scaled:%d/255\r\n",px4flow.avg_flow_x(),px4flow.avg_flow_y(),px4flow.avg_qual(),px4flow.valid_frame_count(),px4flow.frame_count(),px4flow.avg_qual_scaled());
        //printf("Motion Estimation: transl = %f / %f rot = %f / %f\r\n",motionEstimation->getTranslationalVelocity(), controller->getActualTranslationalVelocity(), motionEstimation->getTranslationalVelocity(), controller->getActualRotationalVelocity());
        printf("\r\n");
        //printf("motion estimation calc time: %f [s]\r\n",motionEstimation.calculationTime);
        
        
        //printf("Reciver: EN: %.1f MES: %.1f MODE: %.1f STEERING: %.1f THROTTLE: %.1f, quality: %.2f\r\n",graupnerReciver.getChannelValue(Receiver::ENABLE_CHANNEL),graupnerReciver.getChannelValue(Receiver::MEASUREMENT_CHANNEL),graupnerReciver.getChannelValue(Receiver::MODE_CHANNEL),graupnerReciver.getChannelValue(Receiver::STEERING_CHANNEL),graupnerReciver.getChannelValue(Receiver::THROTTLE_CHANNEL),graupnerReciver.getQuality());



        // print to serial port via WiFi
        // =============================
        //wifiSerial.printf("State SM: %d\r\n", stateMachine->getState());
        //wifiSerial.printf("PX4Flow: avg. flow x: %.3f, y: %.3f   quality: %d/255    val frame count: %d   frame count:%d   qual_scaled:%d/255\r\n",px4flow.avg_flow_x(),px4flow.avg_flow_y(),px4flow.avg_qual(),px4flow.valid_frame_count(),px4flow.frame_count(),px4flow.avg_qual_scaled());

        nucleoLed3 = !nucleoLed3;
        // wait in main loop
        ThisThread::sleep_for(500);
    }
}