/*
 * StateMachine.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 03.03.2021
 *      Author: Jonas Langenegger
 */

#ifndef STATE_MACHINE_H_
#define STATE_MACHINE_H_

#include <cstdint>
#include <cstdlib>
#include <mbed.h>
#include "DigitalIn.h"
#include "Graupner.h"
#include "MotionEstimation.h"
#include "Mutex.h"
#include "ObjectDictionary.h"
#include "ThreadFlag.h"
#include "Controller.h"
#include "Servo.h"

/**
 * This class runs a state machine
 */
class StateMachine {

    public:

        static const int16_t    INIT = 0;
        static const int16_t    OFF = 1;
        static const int16_t    ON = 2;
        static const int16_t    TURN_ON = 3;
        static const int16_t    TURN_OFF = 4;
        static const int16_t    MANUAL = 5;
        static const int16_t    SEMI_AUTONOMOUS = 6;
        static const int16_t    AUTONOMOUS = 7;
        static const int16_t    RECEIVER_FAULT = 8;
        static const int16_t    EMERGENCY = 9;
        
                    StateMachine(Controller& controller, GraupnerReciver& receiver, DigitalIn& emergencyButtonReleased, 
                                    DigitalOut& green1, DigitalOut& green2, DigitalOut& orange, DigitalOut& red, Servo& brakeServo,
                                    ObjectDictionary& objectDictionary, MotionEstimation& motionEstimation, DigitalIn& blueButton,
                                    int nData = 0, float *Mes = nullptr);
        virtual     ~StateMachine();
        void        setState(int16_t stateDemand);
        int16_t     getState();
        void        setRemoteSteeringAngle(float steeringAngle);
        void        setRemoteSteeringAngleVelocity(float steeringAngleVelocity);
        void        setRemoteVelocity(float velocity);
        void        setRemoteAcceleration(float acceleration);

        bool        saveMeasure = false;

    private:
        
        static const unsigned int       STACK_SIZE = 4096;          // stack size of thread, given in [bytes]
        static const float              PERIOD;                     // the period of the timer interrupt, given in [s]  
        static const float              INIT_TIME;                  // time to wait in init state to start up (due to motor controller, needs a certain time with 1500us pwm)
        static const float              MAXIMAL_MANUAL_ACCELERATION;   
        static const float              MAXIMAL_MANUAL_DECELERATION; 
        static const float              MAXIMAL_MANUAL_TRANSLATIONAL_VELOCITY;
        static const float              RAD_PER_PWM;
        static const int                RECEIVER_WATCHDOG_TIMEOUT;

        float remoteSteeringAngle;
        float remoteSteeringAngleVelocity;
        float remoteTranslationalVelocity;
        float remoteTranslationalAcceleration;

        int16_t         stateDemand;
        int16_t         state;     

        ThreadFlag      threadFlag;
        Thread          thread;
        Ticker          ticker;
        Timer           startupTimer;

        Controller&     controller;
        GraupnerReciver&       receiver;
        DigitalIn&      emergencyButtonReleased;
        DigitalOut&     green1;
        DigitalOut&     green2;
        DigitalOut&     orange;
        DigitalOut&     red;
        Servo&          brakeServo;
        ObjectDictionary& objectDictionary;
        MotionEstimation& motionEstimation;
        DigitalIn&      blueButton;

        // pointer to measurement objects
        int                 nData;
        float               *Mes;
        Timer               timer;
        Mutex               mutex;

        void    sendThreadFlag();
        void    run();
};

#endif /* STATE_MACHINE_H_ */
