/*
 * EEPROM.cpp
 * Copyright (c) 2018, ZHAW
 * All rights reserved.
 *
 *  Created on: 19.07.2018
 *      Author: Marcel Honegger
 */

#include "EEPROM.h"

using namespace std;

/**
 * Writes a byte to a specified address.
 * @param address a given byte address.
 * @param data the data byte to store at the given address.
 * @return an error code, 0 on sucess and other values on failure.
 */
int32_t EEPROM::write(uint16_t address, uint8_t data) {
    
    return 0;
}

/**
 * Reads a byte from a specified address.
 * @param address a given byte address.
 * @param data a reference to a data byte to copy the value at the given address into.
 * @return an error code, 0 on sucess and other values on failure.
 */
int32_t EEPROM::read(uint16_t address, uint8_t& data) {
    
    return 0;
}
