/*
 * AtmelAT24C04.cpp
 * Copyright (c) 2018, ZHAW
 * All rights reserved.
 *
 *  Created on: 19.07.2018
 *      Author: Marcel Honegger
 */

#include "AtmelAT24C04.h"

using namespace std;

/**
 * Creates a device driver for an I2C EEPROM.
 * @param i2c a reference to an I2C device driver.
 */
AtmelAT24C04::AtmelAT24C04(I2C& i2c) : i2c(i2c) {}

/**
 * Deletes the I2C EEPROM device driver object.
 */
AtmelAT24C04::~AtmelAT24C04() {}

/**
 * Writes a byte to a specified address.
 * @param address a given byte address.
 * @param data the data byte to store at the given address.
 * @return an error code, 0 on sucess and other values on failure.
 */
int32_t AtmelAT24C04::write(uint16_t address, uint8_t data) {
    
    int32_t ack = -1;
    
    if (address < MEMORY_SIZE) {
        
        uint8_t slaveAddress = SLAVE_ADDRESS | (address >> 8);
        uint8_t buffer[2];
        buffer[0] = address & 0xFF;
        buffer[1] = data;
        uint16_t retries = 0;
        
        while ((ack != 0) && (retries++ < RETRIES)) {
            
            ack = i2c.write(slaveAddress << 1, (char*)buffer, 2);
        }
    }
    
    return ack;
}

/**
 * Reads a byte from a specified address.
 * @param address a given byte address.
 * @param data a reference to a data byte to copy the value at the given address into.
 * @return an error code, 0 on sucess and other values on failure.
 */
int32_t AtmelAT24C04::read(uint16_t address, uint8_t& data) {
    
    int32_t ack = -1;
    
    if (address < MEMORY_SIZE) {
        
        uint8_t slaveAddress = SLAVE_ADDRESS | (address >> 8);
        uint8_t buffer[1];
        buffer[0] = address & 0xFF;
        uint16_t retries = 0;
        
        while ((ack != 0) && (retries++ < RETRIES)) {
            
            ack = i2c.write(slaveAddress << 1, (char*)buffer, 1);
        }
        
        if (ack == 0) {
            
            buffer[0] = 0x00;
            
            ack = i2c.read(slaveAddress << 1, (char*)buffer, 1);
            data = buffer[0];
        }
    }
    
    return ack;
}
