/*
 * EEPROM.h
 * Copyright (c) 2018, ZHAW
 * All rights reserved.
 *
 *  Created on: 19.07.2018
 *      Author: Marcel Honegger
 */

#ifndef EEPROM_H_
#define EEPROM_H_

#include <cstdlib>
#include <stdint.h>

/**
 * This is an abstract device driver for an I2C EEPROM chip.
 */
class EEPROM {

    public:
        
        virtual int32_t     write(uint16_t address, uint8_t data);
        virtual int32_t     read(uint16_t address, uint8_t& data);
};

#endif /* EEPROM_H_ */
