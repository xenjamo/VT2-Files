/*
 * AtmelAT24C04.h
 * Copyright (c) 2018, ZHAW
 * All rights reserved.
 *
 *  Created on: 19.07.2018
 *      Author: Marcel Honegger
 */

#ifndef ATMEL_AT24C04_H_
#define ATMEL_AT24C04_H_

#include <cstdlib>
#include <stdint.h>
#include <mbed.h>
#include "EEPROM.h"

/**
 * This is a device driver for the Atmel AT24C04 I2C EEPROM chip.
 * The AT24C04 offers 4K bit of storage, organized as 32 pages of 16 bytes each.
 */
class AtmelAT24C04 : public EEPROM {

    public:
        
                    AtmelAT24C04(I2C& i2c);
        virtual     ~AtmelAT24C04();
        int32_t     write(uint16_t address, uint8_t data);
        int32_t     read(uint16_t address, uint8_t& data);
        
    private:
        
        static const uint8_t    SLAVE_ADDRESS = 0x50;   // I2C slave address of EEPROM
        static const uint16_t   MEMORY_SIZE = 512;      // size of EEPROM in [bytes]
        static const uint16_t   RETRIES = 100;          // number of write retries
        
        I2C&        i2c;
};

#endif /* ATMEL_AT24C04_H_ */
