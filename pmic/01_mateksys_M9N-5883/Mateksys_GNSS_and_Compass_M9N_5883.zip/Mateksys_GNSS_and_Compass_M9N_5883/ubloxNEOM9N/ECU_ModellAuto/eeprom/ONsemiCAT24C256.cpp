/*
 * ONsemiCAT24C256.cpp
 * Copyright (c) 2018, ZHAW
 * All rights reserved.
 *
 *  Created on: 09.08.2018
 *      Author: Marcel Honegger
 */

#include "ONsemiCAT24C256.h"

using namespace std;

/**
 * Creates a device driver for an I2C EEPROM.
 * @param i2c a reference to an I2C device driver.
 */
ONsemiCAT24C256::ONsemiCAT24C256(I2C& i2c) : i2c(i2c) {
    
    device = 0;
}

/**
 * Creates a device driver for an I2C EEPROM.
 * @param i2c a reference to an I2C device driver.
 * @param device the number of the device on the I2C bus.
 * This number must be between 0 and 7.
 */
ONsemiCAT24C256::ONsemiCAT24C256(I2C& i2c, uint8_t device) : i2c(i2c) {
    
    this->device = (device > 7) ? 7 : device;
}

/**
 * Deletes the I2C EEPROM device driver object.
 */
ONsemiCAT24C256::~ONsemiCAT24C256() {}

/**
 * Writes a byte to a specified address.
 * @param address a given byte address.
 * @param data the data byte to store at the given address.
 * @return an error code, 0 on sucess and other values on failure.
 */
int32_t ONsemiCAT24C256::write(uint16_t address, uint8_t data) {
    
    int32_t ack = -1;
    
    if (address < MEMORY_SIZE) {
        
        uint8_t slaveAddress = SLAVE_ADDRESS | device;
        uint8_t buffer[3];
        buffer[0] = (address >> 8) & 0xFF;
        buffer[1] = address & 0xFF;
        buffer[2] = data;
        uint16_t retries = 0;
        
        while ((ack != 0) && (retries++ < RETRIES)) {
            
            ack = i2c.write(slaveAddress << 1, (char*)buffer, 3);
        }
    }
    
    return ack;
}

/**
 * Reads a byte from a specified address.
 * @param address a given byte address.
 * @param data a reference to a data byte to copy the value at the given address into.
 * @return an error code, 0 on sucess and other values on failure.
 */
int32_t ONsemiCAT24C256::read(uint16_t address, uint8_t& data) {
    
    int32_t ack = -1;
    
    if (address < MEMORY_SIZE) {
        
        uint8_t slaveAddress = SLAVE_ADDRESS | device;
        uint8_t buffer[2];
        buffer[0] = (address >> 8) & 0xFF;
        buffer[1] = address & 0xFF;
        uint16_t retries = 0;
        
        while ((ack != 0) && (retries++ < RETRIES)) {
            
            ack = i2c.write(slaveAddress << 1, (char*)buffer, 2);
        }
        
        if (ack == 0) {
            
            buffer[0] = 0x00;
            
            ack = i2c.read(slaveAddress << 1, (char*)buffer, 1);
            data = buffer[0];
        }
    }
    
    return ack;
}
