/*
 * ONsemiCAT24C256.h
 * Copyright (c) 2018, ZHAW
 * All rights reserved.
 *
 *  Created on: 09.08.2018
 *      Author: Marcel Honegger
 */

#ifndef ON_SEMI_CAT24C256_H_
#define ON_SEMI_CAT24C256_H_

#include <cstdlib>
#include <stdint.h>
#include <mbed.h>
#include "EEPROM.h"

/**
 * This is a device driver for the ON semiconductor CAT24C256 I2C EEPROM chip.
 * The CAT24C256 offers 256K bit of storage, organized as 512 pages of 64 bytes each.
 */
class ONsemiCAT24C256 : public EEPROM {

    public:
        
                    ONsemiCAT24C256(I2C& i2c);
                    ONsemiCAT24C256(I2C& i2c, uint8_t device);
        virtual     ~ONsemiCAT24C256();
        int32_t     write(uint16_t address, uint8_t data);
        int32_t     read(uint16_t address, uint8_t& data);
        
    private:
        
        static const uint8_t    SLAVE_ADDRESS = 0x50;   // I2C slave address of EEPROM
        static const uint16_t   MEMORY_SIZE = 32768;    // size of EEPROM in [bytes]
        static const uint16_t   RETRIES = 100;          // number of write retries
        
        I2C&        i2c;
        uint8_t     device;
};

#endif /* ON_SEMI_CAT24C256_H_ */
