/*
 * Graupner.cpp
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 19.05.2021
 *      Author: Nicolas Borla
 */

#include "Graupner.h"
#include "RawSerial.h"
#include <cstdint>


using namespace std;

/**
 * Creates and initializes the driver to read a Graupner RC-Receiver. The Receiver provides an interface to read each channel. After instantiate the object, it has to be switched on 
 * (by using function switchOn()).
 * @param Tx The Tx Pin, which is not used and not connected.  
 * @param Rx The Rx Pin to the SUMD signal of the Graupner Receiver (eg. GR16)
 */
GraupnerReciver::GraupnerReciver(RawSerial& serial): serial(serial){

    // set all channel value to neutral position
    for(int i=0; i<NUMBER_OF_CHANNELS; i++){
        channelData[i] = 0x2EE0; // Neutral position
    }
    for(int i=0; i<21; i++){
        data[i] = 0x00;
    }
    dataCounter = 0;
    validRecivedCount = 0;
    messageRecivedCount = 0;

    watchDogTimer.reset();
    watchDogTimer.start();

    serial.baud(115200);

    serial.attach(callback(this,&GraupnerReciver::receiveData),RawSerial::RxIrq);

}

GraupnerReciver::~GraupnerReciver() {
}

void GraupnerReciver::receiveData(){

    if(serial.readable()){

        // get char
        char c = serial.getc();

        if (c!=0xA8) { //dataCounter < DATA_SIZE
                data[dataCounter] = c;
                dataCounter++;
            }
        if (c==0xA8) { //dataCounter >= DATA_SIZE
        
                if(data[0]==0x81){
                    // valid SUMD data frame with transmitter in fail safe condition (Transmitter turned off)
                    
                    //validMessages.push_back(false);
                } else if(data[0]==0x01 && data[1]==0x08 && dataCounter==20){

                    // reset watchdog
                    watchDogTimer.reset();
                    // valid and live SUMD data frame
                    channelData[0] = static_cast<uint16_t>((data[2]<<8) + data[3]);
                    channelData[1] = static_cast<uint16_t>((data[4]<<8) + data[5]);
                    channelData[2] = static_cast<uint16_t>((data[6]<<8) + data[7]);
                    channelData[3] = static_cast<uint16_t>((data[8]<<8) + data[9]);
                    channelData[4] = static_cast<uint16_t>((data[10]<<8) + data[11]);
                    channelData[5] = static_cast<uint16_t>((data[12]<<8) + data[13]);
                    channelData[6] = static_cast<uint16_t>((data[14]<<8) + data[15]);
                    channelData[7] = static_cast<uint16_t>((data[16]<<8) + data[17]);
                    

                    validRecivedCount++;
                } else {
                    // not valid
                    
                }
                
                // data buffer is full, process measurement
                
                
                // reset data counter
                
                dataCounter = 0;

                messageRecivedCount++;
            }

        if(messageRecivedCount>10){
            quality = (float)validRecivedCount/(float)messageRecivedCount;
            messageRecivedCount = 0;
            validRecivedCount = 0;
        }
    }    

}

/**
 * @brief Receiver::getChannelValue returns the raw channel value for the servo 
 * @return Value of the servo in: [0x1C20, 0x41A0] for the values in [-150%, 150%]. returns zero in case of data is not valid or if selected channel does not exist
 */
float GraupnerReciver::getChannelValue(uint8_t channel){
    if(channel < NUMBER_OF_CHANNELS){

        // Normalize value
        float valueToNorm = static_cast<float>(channelData[channel]);
        return (valueToNorm - MIN_GRAUPNER_VALUE)/(MAX_GRAUPNER_VALUE - MIN_GRAUPNER_VALUE)*2.0 - 1.0;

    } else {
        return 0.0;
    }
}

float GraupnerReciver::getQuality(){
    return quality;
}

int GraupnerReciver::getWatchdogTime(){
    return watchDogTimer.read_ms();
}