/*
 * ODStateMachine.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 19.03.2021
 *      Author: Nicolas Borla
 */

#ifndef OD_STATE_MACHINE_H
#define OD_STATE_MACHINE_H

#include <cstdlib>
#include <stdint.h>
#include "ODTypedEntry.h"
#include "StateMachine.h"

using namespace std;

/**
 * The <code>ODStateMachine</code> class implements an object dictionary entry
 * to read and write values in a stateMachine object.
 */
class ODStateMachine : public ODTypedEntry<int16_t> {
    
    public:


        static const uint8_t   WRITE_STEERING_ANGLE = 0;  
        static const uint8_t   WRITE_STEERING_SPEED = 1;               
        static const uint8_t   WRITE_VELOCITY = 2;                    
        static const uint8_t   WRITE_ACCELERATION = 3;              
        
        using                       ODTypedEntry<int16_t>::init;
        void                        init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, StateMachine* stateMachine, uint8_t valueID);
        virtual void                write(int16_t value);
        ODStateMachine&             operator=(int16_t value);
        virtual uint32_t            read(uint8_t buffer[], uint8_t& length);
        virtual int16_t             read();
                                    operator int16_t();
        
    private:
        
        StateMachine*               stateMachine;
        uint8_t                     valueID;
};

#endif /* OD_STATE_MACHINE_H */
