/*
 * ODPDOMappedObject.h
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#ifndef OD_PDO_MAPPED_OBJECT_H_
#define OD_PDO_MAPPED_OBJECT_H_

#include <cstdlib>
#include <stdint.h>
#include "ODTypedEntry.h"

using namespace std;

class ObjectDictionary;
class ODRecord;

/**
 * The <code>ODPDOMappedObject</code> class implements an object dictionary entry
 * to map objects for PDO communication.
 */
class ODPDOMappedObject : public ODTypedEntry<uint32_t> {
    
    public:
        
        using               ODTypedEntry<uint32_t>::init;
        void                init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, uint32_t defaultValue, ObjectDictionary* objectDictionary, ODRecord* record, uint8_t requiredAccess);
        virtual uint32_t    write(uint8_t buffer[], uint8_t& length);
        virtual void        write(uint32_t value);
        ODPDOMappedObject&  operator=(uint32_t value);
        
    private:
        
        ObjectDictionary*   objectDictionary;
        ODRecord*           record;
        uint8_t             requiredAccess;
};

#endif /* OD_PDO_MAPPED_OBJECT_H_ */
