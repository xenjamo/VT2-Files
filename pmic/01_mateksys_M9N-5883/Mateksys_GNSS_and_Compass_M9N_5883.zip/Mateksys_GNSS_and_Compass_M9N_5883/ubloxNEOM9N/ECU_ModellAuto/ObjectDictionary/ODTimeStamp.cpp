/*
 * ODTimeStamp.cpp
 * Copyright (c) 2016, ZHAW
 * All rights reserved.
 *
 *  Created on: 06.01.2016
 *      Author: Marcel Honegger
 */

#include "ODTimeStamp.h"

using namespace std;

/**
 * Initializes the time stamp object dictionary entry.
 */
void ODTimeStamp::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access) {
    
    ODTypedEntry<uint32_t>::init(index, subindex, type, bitlength, access);
    
    timer.start();
}

/**
 * Writes the value of this object dictionary entry.
 */
uint32_t ODTimeStamp::write(uint8_t buffer[], uint8_t& length) {
    
    uint32_t value = static_cast<uint32_t>(buffer[0]) | (static_cast<uint32_t>(buffer[1]) << 8) | (static_cast<uint32_t>(buffer[2]) << 16) | (static_cast<uint32_t>(buffer[3]) << 24);
    
    if (value == 0) {
        
        timer.reset();
        
        return ODTypedEntry<uint32_t>::write(buffer, length);
        
    } else {
        
        return CANopen::VALUE_RANGE_ERROR;
    }
}

/**
 * Writes the value of this object dictionary entry.
 */
void ODTimeStamp::write(uint32_t value) {
    
    if (value == 0) {
        
        timer.reset();
        ODTypedEntry<uint32_t>::write(value);
    }
}

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
ODTimeStamp& ODTimeStamp::operator=(uint32_t value) {
    
    write(value);
    
    return *this;
}

/**
 * Reads the value of this object dictionary entry.
 */
uint32_t ODTimeStamp::read(uint8_t buffer[], uint8_t& length) {
    
    value = timer.read_us();
    
    return ODTypedEntry<uint32_t>::read(buffer, length);
}

/**
 * Reads the value of this object dictionary entry.
 */
uint32_t ODTimeStamp::read() {
    
    value = timer.read_us();
    
    return value;
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
ODTimeStamp::operator uint32_t() {
    
    return read();
}
