/*
 * ODMotionEstimationValue.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 19.06.2021
 *      Author: Nicolas Borla
 */

#ifndef OD_MOTION_ESTIMATION_VALUE_H
#define OD_MOTION_ESTIMATION_VALUE_H

#include <cstdlib>
#include <stdint.h>
#include "ODTypedEntry.h"
#include "MotionEstimation.h"

using namespace std;

/**
 * The <code>ODMotionEstimationValue</code> class implements an object dictionary entry
 * to read the actual speed of the wheel and of the car from a motionEstimation object.
 */
class ODMotionEstimationValue : public ODTypedEntry<int16_t> {
    
    public:


        static const uint8_t   TRANSLATIONAL = 0;       // Translational speed [m/s]
        static const uint8_t   ROATATIONAL = 1;         // Rotational speed [rad/s]
        
        using                       ODTypedEntry<int16_t>::init;
        void                        init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, MotionEstimation* motionEstimation, uint8_t valueID);
        virtual uint32_t            read(uint8_t buffer[], uint8_t& length);
        virtual int16_t             read();
                                    operator int16_t();
        
    private:
        
        MotionEstimation*           motionEstimation;
        uint8_t                     valueID;
};

#endif /* OD_MOTION_ESTIMATION_VALUE_H */
