/*
 * ODControllerValue.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 12.02.2021
 *      Author: Nicolas Borla
 */

#ifndef OD_CONTROLLER_VALUE_H
#define OD_CONTROLLER_VALUE_H

#include <cstdlib>
#include <stdint.h>
#include "ODTypedEntry.h"
#include "Controller.h"

using namespace std;

/**
 * The <code>ODControllerValue</code> class implements an object dictionary entry
 * to read the actual speed of the wheel and of the car from a controller object.
 */
class ODControllerValue : public ODTypedEntry<int16_t> {
    
    public:


        static const uint8_t   FL = 0;                  // Front left wheel [rad/s]
        static const uint8_t   FR = 1;                  // Front right wheel [rad/s]
        static const uint8_t   RL = 2;                  // Rear left wheel [rad/s]
        static const uint8_t   RR = 3;                  // Rear right wheel [rad/s]
        static const uint8_t   TRANSLATIONAL = 4;       // Translational speed [m/s]
        static const uint8_t   ROATATIONAL = 5;         // Rotational speed [rad/s]
        static const uint8_t   PHASE_VOLTAGE = 6;       // Phase voltage [V]
        static const uint8_t   STEERING_ANGLE = 7;      // actual steering angle [rad]
        
        using                       ODTypedEntry<int16_t>::init;
        void                        init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, Controller* controller, uint8_t valueID);
        virtual uint32_t            read(uint8_t buffer[], uint8_t& length);
        virtual int16_t             read();
                                    operator int16_t();
        
    private:
        
        Controller*                 controller;
        uint8_t                     valueID;
};

#endif /* OD_CONTROLLER_VALUE_H */
