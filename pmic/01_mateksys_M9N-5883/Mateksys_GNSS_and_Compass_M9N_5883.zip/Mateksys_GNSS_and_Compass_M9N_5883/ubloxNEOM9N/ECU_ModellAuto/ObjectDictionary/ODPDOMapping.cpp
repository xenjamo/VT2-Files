/*
 * ODPDOMapping.cpp
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#include "ObjectDictionary.h"
#include "CANopen.h"
#include "ODTypedEntry.h"
#include "ODPDOMapping.h"

using namespace std;

/**
 * Initializes this record object dictionary entry.
 * @param index the index of the object.
 * @param access the supported access methods. This value is defined as
 * a bit pattern consisting of ACCESS_READ, ACCESS_WRITE, ACCESS_TXPDO,
 * ACCESS_RXPDO and ACCESS_BACKUP.
 */
void ODPDOMapping::init(uint16_t index, uint8_t access, ObjectDictionary* objectDictionary) {
    
    ODRecord::init(index, access);
    
    this->objectDictionary = objectDictionary;
}

/**
 * Writes the value of this record object dictionary entry.
 */
uint32_t ODPDOMapping::write(uint8_t buffer[], uint8_t& length) {
    
    if ((objectDictionary->canOpenNMTState == CANopen::STATE_INITIALISATION) || (objectDictionary->canOpenNMTState == CANopen::STATE_PRE_OPERATIONAL)) {
        
        uint8_t value = buffer[0];
        
        if (value > ObjectDictionary::NUMBER_OF_OBJECTS) {
            
            return CANopen::VALUE_TOO_HIGH_ERROR;
            
        } else {
            
            uint16_t pdoLength = 0;
            
            for (uint8_t i = 0; i < value; i++) {
                
                if (static_cast<ODTypedEntry<uint32_t>*>(entries[i])->read() == 0x00000000) return CANopen::PDO_MAPPING_ERROR;
                pdoLength += (static_cast<ODTypedEntry<uint32_t>*>(entries[i])->read() & 0xFF)/8;
            }
            
            if (pdoLength > MAX_PDO_LENGTH) return CANopen::PDO_LENGTH_ERROR;
            
            return ODRecord::write(buffer, length);
        }
        
    } else {
        
        return CANopen::WRONG_NMT_STATE_ERROR;
    }
}

/**
 * Writes the value of this record object dictionary entry.
 */
void ODPDOMapping::write(uint8_t value) {
    
    if ((objectDictionary->canOpenNMTState == CANopen::STATE_INITIALISATION) || (objectDictionary->canOpenNMTState == CANopen::STATE_PRE_OPERATIONAL)) {
        
        if (value <= ObjectDictionary::NUMBER_OF_OBJECTS) {
            
            ODRecord::write(value);
        }
    }
}

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
ODPDOMapping& ODPDOMapping::operator=(uint8_t value) {
    
    write(value);
    
    return *this;
}
