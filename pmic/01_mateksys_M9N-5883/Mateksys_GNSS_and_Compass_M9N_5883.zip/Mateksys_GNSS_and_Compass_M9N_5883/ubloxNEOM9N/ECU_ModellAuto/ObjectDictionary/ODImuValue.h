/*
 * ODImuValue.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 12.02.2021
 *      Author: Nicolas Borla
 */

#ifndef OD_IMU_VALUE_H
#define OD_IMU_VALUE_H

#include <cstdlib>
#include <stdint.h>
#include "ODTypedEntry.h"
#include "OpenIMU300ZI.h"

using namespace std;

/**
 * The <code>ODImuValue</code> class implements an object dictionary entry
 * to read value of the IMU.
 */
class ODImuValue : public ODTypedEntry<int16_t> {
    
    public:


        static const uint8_t   ACCELERATION_X = 0;                  // get acceleration in X, in [m/s²]
        static const uint8_t   ACCELERATION_Y = 1;                  // get acceleration in Y, in [m/s²]
        static const uint8_t   ACCELERATION_Z = 2;                  // get acceleration in Z, in [m/s²]
        static const uint8_t   GYRO_X = 3;                          // get angular speed about X, in [rad/s]
        static const uint8_t   GYRO_Y = 4;                          // get angular speed about Y, in [rad/s]
        static const uint8_t   GYRO_Z = 5;                          // get angular speed about Z, in [rad/s]
        static const uint8_t   MAGNETOMETER_X = 6;                  // get the magnetic field strngth in X, in [Gauss]
        static const uint8_t   MAGNETOMETER_Y = 7;                  // get the magnetic field strngth in Y, in [Gauss]
        static const uint8_t   MAGNETOMETER_Z = 8;                  // get the magnetic field strngth in Z, in [Gauss]
        static const uint8_t   ROLL = 9;                            // get roll angle in [rad]
        static const uint8_t   PITCH = 10;                          // get pitch angle in [rad]
        static const uint8_t   YAW = 11;                            // get yaw angle in [rad]
        static const uint8_t   ROLL_RATE = 12;                      // get roll angular speed in [rad/s]
        static const uint8_t   PITCH_RATE = 13;                     // get pitch angular speed in [rad/s]
        static const uint8_t   YAW_RATE = 14;                       // get yaw angular speed in [rad/s]

        static constexpr double INT_TO_DOUBLE_FACTOR = 1000.0;             // factor to transform double in integer value
        
        using                       ODTypedEntry<int16_t>::init;
        void                        init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, OpenIMU300ZI* imu, uint8_t valueID);
        virtual uint32_t            read(uint8_t buffer[], uint8_t& length);
        virtual int16_t             read();
                                    operator int16_t();
        
    private:
        
        OpenIMU300ZI*               imu;
        uint8_t                     valueID;
};

#endif /* OD_IMU_VALUE_H */
