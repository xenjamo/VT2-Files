/*
 * ODRestoreAllDefaultParameters.cpp
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#include "ObjectDictionary.h"
#include "CANopen.h"
#include "ODRestoreAllDefaultParameters.h"

using namespace std;

void ODRestoreAllDefaultParameters::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, uint32_t defaultValue, uint32_t minValue, uint32_t maxValue, ObjectDictionary* objectDictionary) {
    
    ODTypedEntry<uint32_t>::init(index, subindex, type, bitlength, access, defaultValue, minValue, maxValue);
    
    this->objectDictionary = objectDictionary;
}

/**
 * Writes the value of this object dictionary entry.
 */
uint32_t ODRestoreAllDefaultParameters::write(uint8_t buffer[], uint8_t& length) {
    
    uint32_t abortCode = CANopen::NO_COMMUNICATION_ERROR;
    
    if ((objectDictionary->canOpenNMTState == CANopen::STATE_INITIALISATION) || (objectDictionary->canOpenNMTState == CANopen::STATE_PRE_OPERATIONAL)) {
        
        abortCode = ODTypedEntry<uint32_t>::write(buffer, length);
        if (abortCode == CANopen::NO_COMMUNICATION_ERROR) abortCode = objectDictionary->loadDefaultParameters();
        
    } else {
        
        abortCode = CANopen::WRONG_NMT_STATE_ERROR;
    }
    
    return abortCode;
}

/**
 * Writes the value of this object dictionary entry.
 */
void ODRestoreAllDefaultParameters::write(uint32_t value) {
    
    if ((objectDictionary->canOpenNMTState == CANopen::STATE_INITIALISATION) || (objectDictionary->canOpenNMTState == CANopen::STATE_PRE_OPERATIONAL)) {
        
        if (value == 0x64616F6C) {
            
            ODTypedEntry<uint32_t>::write(value);
            objectDictionary->loadDefaultParameters();
        }
    }
}

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
ODRestoreAllDefaultParameters& ODRestoreAllDefaultParameters::operator=(uint32_t value) {
    
    write(value);
    
    return *this;
}
