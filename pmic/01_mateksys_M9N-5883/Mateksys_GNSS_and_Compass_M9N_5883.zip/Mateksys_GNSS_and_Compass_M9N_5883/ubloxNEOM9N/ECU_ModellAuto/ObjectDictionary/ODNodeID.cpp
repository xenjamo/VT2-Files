/*
 * ODNodeID.cpp
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#include "ObjectDictionary.h"
#include "CANopen.h"
#include "ODNodeID.h"

using namespace std;

/**
 * Initializes the node ID object dictionary entry with a default, minimum and maximum values.
 */
void ODNodeID::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, uint8_t defaultValue, uint8_t minValue, uint8_t maxValue, ObjectDictionary* objectDictionary) {
    
    ODTypedEntry<uint8_t>::init(index, subindex, type, bitlength, access, defaultValue, minValue, maxValue);
    
    this->objectDictionary = objectDictionary;
}

/**
 * Writes the value of this object dictionary entry.
 */
uint32_t ODNodeID::write(uint8_t buffer[], uint8_t& length) {
    
    uint32_t abortCode = CANopen::NO_COMMUNICATION_ERROR;
    
    if ((objectDictionary->canOpenNMTState == CANopen::STATE_INITIALISATION) || (objectDictionary->canOpenNMTState == CANopen::STATE_PRE_OPERATIONAL)) {
        
        abortCode = ODTypedEntry<uint8_t>::write(buffer, length);
        
        if (abortCode == CANopen::NO_COMMUNICATION_ERROR) {
            
            objectDictionary->cobIDReceivePDO1 = (objectDictionary->cobIDReceivePDO1 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::RPDO1+value);
            objectDictionary->cobIDReceivePDO2 = (objectDictionary->cobIDReceivePDO2 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::RPDO2+value);
            objectDictionary->cobIDReceivePDO3 = (objectDictionary->cobIDReceivePDO3 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::RPDO3+value);
            objectDictionary->cobIDReceivePDO4 = (objectDictionary->cobIDReceivePDO4 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::RPDO4+value);
            objectDictionary->cobIDTransmitPDO1 = (objectDictionary->cobIDTransmitPDO1 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::TPDO1+value);
            objectDictionary->cobIDTransmitPDO2 = (objectDictionary->cobIDTransmitPDO2 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::TPDO2+value);
            objectDictionary->cobIDTransmitPDO3 = (objectDictionary->cobIDTransmitPDO3 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::TPDO3+value);
            objectDictionary->cobIDTransmitPDO4 = (objectDictionary->cobIDTransmitPDO4 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::TPDO4+value);
        }
        
    } else {
        
        abortCode = CANopen::WRONG_NMT_STATE_ERROR;
    }
    
    return abortCode;
}

/**
 * Writes the value of this object dictionary entry.
 */
void ODNodeID::write(uint8_t value) {
    
    if ((objectDictionary->canOpenNMTState == CANopen::STATE_INITIALISATION) || (objectDictionary->canOpenNMTState == CANopen::STATE_PRE_OPERATIONAL)) {
        
        ODTypedEntry<uint8_t>::write(value);
        
        objectDictionary->cobIDReceivePDO1 = (objectDictionary->cobIDReceivePDO1 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::RPDO1+value);
        objectDictionary->cobIDReceivePDO2 = (objectDictionary->cobIDReceivePDO2 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::RPDO2+value);
        objectDictionary->cobIDReceivePDO3 = (objectDictionary->cobIDReceivePDO3 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::RPDO3+value);
        objectDictionary->cobIDReceivePDO4 = (objectDictionary->cobIDReceivePDO4 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::RPDO4+value);
        objectDictionary->cobIDTransmitPDO1 = (objectDictionary->cobIDTransmitPDO1 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::TPDO1+value);
        objectDictionary->cobIDTransmitPDO2 = (objectDictionary->cobIDTransmitPDO2 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::TPDO2+value);
        objectDictionary->cobIDTransmitPDO3 = (objectDictionary->cobIDTransmitPDO3 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::TPDO3+value);
        objectDictionary->cobIDTransmitPDO4 = (objectDictionary->cobIDTransmitPDO4 & ~CANopen::CAN_ID_MASK) | static_cast<uint32_t>(CANopen::TPDO4+value);
    }
}

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
ODNodeID& ODNodeID::operator=(uint8_t value) {
    
    write(value);
    
    return *this;
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
ODNodeID::operator uint8_t() {
    
    return read();
}
