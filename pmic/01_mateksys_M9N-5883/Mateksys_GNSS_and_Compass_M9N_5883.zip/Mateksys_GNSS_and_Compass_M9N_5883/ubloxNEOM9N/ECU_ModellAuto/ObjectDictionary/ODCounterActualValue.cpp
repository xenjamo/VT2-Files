/*
 * ODCounterActualValue.h
 * Copyright (c) 2016, ZHAW
 * All rights reserved.
 *
 *  Created on: 05.02.2021
 *      Author: Nicolas Borla
 */

#include "ODCounterActualValue.h"
#include "EncoderF767ZI.h"

using namespace std;

/**
 * Initializes the position actual value object dictionary entry.
 */
void ODCounterActualValue::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, EncoderCounter* counter) {
    
    ODTypedEntry<int16_t>::init(index, subindex, type, bitlength, access);
    
    this->counter = counter;
}

/**
 * Writes the value of this object dictionary entry.
 */
void ODCounterActualValue::write(int16_t value) {
    
    ODTypedEntry<int16_t>::write(value);
    counter->reset(value);
}

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
ODCounterActualValue& ODCounterActualValue::operator=(int16_t value) {
    
    write(value);
    
    return *this;
}

/**
 * Reads the value of this object dictionary entry.
 */
uint32_t ODCounterActualValue::read(uint8_t buffer[], uint8_t& length) {
    
    value = counter->read();
    
    return ODTypedEntry<int16_t>::read(buffer, length);
}

/**
 * Reads the value of this object dictionary entry.
 */
int16_t ODCounterActualValue::read() {
    
    value = counter->read();

    return value;
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
ODCounterActualValue::operator int16_t() {
    
    return read();
}
