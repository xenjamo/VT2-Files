/*
 * ODTimeStamp.h
 * Copyright (c) 2016, ZHAW
 * All rights reserved.
 *
 *  Created on: 06.01.2016
 *      Author: Marcel Honegger
 */

#ifndef OD_TIME_STAMP_H_
#define OD_TIME_STAMP_H_

#include <cstdlib>
#include <stdint.h>
#include <mbed.h>
#include "ODTypedEntry.h"

using namespace std;

/**
 * The <code>ODTimeStamp</code> class implements an object dictionary entry
 * to read a device internal timer.
 */
class ODTimeStamp : public ODTypedEntry<uint32_t> {
    
    public:
        
        using               ODTypedEntry<uint32_t>::init;
        virtual void        init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access);
        virtual uint32_t    write(uint8_t buffer[], uint8_t& length);
        virtual void        write(uint32_t value);
        ODTimeStamp&        operator=(uint32_t value);
        virtual uint32_t    read(uint8_t buffer[], uint8_t& length);
        virtual uint32_t    read();
                            operator uint32_t();
        
    private:
        
        Timer               timer;
};

#endif /* OD_TIME_STAMP_H_ */
