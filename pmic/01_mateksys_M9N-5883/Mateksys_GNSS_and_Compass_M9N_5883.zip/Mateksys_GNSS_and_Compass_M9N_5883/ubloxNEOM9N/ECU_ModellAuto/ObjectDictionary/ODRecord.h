/*
 * ODRecord.h
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#ifndef OD_RECORD_H_
#define OD_RECORD_H_

#include <cstdlib>
#include <cstdarg>
#include <string>
#include <vector>
#include <stdint.h>
#include "ODEntry.h"

using namespace std;

/**
 * The <code>ODRecord</code> class is a specific implementation of an object dictionary
 * entry that represents a record. It's value corresponds to the value of the record's
 * subindex 0, which represents the number of subindices.
 */
class ODRecord : public ODEntry {
    
    public:
        
                                ODRecord();
        virtual                 ~ODRecord();
        using                   ODEntry::init;
        virtual void            init(uint16_t index, uint8_t access);
        virtual void            init(uint16_t index, uint8_t access, uint8_t value, ...);
        virtual void            addEntry(ODEntry* entry);
        virtual void            setDefault();
        virtual void            setDefault(uint8_t defaultValue);
        virtual void            setMaxValue(uint8_t maxValue);
        virtual uint32_t        write(uint8_t buffer[], uint8_t& length);
        virtual void            write(uint8_t value);
        ODRecord&               operator=(uint8_t value);
        virtual uint32_t        read(uint8_t buffer[], uint8_t& length);
        virtual uint8_t         read();
                                operator uint8_t();

        vector<ODEntry*>        entries;

    protected:
        
        uint8_t                 value;
        uint8_t                 defaultValue;
        uint8_t                 maxValue;
};

#endif /* OD_RECORD_H_ */
