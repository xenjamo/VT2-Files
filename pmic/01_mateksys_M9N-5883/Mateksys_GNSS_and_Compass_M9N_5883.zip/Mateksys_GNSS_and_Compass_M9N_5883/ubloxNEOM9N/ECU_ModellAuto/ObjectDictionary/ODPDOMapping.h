/*
 * ODPDOMapping.h
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#ifndef OD_PDO_MAPPING_H_
#define OD_PDO_MAPPING_H_

#include <cstdlib>
#include <cstdarg>
#include <vector>
#include <stdint.h>
#include "ODRecord.h"

using namespace std;

class ObjectDictionary;

/**
 * The <code>ODPDOMapping</code> class is a specific implementation of an object dictionary
 * entry that represents a record with mapped objects for PDO communication.
 */
class ODPDOMapping : public ODRecord {
    
    public:
        
        using                   ODRecord::init;
        void                    init(uint16_t index, uint8_t access, ObjectDictionary* objectDictionary);
        virtual uint32_t        write(uint8_t buffer[], uint8_t& length);
        virtual void            write(uint8_t value);
        ODPDOMapping&           operator=(uint8_t value);
        
    private:
        
        static const uint8_t    MAX_PDO_LENGTH = 8;     // max number of bytes in a PDO
        
        ObjectDictionary*       objectDictionary;
};

#endif /* OD_PDO_MAPPING_H_ */
