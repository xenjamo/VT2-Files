/*
 * ODNodeID.h
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#ifndef OD_NODE_ID_H_
#define OD_NODE_ID_H_

#include <cstdlib>
#include <stdint.h>
#include "ODTypedEntry.h"

using namespace std;

class ObjectDictionary;

/**
 * The <code>ODNodeID</code> class implements an object dictionary entry
 * to set and read the node ID used for CANopen communication.
 */
class ODNodeID : public ODTypedEntry<uint8_t> {
    
    public:
        
        using               ODTypedEntry<uint8_t>::init;
        void                init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, uint8_t defaultValue, uint8_t minValue, uint8_t maxValue, ObjectDictionary* objectDictionary);
        virtual uint32_t    write(uint8_t buffer[], uint8_t& length);
        virtual void        write(uint8_t value);
        ODNodeID&           operator=(uint8_t value);
                            operator uint8_t();
        
    private:
        
        ObjectDictionary*   objectDictionary;
};

#endif /* OD_NODE_ID_H_ */
