/*
 * ODErrorHistory.cpp
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#include "ObjectDictionary.h"
#include "CANopen.h"
#include "ODErrorHistory.h"

using namespace std;

/**
 * Initializes this record object dictionary entry.
 * @param index the index of the object.
 * @param access the supported access methods. This value is defined as
 * a bit pattern consisting of ACCESS_READ, ACCESS_WRITE, ACCESS_TXPDO,
 * ACCESS_RXPDO and ACCESS_BACKUP.
 * @param objectDictionary a reference to the object dictionary.
 */
void ODErrorHistory::init(uint16_t index, uint8_t access, ObjectDictionary* objectDictionary) {
    
    ODRecord::init(index, access);
    
    this->objectDictionary = objectDictionary;
}

/**
 * Writes the value of this record object dictionary entry.
 */
uint32_t ODErrorHistory::write(uint8_t buffer[], uint8_t& length) {
    
    uint8_t value = buffer[0];
    
    if (value == 0) {
        
        // clear errors in this record
        
        for (uint8_t i = 0; i < ObjectDictionary::NUMBER_OF_ERRORS; i++) objectDictionary->error[i] = 0x00000000;
        
        return ODRecord::write(buffer, length);
        
    } else {
        
        return CANopen::VALUE_RANGE_ERROR;
    }
}

/**
 * Writes the value of this record object dictionary entry.
 */
void ODErrorHistory::write(uint8_t value) {
    
    if (value == 0) {
        
        // clear errors in this record
        
        for (uint8_t i = 0; i < ObjectDictionary::NUMBER_OF_ERRORS; i++) objectDictionary->error[i] = 0x00000000;
        
        ODRecord::write(value);
    }
}

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
ODErrorHistory& ODErrorHistory::operator=(uint8_t value) {
    
    write(value);
    
    return *this;
}

/**
 * Adds a new error to this error history.
 * This error is stored at subindex 1, while previous errors are shifted
 * down by one subindex in this error history record.
 */
void ODErrorHistory::addError(uint32_t error) {
    
    for (uint8_t i = ObjectDictionary::NUMBER_OF_ERRORS-1; i > 0; i--) {
        uint32_t previousError = objectDictionary->error[i-1].read();
        objectDictionary->error[i].write(previousError);
    }
    objectDictionary->error[0].write(error);
    
    if (value < ObjectDictionary::NUMBER_OF_ERRORS) value++;
}
