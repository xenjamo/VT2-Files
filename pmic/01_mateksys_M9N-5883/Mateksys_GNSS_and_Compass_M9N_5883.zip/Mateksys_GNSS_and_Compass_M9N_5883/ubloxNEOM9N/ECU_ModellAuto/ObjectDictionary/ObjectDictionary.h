/*
 * ObjectDictionary.h
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#ifndef OBJECT_DICTIONARY_H_
#define OBJECT_DICTIONARY_H_

#include <cstdlib>
#include <vector>
#include <stdint.h>
#include "AnalogIn.h"
#include "EncoderF767ZI.h"
#include "Controller.h"
#include "MotionEstimation.h"
#include "ODRecord.h"
#include "ODTypedEntry.h"
#include "ODErrorRegister.h"
#include "ODErrorHistory.h"
#include "ODSaveAllParameters.h"
#include "ODRestoreAllDefaultParameters.h"
#include "ODPDOMapping.h"
#include "ODPDOMappedObject.h"
#include "ODNodeID.h"
#include "ODTimeStamp.h"
#include "ODCounterActualValue.h"
#include "ODControllerValue.h"
#include "ODImuValue.h"
#include "OpenIMU300ZI.h"
#include "ODAnalogInValue.h"
#include "Stream.h"
#include "ODMotionEstimationValue.h"


using namespace std;

class EEPROM;
class EncoderCounter;
class Controller;
class StateMachine;

/**
 * The <code>ObjectDictionary</code> class holds a list of all CANopen object
 * dictionary entries, as well as named field objects of these entries.
 */
class ObjectDictionary {
    
    public:
        
        static const uint8_t    NUMBER_OF_ERRORS = 5;       /**< Defines the number of errors in the error history. */
        static const uint8_t    NUMBER_OF_OBJECTS = 8;      /**< Defines the maximum number of objects in PDOs. */
        
        ODTypedEntry<uint32_t>              deviceType;                                     // 0x1000 / 0x00 / R
        ODErrorRegister                     errorRegister;                                  // 0x1001 / 0x00 / R
        ODErrorHistory                      errorHistory;                                   // 0x1003 / 0x00 / RW
        ODTypedEntry<uint32_t>              error[NUMBER_OF_ERRORS];                        // 0x1003 / 0x0X / R
        ODTypedEntry<uint32_t>              manufacturerDeviceName;                         // 0x1008 / 0x00 / R
        ODRecord                            storeParameters;                                // 0x1010 / 0x00 / R
        ODSaveAllParameters                 saveAllParameters;                              // 0x1010 / 0x01 / RW
        ODRecord                            restoreDefaultParameters;                       // 0x1011 / 0x00 / R
        ODRestoreAllDefaultParameters       restoreAllDefaultParameters;                    // 0x1011 / 0x01 / RW
        ODRecord                            consumerHeartbeatTime;                          // 0x1016 / 0x00 / R
        ODTypedEntry<uint32_t>              consumer1HeartbeatTime;                         // 0x1016 / 0x01 / RW
        ODTypedEntry<uint16_t>              producerHeartbeatTime;                          // 0x1017 / 0x00 / RW
        ODRecord                            identityObject;                                 // 0x1018 / 0x00 / R
        ODTypedEntry<uint32_t>              vendorID;                                       // 0x1018 / 0x01 / R
        ODTypedEntry<uint32_t>              productCode;                                    // 0x1018 / 0x02 / R
        ODTypedEntry<uint32_t>              revisionNumber;                                 // 0x1018 / 0x03 / R
        ODTypedEntry<uint32_t>              serialNumber;                                   // 0x1018 / 0x04 / R
        ODRecord                            receivePDO1Parameter;                           // 0x1400 / 0x00 / R
        ODTypedEntry<uint32_t>              cobIDReceivePDO1;                               // 0x1400 / 0x01 / RW
        ODTypedEntry<uint8_t>               transmissionTypeReceivePDO1;                    // 0x1400 / 0x02 / RW
        ODRecord                            receivePDO2Parameter;                           // 0x1401 / 0x00 / R
        ODTypedEntry<uint32_t>              cobIDReceivePDO2;                               // 0x1401 / 0x01 / RW
        ODTypedEntry<uint8_t>               transmissionTypeReceivePDO2;                    // 0x1401 / 0x02 / RW
        ODRecord                            receivePDO3Parameter;                           // 0x1402 / 0x00 / R
        ODTypedEntry<uint32_t>              cobIDReceivePDO3;                               // 0x1402 / 0x01 / RW
        ODTypedEntry<uint8_t>               transmissionTypeReceivePDO3;                    // 0x1402 / 0x02 / RW
        ODRecord                            receivePDO4Parameter;                           // 0x1403 / 0x00 / R
        ODTypedEntry<uint32_t>              cobIDReceivePDO4;                               // 0x1403 / 0x01 / RW
        ODTypedEntry<uint8_t>               transmissionTypeReceivePDO4;                    // 0x1403 / 0x02 / RW
        ODPDOMapping                        receivePDO1Mapping;                             // 0x1600 / 0x00 / RW
        ODPDOMappedObject                   receivePDO1MappedObject[NUMBER_OF_OBJECTS];     // 0x1600 / 0x0X / RW
        ODPDOMapping                        receivePDO2Mapping;                             // 0x1601 / 0x00 / RW
        ODPDOMappedObject                   receivePDO2MappedObject[NUMBER_OF_OBJECTS];     // 0x1601 / 0x0X / RW
        ODPDOMapping                        receivePDO3Mapping;                             // 0x1602 / 0x00 / RW
        ODPDOMappedObject                   receivePDO3MappedObject[NUMBER_OF_OBJECTS];     // 0x1602 / 0x0X / RW
        ODPDOMapping                        receivePDO4Mapping;                             // 0x1603 / 0x00 / RW
        ODPDOMappedObject                   receivePDO4MappedObject[NUMBER_OF_OBJECTS];     // 0x1603 / 0x0X / RW
        ODRecord                            transmitPDO1Parameter;                          // 0x1800 / 0x00 / R
        ODTypedEntry<uint32_t>              cobIDTransmitPDO1;                              // 0x1800 / 0x01 / RW
        ODTypedEntry<uint8_t>               transmissionTypeTransmitPDO1;                   // 0x1800 / 0x02 / RW
        ODTypedEntry<uint16_t>              inhibitTimeTransmitPDO1;                        // 0x1800 / 0x03 / RW
        ODRecord                            transmitPDO2Parameter;                          // 0x1801 / 0x00 / R
        ODTypedEntry<uint32_t>              cobIDTransmitPDO2;                              // 0x1801 / 0x01 / RW
        ODTypedEntry<uint8_t>               transmissionTypeTransmitPDO2;                   // 0x1801 / 0x02 / RW
        ODTypedEntry<uint16_t>              inhibitTimeTransmitPDO2;                        // 0x1801 / 0x03 / RW
        ODRecord                            transmitPDO3Parameter;                          // 0x1802 / 0x00 / R
        ODTypedEntry<uint32_t>              cobIDTransmitPDO3;                              // 0x1802 / 0x01 / RW
        ODTypedEntry<uint8_t>               transmissionTypeTransmitPDO3;                   // 0x1802 / 0x02 / RW
        ODTypedEntry<uint16_t>              inhibitTimeTransmitPDO3;                        // 0x1802 / 0x03 / RW
        ODRecord                            transmitPDO4Parameter;                          // 0x1803 / 0x00 / R
        ODTypedEntry<uint32_t>              cobIDTransmitPDO4;                              // 0x1803 / 0x01 / RW
        ODTypedEntry<uint8_t>               transmissionTypeTransmitPDO4;                   // 0x1803 / 0x02 / RW
        ODTypedEntry<uint16_t>              inhibitTimeTransmitPDO4;                        // 0x1803 / 0x03 / RW
        ODPDOMapping                        transmitPDO1Mapping;                            // 0x1A00 / 0x00 / RW
        ODPDOMappedObject                   transmitPDO1MappedObject[NUMBER_OF_OBJECTS];    // 0x1A00 / 0x0X / RW
        ODPDOMapping                        transmitPDO2Mapping;                            // 0x1A01 / 0x00 / RW
        ODPDOMappedObject                   transmitPDO2MappedObject[NUMBER_OF_OBJECTS];    // 0x1A01 / 0x0X / RW
        ODPDOMapping                        transmitPDO3Mapping;                            // 0x1A02 / 0x00 / RW
        ODPDOMappedObject                   transmitPDO3MappedObject[NUMBER_OF_OBJECTS];    // 0x1A02 / 0x0X / RW
        ODPDOMapping                        transmitPDO4Mapping;                            // 0x1A03 / 0x00 / RW
        ODPDOMappedObject                   transmitPDO4MappedObject[NUMBER_OF_OBJECTS];    // 0x1A03 / 0x0X / RW
        ODNodeID                            nodeID;                                         // 0x2000 / 0x00 / RW
        ODTypedEntry<int8_t>                canBitrate;                                     // 0x2001 / 0x00 / RW
        ODTypedEntry<uint8_t>               canOpenNMTState;                                // 0x2002 / 0x00 / R
        ODTimeStamp                         timeStamp;                                      // 0x2003 / 0x00 / RW
        ODRecord                            consumerHeartbeatTimer;                         // 0x2004 / 0x00 / R
        ODTypedEntry<uint32_t>              consumer1HeartbeatTimer;                        // 0x2004 / 0x01 / R

        // ECU specific Objects
        ODTypedEntry<int16_t>               ledStatus;                                      // 0x2203 / 0x00 / RW
        ODCounterActualValue                counterActualValueFL;                           // 0x2300 / 0x00 / RW   / counts encoder front left
        ODCounterActualValue                counterActualValueFR;                           // 0x2302 / 0x00 / RW   / counts encoder front right
        ODCounterActualValue                counterActualValueRL;                           // 0x2304 / 0x00 / RW   / counts encoder rear left
        ODCounterActualValue                counterActualValueRR;                           // 0x2306 / 0x00 / RW   / counts encoder rear right
        ODControllerValue                   actualSpeedFL;                                  // 0x2310 / 0x00 / R    / [rad/s]
        ODControllerValue                   actualSpeedFR;                                  // 0x2312 / 0x00 / R    / [rad/s]
        ODControllerValue                   actualSpeedRL;                                  // 0x2314 / 0x00 / R    / [rad/s]
        ODControllerValue                   actualSpeedRR;                                  // 0x2316 / 0x00 / R    / [rad/s]
        ODControllerValue                   actualTranslationalVelocity;                    // 0x2318 / 0x00 / R    / [m/s]
        ODControllerValue                   actualRotationalVelocity;                       // 0x2320 / 0x00 / R    / [rad/s]
        ODImuValue                          accelerationX;                                  // 0x2400 / 0x00 / R    / [m/s²]
        ODImuValue                          accelerationY;                                  // 0x2402 / 0x00 / R    / [m/s²]
        ODImuValue                          accelerationZ;                                  // 0x2404 / 0x00 / R    / [m/s²]
        ODImuValue                          gyroX;                                          // 0x2406 / 0x00 / R    / [m/s]
        ODImuValue                          gyroY;                                          // 0x2408 / 0x00 / R    / [m/s]
        ODImuValue                          gyroZ;                                          // 0x2410 / 0x00 / R    / [m/s]
        ODImuValue                          magnetometerX;                                  // 0x2412 / 0x00 / R    / [Gauss]
        ODImuValue                          magnetometerY;                                  // 0x2414 / 0x00 / R    / [Gauss]
        ODImuValue                          magnetometerZ;                                  // 0x2416 / 0x00 / R    / [Gauss]
        ODImuValue                          roll;                                           // 0x2418 / 0x00 / R    / [rad]
        ODImuValue                          pitch;                                          // 0x2420 / 0x00 / R    / [rad]
        ODImuValue                          yaw;                                            // 0x2422 / 0x00 / R    / [rad]
        ODImuValue                          rollRate;                                       // 0x2424 / 0x00 / R    / [rad/s]
        ODImuValue                          pitchRate;                                      // 0x2426 / 0x00 / R    / [rad/s]
        ODImuValue                          yawRate;                                        // 0x2428 / 0x00 / R    / [rad/s]
        ODTypedEntry<int8_t>                enableMotor;                                    // 0x2504 / 0x00 / RW   / [bool]
        ODTypedEntry<int8_t>                enableSteering;                                 // 0x2506 / 0x00 / RW   / [bool]
        ODControllerValue                   phaseVoltage;                                   // 0x2508 / 0x00 / R    / [V]
        ODAnalogInValue                     batteryVoltage;                                 // 0x2510 / 0x00 / R    / [V]
        ODControllerValue                   actualSteeringAngle;                            // 0x2512 / 0x00 / R    / [rad]
        ODTypedEntry<int16_t>               desiredSteeringAngle;                           // 0x2514 / 0x00 / RW   / [rad]
        ODTypedEntry<int16_t>               desiredSteeringSpeed;                           // 0x2516 / 0x00 / RW   / [rad/s]
        ODTypedEntry<int16_t>               desiredTranslationalVelocity;                   // 0x2518 / 0x00 / RW   / [m/s]
        ODTypedEntry<int16_t>               desiredTranslationalAcceleration;               // 0x2520 / 0x00 / RW   / [m/s²]
        ODMotionEstimationValue             ekfTranslationalVelocity;                       // 0x2522 / 0x00 / RW   / [m/s]
        ODMotionEstimationValue             ekfRotationalVelocity;                          // 0x2524 / 0x00 / RW   / [rad/s]

        // ToDo: add getState and setStateDemand

    
        vector<ODEntry*>                    entries;
        
                    ObjectDictionary(EEPROM& eeprom, EncoderCounter* counterFL, EncoderCounter* counterFR, EncoderCounter* counterRL, EncoderCounter* counterRR, Controller* controller, OpenIMU300ZI* imu, AnalogIn* batteryVoltageSensor, MotionEstimation* MotionEstimation);
        virtual     ~ObjectDictionary();
        ODEntry*    findODEntry(uint16_t index, uint8_t subindex);
        uint32_t    saveParameters();
        uint32_t    loadParameters();
        uint32_t    loadDefaultParameters();
        uint32_t    writeObject(uint16_t index, uint8_t subindex, uint8_t buffer[], uint8_t& length);
        uint32_t    readObject(uint16_t index, uint8_t subindex, uint8_t buffer[], uint8_t& length);
        void        configureRxPDOs();
        void        configureTxPDOs();
        uint32_t    writeRxPDO(uint8_t pdo, uint8_t buffer[], uint8_t& length);
        uint32_t    readTxPDO(uint8_t pdo, uint8_t buffer[], uint8_t& length);
        
    private:
        
        EEPROM&                 eeprom;
        
        vector<ODEntry*>        rxPDO1;
        vector<ODEntry*>        rxPDO2;
        vector<ODEntry*>        rxPDO3;
        vector<ODEntry*>        rxPDO4;
        uint8_t                 rxPDO1Length;
        uint8_t                 rxPDO2Length;
        uint8_t                 rxPDO3Length;
        uint8_t                 rxPDO4Length;
        
        vector<ODEntry*>        txPDO1;
        vector<ODEntry*>        txPDO2;
        vector<ODEntry*>        txPDO3;
        vector<ODEntry*>        txPDO4;
        uint8_t                 txPDO1Length;
        uint8_t                 txPDO2Length;
        uint8_t                 txPDO3Length;
        uint8_t                 txPDO4Length;
};

#endif /* OBJECT_DICTIONARY_H_ */
