/*
 * ODAnalogInValue.cpp
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 04.03.2021
 *      Author: Nicolas Borla
 */

#include "AnalogIn.h"
#include "ODAnalogInValue.h"

using namespace std;

/**
 * Initializes the position actual value object dictionary entry.
 */
void ODAnalogInValue::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, AnalogIn* analogIn) {
    
    ODTypedEntry<int16_t>::init(index, subindex, type, bitlength, access);
    
    this->analogIn = analogIn;
}

/**
 * Reads the value of this object dictionary entry.
 */
uint32_t ODAnalogInValue::read(uint8_t buffer[], uint8_t& length) {
    
    // read analogIn 0-1 [%] and transform it to the battery voltage 0-50 [V]
    float uncorrectedVoltage = 3.3 * analogIn->read() * (1 + 4300 / 270);
    // linear correction function of Jerome
    float batteryVoltage = uncorrectedVoltage * 1.07887 - 0.14;

    value = static_cast<int16_t>(batteryVoltage*100.0f);

    
    return ODTypedEntry<int16_t>::read(buffer, length);
}

/**
 * Reads the value of this object dictionary entry.
 */
int16_t ODAnalogInValue::read() {
    
    // read analogIn 0-1 [%] and transform it to the battery voltage 0-50 [V]
    float uncorrectedVoltage = 3.3 * analogIn->read() * (1 + 4300 / 270);
    // linear correction function of Jerome
    float batteryVoltage = uncorrectedVoltage * 1.07887 - 0.14;

    value = static_cast<int16_t>(batteryVoltage*100.0f);

    return value;
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
ODAnalogInValue::operator int16_t() {
    
    return read();
}
