/*
 * ODTypedEntry.h
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#ifndef OD_TYPED_ENTRY_H_
#define OD_TYPED_ENTRY_H_

#include <cstdlib>
#include <vector>
#include <stdint.h>
#include "ODEntry.h"
#include "CANopen.h"

using namespace std;

/**
 * The <code>ODTypedEntry</code> class is a specific implementation of an object dictionary
 * entry with a simple integer value type. Supported integer types are INTEGER8, INTEGER16,
 * INTEGER32, UNSIGNED8, UNSIGNED16 and UNSIGNED32.
 */
template <class T> class ODTypedEntry : public ODEntry {
    
    public:
        
                            ODTypedEntry();
        virtual             ~ODTypedEntry();
        virtual void        init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access);
        virtual void        init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, T defaultValue);
        virtual void        init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, T defaultValue, T minValue, T maxValue);
        virtual void        setDefault();
        virtual void        setMinValue(T minValue);
        virtual T           getMinValue();
        virtual void        setMaxValue(T maxValue);
        virtual T           getMaxValue();
        virtual uint32_t    write(uint8_t buffer[], uint8_t& length);
        virtual void        write(T value);
        ODTypedEntry<T>&    operator=(T value);
        virtual uint32_t    read(uint8_t buffer[], uint8_t& length);
        virtual T           read();
                            operator T();
        
    protected:
        
        T                   value;
        T                   defaultValue;
        T                   minValue;
        T                   maxValue;
};

/**
 * Creates and initializes a simple integer value type object dictionary entry with default values.
 */
template <class T> ODTypedEntry<T>::ODTypedEntry() {}

template <class T> ODTypedEntry<T>::~ODTypedEntry() {}

/**
 * Initializes a simple integer value type object dictionary entry.
 * @param index the index of the object.
 * @param subindex the subindex of the object.
 * @param type the data type of the object. This is either
 * TYPE_INTEGER8, TYPE_INTEGER16, TYPE_INTEGER32,
 * TYPE_UNSIGNED8, TYPE_UNSIGNED16, TYPE_UNSIGNED32.
 * @param bitlength the size of the data type in bits.
 * @param access the supported access methods. This value is defined as
 * a bit pattern consisting of ACCESS_READ, ACCESS_WRITE, ACCESS_TXPDO,
 * ACCESS_RXPDO and ACCESS_BACKUP.
 */
template <class T> void ODTypedEntry<T>::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access) {

    ODEntry::init(index, subindex, type, bitlength, access);
    
    value = 0;
    defaultValue = 0;
    
    int8_t integer8Min = -128;
    int8_t integer8Max = 127;
    int16_t integer16Min = -32768;
    int16_t integer16Max = 32767;
    int32_t integer32Min = -2147483648;
    int32_t integer32Max = 2147483647;
    uint8_t unsigned8Max = 255;
    uint16_t unsigned16Max = 65535;
    uint32_t unsigned32Max = 4294967295;
    
    switch (type) {
        case TYPE_INTEGER8:
            minValue = integer8Min;
            maxValue = integer8Max;
            break;
        case TYPE_INTEGER16:
            minValue = integer16Min;
            maxValue = integer16Max;
            break;
        case TYPE_INTEGER32:
            minValue = integer32Min;
            maxValue = integer32Max;
            break;
        case TYPE_UNSIGNED8:
            minValue = 0;
            maxValue = unsigned8Max;
            break;
        case TYPE_UNSIGNED16:
            minValue = 0;
            maxValue = unsigned16Max;
            break;
        case TYPE_UNSIGNED32:
            minValue = 0;
            maxValue = unsigned32Max;
            break;
        default:
            break;
    }
}

/**
 * Initializes a simple integer value type object dictionary entry with a default value.
 * @param index the index of the object.
 * @param subindex the subindex of the object.
 * @param type the data type of the object. This is either
 * TYPE_INTEGER8, TYPE_INTEGER16, TYPE_INTEGER32,
 * TYPE_UNSIGNED8, TYPE_UNSIGNED16, TYPE_UNSIGNED32.
 * @param bitlength the size of the data type in bits.
 * @param access the supported access methods. This value is defined as
 * a bit pattern consisting of ACCESS_READ, ACCESS_WRITE, ACCESS_TXPDO,
 * ACCESS_RXPDO and ACCESS_BACKUP.
 * @param defaultValue the default value of this object.
 */
template <class T> void ODTypedEntry<T>::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, T defaultValue) {

    ODEntry::init(index, subindex, type, bitlength, access);

    this->value = defaultValue;
    this->defaultValue = defaultValue;
    
    int8_t integer8Min = -128;
    int8_t integer8Max = 127;
    int16_t integer16Min = -32768;
    int16_t integer16Max = 32767;
    int32_t integer32Min = -2147483648;
    int32_t integer32Max = 2147483647;
    uint8_t unsigned8Max = 255;
    uint16_t unsigned16Max = 65535;
    uint32_t unsigned32Max = 4294967295;
    
    switch (type) {
        case TYPE_INTEGER8:
            minValue = integer8Min;
            maxValue = integer8Max;
            break;
        case TYPE_INTEGER16:
            minValue = integer16Min;
            maxValue = integer16Max;
            break;
        case TYPE_INTEGER32:
            minValue = integer32Min;
            maxValue = integer32Max;
            break;
        case TYPE_UNSIGNED8:
            minValue = 0;
            maxValue = unsigned8Max;
            break;
        case TYPE_UNSIGNED16:
            minValue = 0;
            maxValue = unsigned16Max;
            break;
        case TYPE_UNSIGNED32:
            minValue = 0;
            maxValue = unsigned32Max;
            break;
        default:
            break;
    }
}

/**
 * Initializes a simple integer value type object dictionary entry with a default, minimum and maximum values.
 * @param index the index of the object.
 * @param subindex the subindex of the object.
 * @param type the data type of the object. This is either
 * TYPE_INTEGER8, TYPE_INTEGER16, TYPE_INTEGER32,
 * TYPE_UNSIGNED8, TYPE_UNSIGNED16, TYPE_UNSIGNED32.
 * @param bitlength the size of the data type in bits.
 * @param access the supported access methods. This value is defined as
 * a bit pattern consisting of ACCESS_READ, ACCESS_WRITE, ACCESS_TXPDO,
 * ACCESS_RXPDO and ACCESS_BACKUP.
 * @param defaultValue the default value of this object.
 * @param minValue the minimum value of this object.
 * @param maxValue the maximum value of this object.
 */
template <class T> void ODTypedEntry<T>::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, T defaultValue, T minValue, T maxValue) {

    ODEntry::init(index, subindex, type, bitlength, access);

    this->value = defaultValue;
    this->defaultValue = defaultValue;
    this->minValue = minValue;
    this->maxValue = maxValue;
}

/**
 * Sets the actual value of this object dictionary entry to it's default value.
 * This method is usually called by the object dictionary when a master writes
 * the object 'restore all default parameters'.
 */
template <class T> void ODTypedEntry<T>::setDefault() {

    value = defaultValue;
}

/**
 * Sets the minimum value of this object dictionary entry.
 * @param minValue the minimum value of this object.
 */
template <class T> void ODTypedEntry<T>::setMinValue(T minValue) {

    this->minValue = minValue;
}

/**
 * Gets the minimum value of this object dictionary entry.
 * @return the minimum value of this object.
 */
template <class T> T ODTypedEntry<T>::getMinValue() {
    
    return minValue;
}

/**
 * Sets the maximum value of this object dictionary entry.
 * @param maxValue the maximum value of this object.
 */
template <class T> void ODTypedEntry<T>::setMaxValue(T maxValue) {

    this->maxValue = maxValue;
}

/**
 * Gets the maximum value of this object dictionary entry.
 * @return the maximum value of this object.
 */
template <class T> T ODTypedEntry<T>::getMaxValue() {
    
    return maxValue;
}

/**
 * Writes the value of this object dictionary entry. This method is
 * intended to be called by a communication stack of the firmware.
 * @param buffer an array of bytes that defines this value.
 * @param length a pointer to an integer holding the length of this object
 * in bytes. This parameter is set to the actual length by this method.
 * @return a CANopen communication error, such as NO_COMMUNICATION_ERROR,
 * READ_ONLY, VALUE_TOO_HIGH_ERROR, etc.
 */
template <class T> uint32_t ODTypedEntry<T>::write(uint8_t buffer[], uint8_t& length) {

    if (access & ACCESS_WRITE) {

        T value = 0;

        switch (type) {
            case TYPE_INTEGER8:
                value = static_cast<int8_t>(buffer[0]);
                break;
            case TYPE_INTEGER16:
                value = static_cast<int16_t>(static_cast<uint16_t>(buffer[0]) | (static_cast<uint16_t>(buffer[1]) << 8));
                break;
            case TYPE_INTEGER32:
                value = static_cast<int32_t>(static_cast<uint32_t>(buffer[0]) | (static_cast<uint32_t>(buffer[1]) << 8) | (static_cast<uint32_t>(buffer[2]) << 16) | (static_cast<uint32_t>(buffer[3]) << 24));
                break;
            case TYPE_UNSIGNED8:
                value = buffer[0];
                break;
            case TYPE_UNSIGNED16:
                value = static_cast<uint16_t>(buffer[0]) | (static_cast<uint16_t>(buffer[1]) << 8);
                break;
            case TYPE_UNSIGNED32:
                value = static_cast<uint32_t>(buffer[0]) | (static_cast<uint32_t>(buffer[1]) << 8) | (static_cast<uint32_t>(buffer[2]) << 16) | (static_cast<uint32_t>(buffer[3]) << 24);
                break;
            default:
                value = 0;
                break;
        }

        if (value < minValue) {
            
            return CANopen::VALUE_TOO_LOW_ERROR;
            
        } else if (value > maxValue) {
            
            return CANopen::VALUE_TOO_HIGH_ERROR;
            
        } else {
            
            this->value = value;
            length = bitlength/8;

            return CANopen::NO_COMMUNICATION_ERROR;
        }
        
    } else if (access & ACCESS_READ) {

        return CANopen::READ_ONLY;

    } else {

        return CANopen::ACCESS_ERROR;
    }
}

/**
 * Writes the value of this object dictionary entry.
 * This method is usually called by other components of the
 * firmware that have a direct access to the object dictionary.
 * @param value the value to set.
 */
template <class T> void ODTypedEntry<T>::write(T value) {
    
    if ((value >= minValue) || (value <= maxValue)) this->value = value;
}

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
template <class T> ODTypedEntry<T>& ODTypedEntry<T>::operator=(T value) {
    
    write(value);
    
    return *this;
}

/**
 * Reads the value of this object dictionary entry. This method is
 * intended to be called by a communication stack of the firmware.
 * @param buffer an array of bytes where this value must be copied into.
 * @param length a pointer to an integer holding the length of this object
 * in bytes. This parameter is set to the actual length by this method.
 * @return a CANopen communication error, such as NO_COMMUNICATION_ERROR,
 * ACCESS_ERROR, WRITE_ONLY, etc.
 */
template <class T> uint32_t ODTypedEntry<T>::read(uint8_t buffer[], uint8_t& length) {

    if (access & ACCESS_READ) {

        switch (type) {
            case TYPE_INTEGER8:
                buffer[0] = static_cast<uint8_t>(value);
                break;
            case TYPE_INTEGER16:
                buffer[0] = static_cast<uint8_t>(value & 0xFF);
                buffer[1] = static_cast<uint8_t>((value >> 8) & 0xFF);
                break;
            case TYPE_INTEGER32:
                buffer[0] = static_cast<uint8_t>(value & 0xFF);
                buffer[1] = static_cast<uint8_t>((value >> 8) & 0xFF);
                buffer[2] = static_cast<uint8_t>((value >> 16) & 0xFF);
                buffer[3] = static_cast<uint8_t>((value >> 24) & 0xFF);
                break;
            case TYPE_UNSIGNED8:
                buffer[0] = value;
                break;
            case TYPE_UNSIGNED16:
                buffer[0] = static_cast<uint8_t>(value & 0xFF);
                buffer[1] = static_cast<uint8_t>((value >> 8) & 0xFF);
                break;
            case TYPE_UNSIGNED32:
                buffer[0] = static_cast<uint8_t>(value & 0xFF);
                buffer[1] = static_cast<uint8_t>((value >> 8) & 0xFF);
                buffer[2] = static_cast<uint8_t>((value >> 16) & 0xFF);
                buffer[3] = static_cast<uint8_t>((value >> 24) & 0xFF);
                break;
            default:
                break;
        }

        length = bitlength/8;
        
        return CANopen::NO_COMMUNICATION_ERROR;
        
    } else if (access & ACCESS_WRITE) {

        return CANopen::WRITE_ONLY;

    } else {

        return CANopen::ACCESS_ERROR;
    }
}

/**
 * Reads the value of this object dictionary entry.
 * This method is usually called by other components of the
 * firmware that have a direct access to the object dictionary.
 * @return the value of this object dictionary entry.
 */
template <class T> T ODTypedEntry<T>::read() {
    
    return value;
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
template <class T> ODTypedEntry<T>::operator T() {
    
    return read();
}

#endif /* OD_TYPED_ENTRY_H_ */
