/*
 * ODErrorRegister.cpp
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#include "ODErrorRegister.h"

using namespace std;

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
ODErrorRegister& ODErrorRegister::operator=(uint8_t value) {
    
    write(value);
    
    return *this;
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
ODErrorRegister::operator uint8_t() {
    
    return read();
}
