/*
 * ODAnalogInValue.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 04.03.2021
 *      Author: Nicolas Borla
 */

#ifndef OD_ANALOG_IN_VALUE_H
#define OD_ANALOG_IN_VALUE_H

#include <cstdlib>
#include <stdint.h>
#include "ODTypedEntry.h"
#include "AnalogIn.h"

using namespace std;

/**
 * The <code>ODAnalogInValue</code> class implements an object dictionary entry
 * to read the actual value of an AnalogIn object.
 */
class ODAnalogInValue : public ODTypedEntry<int16_t> {
    
    public:
        
        using                       ODTypedEntry<int16_t>::init;
        void                        init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, AnalogIn* analogIn);
        virtual uint32_t            read(uint8_t buffer[], uint8_t& length);
        virtual int16_t             read();
                                    operator int16_t();
        
    private:
        
        AnalogIn*                   analogIn;
        uint8_t                     valueID;
};

#endif /* OD_ANALOG_IN_VALUE_H */
