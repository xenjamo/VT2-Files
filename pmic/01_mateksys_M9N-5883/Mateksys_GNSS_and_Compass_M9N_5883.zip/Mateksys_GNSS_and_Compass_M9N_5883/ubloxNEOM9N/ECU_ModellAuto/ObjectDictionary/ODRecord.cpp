/*
 * ODRecord.cpp
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#include "CANopen.h"
#include "ODRecord.h"

using namespace std;

/**
 * Creates a record object dictionary entry and initializes it with default values.
 */
ODRecord::ODRecord() {
    
    value = 0;
    defaultValue = 0;
    maxValue = 255;
    entries.clear();
}

ODRecord::~ODRecord() {}

/**
 * Initializes this record object dictionary entry.
 * @param index the index of the object.
 * @param access the supported access methods. This value is defined as
 * a bit pattern consisting of ACCESS_READ, ACCESS_WRITE, ACCESS_TXPDO,
 * ACCESS_RXPDO and ACCESS_BACKUP.
 */
void ODRecord::init(uint16_t index, uint8_t access) {
    
    ODEntry::init(index, 0x00, TYPE_RECORD, 0x08, access);
}

/**
 * Initializes this record object dictionary entry with a default value.
 * @param index the index of the object.
 * @param access the supported access methods. This value is defined as
 * a bit pattern consisting of ACCESS_READ, ACCESS_WRITE, ACCESS_TXPDO,
 * ACCESS_RXPDO and ACCESS_BACKUP.
 * @param defaultValue the default value of this object.
 */
void ODRecord::init(uint16_t index, uint8_t access, uint8_t value, ...) {
    
    ODEntry::init(index, 0x00, TYPE_RECORD, 0x08, access);
    
    this->value = value;
    this->defaultValue = value;
    this->maxValue = value;
    
    entries.clear();
    va_list arguments;
    va_start(arguments, value);
    for (uint8_t i = 0; i < value; i++) entries.push_back(va_arg(arguments, ODEntry*));
    va_end(arguments);
}

/**
 * Adds an object dictionary entry to this record.
 * Calling this method also adjusts the value, the default value and the maximum
 * value of this record to the actual number of entries.
 * @param entry a reference to an object dictionary entry to add to this record.
 */
void ODRecord::addEntry(ODEntry* entry) {
    
    entries.push_back(entry);
    
    maxValue = entries.size();
}

/**
 * Sets the actual value of this record object dictionary entry to it's default value.
 * This method is usually called by the object dictionary when a master writes
 * the object 'restore all default parameters'.
 */
void ODRecord::setDefault() {
    
    value = defaultValue;
}

/**
 * Sets the default value of this record object dictionary entry.
 * @param defaultValue the default value of this object.
 */
void ODRecord::setDefault(uint8_t defaultValue) {
    
    this->defaultValue = defaultValue;
}

/**
 * Sets the maximum value of this record object dictionary entry.
 * @param maxValue the maximum value of this object.
 */
void ODRecord::setMaxValue(uint8_t maxValue) {
    
    this->maxValue = maxValue;
}

/**
 * Writes the value of this record object dictionary entry. This method
 * is intended to be called by a communication stack of the firmware.
 * @param buffer an array of bytes that defines this value.
 * @param length a pointer to an integer holding the length of this object
 * in bytes. This parameter is set to the actual length by this method.
 * @return a CANopen communication error, such as NO_COMMUNICATION_ERROR,
 * READ_ONLY, VALUE_TOO_HIGH_ERROR, etc.
 */
uint32_t ODRecord::write(uint8_t buffer[], uint8_t& length) {
    
    if (access & ACCESS_WRITE) {
        
        uint8_t value = buffer[0];
        
        if (value > maxValue) {
            
            return CANopen::VALUE_TOO_HIGH_ERROR;
            
        } else {
            
            this->value = value;
            length = bitlength/8;

            return CANopen::NO_COMMUNICATION_ERROR;
        }
        
    } else if (access & ACCESS_READ) {

        return CANopen::READ_ONLY;

    } else {

        return CANopen::ACCESS_ERROR;
    }
}

/**
 * Sets the value of this record object dictionary entry.
 * This method is usually called by other components of the
 * firmware that have a direct access to the object dictionary.
 * @param value the value to set.
 */
void ODRecord::write(uint8_t value) {
    
    if (value <= maxValue) this->value = value;
}

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
ODRecord& ODRecord::operator=(uint8_t value) {
    
    write(value);
    
    return *this;
}

/**
 * Reads the value of this record object dictionary entry. This method
 * is intended to be called by a communication stack of the firmware.
 * @param buffer an array of bytes where this value must be copied into.
 * @param length a pointer to an integer holding the length of this object
 * in bytes. This parameter is set to the actual length by this method.
 * @return a CANopen communication error, such as NO_COMMUNICATION_ERROR,
 * ACCESS_ERROR, WRITE_ONLY, etc.
 */
uint32_t ODRecord::read(uint8_t buffer[], uint8_t& length) {
    
    if (access & ACCESS_READ) {

        buffer[0] = value;
        length = bitlength/8;
        
        return CANopen::NO_COMMUNICATION_ERROR;
        
    } else if (access & ACCESS_WRITE) {

        return CANopen::WRITE_ONLY;

    } else {

        return CANopen::ACCESS_ERROR;
    }
}

/**
 * Gets the value of this record object dictionary entry.
 * This method is usually called by other components of the
 * firmware that have a direct access to the object dictionary.
 * @return the value of this object dictionary entry.
 */
uint8_t ODRecord::read() {
    
    return value;
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
ODRecord::operator uint8_t() {
    
    return read();
}
