/*
 * ODErrorHistory.h
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#ifndef OD_ERROR_HISTORY_H_
#define OD_ERROR_HISTORY_H_

#include <cstdlib>
#include <cstdarg>
#include <string>
#include <vector>
#include <stdint.h>
#include "ODRecord.h"

using namespace std;

class ObjectDictionary;

/**
 * The <code>ODErrorHistory</code> class is a specific implementation of an object dictionary
 * entry that represents the error history record.
 */
class ODErrorHistory : public ODRecord {
    
    public:
        
        static const uint32_t   NO_ERROR = 0x00000000;
        static const uint32_t   GENERIC_ERROR = 0x00001000;
        static const uint32_t   DC_LINK_OVERVOLTAGE_ERROR = 0x00003210;
        static const uint32_t   DC_LINK_UNDERVOLTAGE_ERROR = 0x00003220;
        static const uint32_t   POWER_SECTION_ERROR = 0x00005400;
        static const uint32_t   CAN_LIFE_GUARD_ERROR = 0x00008130;
        static const uint32_t   FOLLOWING_ERROR = 0x00008611;
        
        using               ODRecord::init;
        virtual void        init(uint16_t index, uint8_t access, ObjectDictionary* objectDictionary);
        virtual uint32_t    write(uint8_t buffer[], uint8_t& length);
        virtual void        write(uint8_t value);
        ODErrorHistory&     operator=(uint8_t value);
        void                addError(uint32_t error);
        
    private:
        
        ObjectDictionary*   objectDictionary;
};

#endif /* OD_ERROR_HISTORY_H_ */
