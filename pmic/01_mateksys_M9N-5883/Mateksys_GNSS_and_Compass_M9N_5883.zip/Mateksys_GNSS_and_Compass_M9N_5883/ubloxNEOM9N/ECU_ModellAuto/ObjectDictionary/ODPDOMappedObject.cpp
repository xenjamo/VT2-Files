/*
 * ODPDOMappedObject.cpp
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#include "ObjectDictionary.h"
#include "CANopen.h"
#include "ODRecord.h"
#include "ODPDOMappedObject.h"

using namespace std;

void ODPDOMappedObject::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, uint32_t defaultValue, ObjectDictionary* objectDictionary, ODRecord* record, uint8_t requiredAccess) {
    
    ODTypedEntry<uint32_t>::init(index, subindex, type, bitlength, access, defaultValue);
    
    this->objectDictionary = objectDictionary;
    this->record = record;
    this->requiredAccess = requiredAccess;
}

/**
 * Writes the value of this object dictionary entry.
 */
uint32_t ODPDOMappedObject::write(uint8_t buffer[], uint8_t& length) {
    
    if ((objectDictionary->canOpenNMTState != CANopen::STATE_INITIALISATION) && (objectDictionary->canOpenNMTState != CANopen::STATE_PRE_OPERATIONAL)) return CANopen::WRONG_NMT_STATE_ERROR;
    
    if (*record > 0) return CANopen::PDO_MAPPING_ERROR;
    
    uint32_t value = static_cast<uint32_t>(buffer[0]) | (static_cast<uint32_t>(buffer[1]) << 8) | (static_cast<uint32_t>(buffer[2]) << 16) | (static_cast<uint32_t>(buffer[3]) << 24);
    
    bool objectEntryPDOMappable = false;
    
    uint16_t index = (value >> 16) & 0xFFFF;
    uint8_t subindex = (value >> 8) & 0xFF;
    uint8_t bitlength = (value) & 0xFF;
    
    for (uint16_t i = 0; i < objectDictionary->entries.size(); i++) {
        if ((objectDictionary->entries[i]->getIndex() == index) && (objectDictionary->entries[i]->getSubindex() == subindex) && (objectDictionary->entries[i]->getBitlength() == bitlength)) {
            if (objectDictionary->entries[i]->getAccess() & requiredAccess) objectEntryPDOMappable = true;
        }
    }
    
    if (!objectEntryPDOMappable) return CANopen::PDO_MAPPING_ERROR;
    
    return ODTypedEntry<uint32_t>::write(buffer, length);
}

/**
 * Writes the value of this object dictionary entry.
 */
void ODPDOMappedObject::write(uint32_t value) {
    
    if ((objectDictionary->canOpenNMTState == CANopen::STATE_INITIALISATION) || (objectDictionary->canOpenNMTState == CANopen::STATE_PRE_OPERATIONAL)) {
        
        bool objectEntryPDOMappable = false;
        
        uint16_t index = (value >> 16) & 0xFFFF;
        uint8_t subindex = (value >> 8) & 0xFF;
        uint8_t bitlength = (value) & 0xFF;
        
        for (uint16_t i = 0; i < objectDictionary->entries.size(); i++) {
            if ((objectDictionary->entries[i]->getIndex() == index) && (objectDictionary->entries[i]->getSubindex() == subindex) && (objectDictionary->entries[i]->getBitlength() == bitlength)) {
                if (objectDictionary->entries[i]->getAccess() & requiredAccess) objectEntryPDOMappable = true;
            }
        }
        
        if (objectEntryPDOMappable) ODTypedEntry<uint32_t>::write(value);
    }
}

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
ODPDOMappedObject& ODPDOMappedObject::operator=(uint32_t value) {
    
    write(value);
    
    return *this;
}
