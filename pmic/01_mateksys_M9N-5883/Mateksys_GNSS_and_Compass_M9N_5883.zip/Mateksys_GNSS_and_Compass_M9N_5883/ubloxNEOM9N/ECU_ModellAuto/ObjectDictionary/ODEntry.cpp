/*
 * ODEntry.cpp
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#include "CANopen.h"
#include "ODEntry.h"

using namespace std;

/**
 * Creates a basic object dictionary entry and initializes it with default values.
 */
ODEntry::ODEntry() {

    index = 0x0000;
    subindex = 0x00;
    type = TYPE_NULL;
    bitlength = 0;
    access = 0;
}

ODEntry::~ODEntry() {}

/**
 * Initializes a basic object dictionary entry.
 * @param index the index of the object.
 * @param subindex the subindex of the object.
 * @param type the data type of the object. This is either
 * TYPE_NULL, TYPE_BOOLEAN, TYPE_INTEGER8, TYPE_INTEGER16, TYPE_INTEGER32,
 * TYPE_UNSIGNED8, TYPE_UNSIGNED16, TYPE_UNSIGNED32, TYPE_REAL32,
 * TYPE_VISIBLESTRING or TYPE_RECORD.
 * @param bitlength the size of the data type in bits.
 * @param access the supported access methods. This value is defined as
 * a bit pattern consisting of ACCESS_READ, ACCESS_WRITE, ACCESS_TXPDO,
 * ACCESS_RXPDO and ACCESS_BACKUP.
 */
void ODEntry::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access) {

    this->index = index;
    this->subindex = subindex;
    this->type = type;
    this->bitlength = bitlength;
    this->access = access;
}

/**
 * Sets the index of this object.
 */
void ODEntry::setIndex(uint16_t index) {

    this->index = index;
}

/**
 * Gets the index of this object.
 */
uint16_t ODEntry::getIndex() {

    return index;
}

/**
 * Sets the subindex of this object.
 */
void ODEntry::setSubindex(uint8_t subindex) {

    this->subindex = subindex;
}

/**
 * Gets the subindex of this object.
 */
uint8_t ODEntry::getSubindex() {

    return subindex;
}

/**
 * Gets the data type of this object.
 * @return the data type. This is either TYPE_NULL, TYPE_BOOLEAN,
 * TYPE_INTEGER8, TYPE_INTEGER16, TYPE_INTEGER32, TYPE_UNSIGNED8,
 * TYPE_UNSIGNED16, TYPE_UNSIGNED32, TYPE_REAL32, TYPE_VISIBLESTRING
 * or TYPE_RECORD.
 */
uint8_t ODEntry::getType() {

    return type;
}

/**
 * Gets the size of this data type in bits.
 * @return the size in bits.
 */
uint8_t ODEntry::getBitlength() {

    return bitlength;
}

/**
 * Sets the supported access methods of this object.
 * @param access the supported access methods. This value is defined as
 * a bit pattern consisting of the flags ACCESS_READ, ACCESS_WRITE,
 * ACCESS_TXPDO, ACCESS_RXPDO and ACCESS_PERSISTENT_MEMORY.
 */
void ODEntry::setAccess(uint8_t access) {

    this->access = access;
}

/**
 * Gets the bit pattern of supported access methods
 * of this object.
 */
uint8_t ODEntry::getAccess() {

    return access;
}

/**
 * Sets the actual value of this object dictionary entry to it's
 * default value. This method is usually called by the object dictionary
 * when a master writes the object 'restore all default parameters'.
 * This is an abstract method that needs to be implemented by
 * specific subclasses.
 */
void ODEntry::setDefault() {}

/**
 * Writes the value of this object dictionary entry. This method
 * is intended to be called by a communication stack of the firmware.
 * @param buffer an array of bytes that defines this value.
 * @param length a pointer to an integer holding the length of this object
 * in bytes. A specific implementation of this method should write (and
 * thus return) the actual number of bytes read from the buffer.
 * @return a CANopen communication error, such as NO_COMMUNICATION_ERROR,
 * READ_ONLY, VALUE_TOO_HIGH_ERROR, etc.
 */
uint32_t ODEntry::write(uint8_t buffer[], uint8_t& length) {

    return CANopen::NO_COMMUNICATION_ERROR;
}

/**
 * Reads the value of this object dictionary entry. This method
 * is intended to be called by a communication stack of the firmware.
 * @param buffer an array of bytes where this value must be copied into.
 * @param length a pointer to an integer holding the length of this object
 * in bytes. A specific implementation of this method should write (and
 * thus return) the actual number of bytes written into the buffer.
 * @return a CANopen communication error, such as NO_COMMUNICATION_ERROR,
 * ACCESS_ERROR, WRITE_ONLY, etc.
 */
uint32_t ODEntry::read(uint8_t buffer[], uint8_t& length) {

    return CANopen::NO_COMMUNICATION_ERROR;
}
