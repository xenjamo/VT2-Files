/*
 * ObjectDictionary.cpp
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#include "EEPROM.h"
#include "CANopen.h"
#include "MotionEstimation.h"
#include "ODControllerValue.h"
#include "ODImuValue.h"
#include "ODMotionEstimationValue.h"
#include "ObjectDictionary.h"
#include "OpenIMU300ZI.h"


using namespace std;

inline string intToString(int32_t i) {
    
    char buffer[32];
    sprintf(buffer, "%d", i);
    
    return string(buffer);
}

/**
 * Creates an instance of a CANopen object dictionary and initializes all entries.
 * @param eeprom a reference to an I2C EEPROM to write nonvolatile object data into.
 */
ObjectDictionary::ObjectDictionary(EEPROM& eeprom,
                                    EncoderCounter* counterFL, EncoderCounter* counterFR, EncoderCounter* counterRL, EncoderCounter* counterRR, 
                                    Controller* controller, OpenIMU300ZI* imu, AnalogIn* batteryVoltageSensor, MotionEstimation* motionEstimation) : eeprom(eeprom) {
    
    // add all object entries to object list
    
    entries.push_back(&deviceType);
    entries.push_back(&errorRegister);
    entries.push_back(&errorHistory);
    for (uint8_t i = 0; i < NUMBER_OF_ERRORS; i++) entries.push_back(&error[i]);
    entries.push_back(&manufacturerDeviceName);
    entries.push_back(&storeParameters);
    entries.push_back(&saveAllParameters);
    entries.push_back(&restoreDefaultParameters);
    entries.push_back(&restoreAllDefaultParameters);
    entries.push_back(&consumerHeartbeatTime);
    entries.push_back(&consumer1HeartbeatTime);
    entries.push_back(&producerHeartbeatTime);
    entries.push_back(&identityObject);
    entries.push_back(&vendorID);
    entries.push_back(&productCode);
    entries.push_back(&revisionNumber);
    entries.push_back(&serialNumber);
    entries.push_back(&receivePDO1Parameter);
    entries.push_back(&cobIDReceivePDO1);
    entries.push_back(&transmissionTypeReceivePDO1);
    entries.push_back(&receivePDO2Parameter);
    entries.push_back(&cobIDReceivePDO2);
    entries.push_back(&transmissionTypeReceivePDO2);
    entries.push_back(&receivePDO3Parameter);
    entries.push_back(&cobIDReceivePDO3);
    entries.push_back(&transmissionTypeReceivePDO3);
    entries.push_back(&receivePDO4Parameter);
    entries.push_back(&cobIDReceivePDO4);
    entries.push_back(&transmissionTypeReceivePDO4);
    entries.push_back(&receivePDO1Mapping);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) entries.push_back(&receivePDO1MappedObject[i]);
    entries.push_back(&receivePDO2Mapping);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) entries.push_back(&receivePDO2MappedObject[i]);
    entries.push_back(&receivePDO3Mapping);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) entries.push_back(&receivePDO3MappedObject[i]);
    entries.push_back(&receivePDO4Mapping);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) entries.push_back(&receivePDO4MappedObject[i]);
    entries.push_back(&transmitPDO1Parameter);
    entries.push_back(&cobIDTransmitPDO1);
    entries.push_back(&transmissionTypeTransmitPDO1);
    entries.push_back(&inhibitTimeTransmitPDO1);
    entries.push_back(&transmitPDO2Parameter);
    entries.push_back(&cobIDTransmitPDO2);
    entries.push_back(&transmissionTypeTransmitPDO2);
    entries.push_back(&inhibitTimeTransmitPDO2);
    entries.push_back(&transmitPDO3Parameter);
    entries.push_back(&cobIDTransmitPDO3);
    entries.push_back(&transmissionTypeTransmitPDO3);
    entries.push_back(&inhibitTimeTransmitPDO3);
    entries.push_back(&transmitPDO4Parameter);
    entries.push_back(&cobIDTransmitPDO4);
    entries.push_back(&transmissionTypeTransmitPDO4);
    entries.push_back(&inhibitTimeTransmitPDO4);
    entries.push_back(&transmitPDO1Mapping);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) entries.push_back(&transmitPDO1MappedObject[i]);
    entries.push_back(&transmitPDO2Mapping);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) entries.push_back(&transmitPDO2MappedObject[i]);
    entries.push_back(&transmitPDO3Mapping);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) entries.push_back(&transmitPDO3MappedObject[i]);
    entries.push_back(&transmitPDO4Mapping);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) entries.push_back(&transmitPDO4MappedObject[i]);
    entries.push_back(&nodeID);
    entries.push_back(&canBitrate);
    entries.push_back(&canOpenNMTState);
    entries.push_back(&timeStamp);
    entries.push_back(&consumerHeartbeatTimer);
    entries.push_back(&consumer1HeartbeatTimer);

    // ECU specific Objects
    entries.push_back(&ledStatus);
    entries.push_back(&counterActualValueFL);
    entries.push_back(&counterActualValueFR);
    entries.push_back(&counterActualValueRL);
    entries.push_back(&counterActualValueRR);
    entries.push_back(&actualSpeedFL);
    entries.push_back(&actualSpeedFR);
    entries.push_back(&actualSpeedRL);
    entries.push_back(&actualSpeedRR);
    entries.push_back(&actualTranslationalVelocity);
    entries.push_back(&actualRotationalVelocity);
    entries.push_back(&accelerationX);
    entries.push_back(&accelerationY);
    entries.push_back(&accelerationZ);
    entries.push_back(&gyroX);
    entries.push_back(&gyroY);
    entries.push_back(&gyroZ);
    entries.push_back(&magnetometerX);
    entries.push_back(&magnetometerY);
    entries.push_back(&magnetometerZ);
    entries.push_back(&roll);
    entries.push_back(&pitch);
    entries.push_back(&yaw);
    entries.push_back(&rollRate);
    entries.push_back(&pitchRate);
    entries.push_back(&yawRate);
    entries.push_back(&enableMotor);
    entries.push_back(&enableSteering);
    entries.push_back(&phaseVoltage);
    entries.push_back(&batteryVoltage);
    entries.push_back(&actualSteeringAngle);
    entries.push_back(&desiredSteeringAngle);
    entries.push_back(&desiredSteeringSpeed);
    entries.push_back(&desiredTranslationalVelocity);
    entries.push_back(&desiredTranslationalAcceleration);
    entries.push_back(&ekfTranslationalVelocity);
    entries.push_back(&ekfRotationalVelocity);

    
    // initialise all object entries
    
    deviceType.init(0x1000, 0x00, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ, 0x00020192);
    errorRegister.init(0x1001, 0x00, ODEntry::TYPE_UNSIGNED8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, 0);
    errorHistory.init(0x1003, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE, this);
    for (uint8_t i = 0; i < NUMBER_OF_ERRORS; i++) {
        error[i].init(0x1003, i+1, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ, 0x00000000);
        errorHistory.addEntry(&error[i]);
    }
    errorHistory.setDefault();
    manufacturerDeviceName.init(0x1008, 0x00, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ, 0x4F565253);
    storeParameters.init(0x1010, ODEntry::ACCESS_READ, 1, &saveAllParameters);
    saveAllParameters.init(0x1010, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE, 0x65766173, 0x65766173, 0x65766173, this);
    restoreDefaultParameters.init(0x1011, ODEntry::ACCESS_READ, 1, &restoreAllDefaultParameters);
    restoreAllDefaultParameters.init(0x1011, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE, 0x64616F6C, 0x64616F6C, 0x64616F6C, this);
    consumerHeartbeatTime.init(0x1016, ODEntry::ACCESS_READ, 1, &consumer1HeartbeatTime);
    consumer1HeartbeatTime.init(0x1016, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 0);
    producerHeartbeatTime.init(0x1017, 0x00, ODEntry::TYPE_UNSIGNED16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 0);
    identityObject.init(0x1018, ODEntry::ACCESS_READ, 4, &vendorID, &productCode, &revisionNumber, &serialNumber);
    vendorID.init(0x1018, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ, 0x00000036);
    productCode.init(0x1018, 0x02, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ, 0x00000001);
    revisionNumber.init(0x1018, 0x03, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ, 0x00000001);
    serialNumber.init(0x1018, 0x04, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ, 0xBABEFACE);
    receivePDO1Parameter.init(0x1400, ODEntry::ACCESS_READ, 2, &cobIDReceivePDO1, &transmissionTypeReceivePDO1);
    cobIDReceivePDO1.init(0x1400, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE, 0x00000201);
    transmissionTypeReceivePDO1.init(0x1400, 0x02, ODEntry::TYPE_UNSIGNED8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 255);
    receivePDO2Parameter.init(0x1401, ODEntry::ACCESS_READ, 2, &cobIDReceivePDO2, &transmissionTypeReceivePDO2);
    cobIDReceivePDO2.init(0x1401, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE, 0x00000301);
    transmissionTypeReceivePDO2.init(0x1401, 0x02, ODEntry::TYPE_UNSIGNED8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 255);
    receivePDO3Parameter.init(0x1402, ODEntry::ACCESS_READ, 2, &cobIDReceivePDO3, &transmissionTypeReceivePDO3);
    cobIDReceivePDO3.init(0x1402, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE, 0x00000401);
    transmissionTypeReceivePDO3.init(0x1402, 0x02, ODEntry::TYPE_UNSIGNED8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 255);
    receivePDO4Parameter.init(0x1403, ODEntry::ACCESS_READ, 2, &cobIDReceivePDO4, &transmissionTypeReceivePDO4);
    cobIDReceivePDO4.init(0x1403, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE, 0x00000501);
    transmissionTypeReceivePDO4.init(0x1403, 0x02, ODEntry::TYPE_UNSIGNED8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 255);
    receivePDO1Mapping.init(0x1600, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, this);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) {
        receivePDO1MappedObject[i].init(0x1600, i+1, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 0x00000000, this, &receivePDO1Mapping, ODEntry::ACCESS_RXPDO);
        receivePDO1Mapping.addEntry(&receivePDO1MappedObject[i]);
    }
    receivePDO1Mapping.setDefault();
    receivePDO2Mapping.init(0x1601, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, this);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) {
        receivePDO2MappedObject[i].init(0x1601, i+1, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 0x00000000, this, &receivePDO2Mapping, ODEntry::ACCESS_RXPDO);
        receivePDO2Mapping.addEntry(&receivePDO2MappedObject[i]);
    }
    receivePDO2Mapping.setDefault();
    receivePDO3Mapping.init(0x1602, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, this);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) {
        receivePDO3MappedObject[i].init(0x1602, i+1, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 0x00000000, this, &receivePDO3Mapping, ODEntry::ACCESS_RXPDO);
        receivePDO3Mapping.addEntry(&receivePDO3MappedObject[i]);
    }
    receivePDO3Mapping.setDefault();
    receivePDO4Mapping.init(0x1603, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, this);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) {
        receivePDO4MappedObject[i].init(0x1603, i+1, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 0x00000000, this, &receivePDO4Mapping, ODEntry::ACCESS_RXPDO);
        receivePDO4Mapping.addEntry(&receivePDO4MappedObject[i]);
    }
    receivePDO4Mapping.setDefault();
    transmitPDO1Parameter.init(0x1800, ODEntry::ACCESS_READ, 3, &cobIDTransmitPDO1, &transmissionTypeTransmitPDO1, &inhibitTimeTransmitPDO1);
    cobIDTransmitPDO1.init(0x1800, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE, 0x00000181);
    transmissionTypeTransmitPDO1.init(0x1800, 0x02, ODEntry::TYPE_UNSIGNED8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 253);
    inhibitTimeTransmitPDO1.init(0x1800, 0x03, ODEntry::TYPE_UNSIGNED16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 1, 1, 10000);
    transmitPDO2Parameter.init(0x1801, ODEntry::ACCESS_READ, 3, &cobIDTransmitPDO2, &transmissionTypeTransmitPDO2, &inhibitTimeTransmitPDO2);
    cobIDTransmitPDO2.init(0x1801, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE, 0x00000281);
    transmissionTypeTransmitPDO2.init(0x1801, 0x02, ODEntry::TYPE_UNSIGNED8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 253);
    inhibitTimeTransmitPDO2.init(0x1801, 0x03, ODEntry::TYPE_UNSIGNED16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 1, 1, 10000);
    transmitPDO3Parameter.init(0x1802, ODEntry::ACCESS_READ, 3, &cobIDTransmitPDO3, &transmissionTypeTransmitPDO3, &inhibitTimeTransmitPDO3);
    cobIDTransmitPDO3.init(0x1802, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE, 0x00000381);
    transmissionTypeTransmitPDO3.init(0x1802, 0x02, ODEntry::TYPE_UNSIGNED8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 253);
    inhibitTimeTransmitPDO3.init(0x1802, 0x03, ODEntry::TYPE_UNSIGNED16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 1, 1, 10000);
    transmitPDO4Parameter.init(0x1803, ODEntry::ACCESS_READ, 3, &cobIDTransmitPDO4, &transmissionTypeTransmitPDO4, &inhibitTimeTransmitPDO4);
    cobIDTransmitPDO4.init(0x1803, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE, 0x00000481);
    transmissionTypeTransmitPDO4.init(0x1803, 0x02, ODEntry::TYPE_UNSIGNED8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 253);
    inhibitTimeTransmitPDO4.init(0x1803, 0x03, ODEntry::TYPE_UNSIGNED16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 1, 1, 10000);
    transmitPDO1Mapping.init(0x1A00, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, this);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) {
        transmitPDO1MappedObject[i].init(0x1A00, i+1, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 0x00000000, this, &transmitPDO1Mapping, ODEntry::ACCESS_TXPDO);
        transmitPDO1Mapping.addEntry(&transmitPDO1MappedObject[i]);
    }
    transmitPDO1Mapping.setDefault();
    transmitPDO2Mapping.init(0x1A01, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, this);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) {
        transmitPDO2MappedObject[i].init(0x1A01, i+1, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 0x00000000, this, &transmitPDO2Mapping, ODEntry::ACCESS_TXPDO);
        transmitPDO2Mapping.addEntry(&transmitPDO2MappedObject[i]);
    }
    transmitPDO2Mapping.setDefault();
    transmitPDO3Mapping.init(0x1A02, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, this);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) {
        transmitPDO3MappedObject[i].init(0x1A02, i+1, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 0x00000000, this, &transmitPDO3Mapping, ODEntry::ACCESS_TXPDO);
        transmitPDO3Mapping.addEntry(&transmitPDO3MappedObject[i]);
    }
    transmitPDO3Mapping.setDefault();
    transmitPDO4Mapping.init(0x1A03, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, this);
    for (uint8_t i = 0; i < NUMBER_OF_OBJECTS; i++) {
        transmitPDO4MappedObject[i].init(0x1A03, i+1, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 0x00000000, this, &transmitPDO4Mapping, ODEntry::ACCESS_TXPDO);
        transmitPDO4Mapping.addEntry(&transmitPDO4MappedObject[i]);
    }
    transmitPDO4Mapping.setDefault();
    nodeID.init(0x2000, 0x00, ODEntry::TYPE_UNSIGNED8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 15, 1, 127, this);
    canBitrate.init(0x2001, 0x00, ODEntry::TYPE_INTEGER8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_BACKUP, 0);
    canOpenNMTState.init(0x2002, 0x00, ODEntry::TYPE_UNSIGNED8, 0x08, ODEntry::ACCESS_READ, 0);
    timeStamp.init(0x2003, 0x00, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_TXPDO | ODEntry::ACCESS_RXPDO);
    consumerHeartbeatTimer.init(0x2004, ODEntry::ACCESS_READ, 1, &consumer1HeartbeatTimer);
    consumer1HeartbeatTimer.init(0x2004, 0x01, ODEntry::TYPE_UNSIGNED32, 0x20, ODEntry::ACCESS_READ);
    
    // ECU specific Objects
    ledStatus.init(0x2203, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_TXPDO | ODEntry::ACCESS_RXPDO, 0, 0, 1);
    counterActualValueFL.init(0x2300, 0x00, ODEntry::TYPE_INTEGER32, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, counterFL);
    counterActualValueFR.init(0x2302, 0x00, ODEntry::TYPE_INTEGER32, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, counterFR);
    counterActualValueRL.init(0x2304, 0x00, ODEntry::TYPE_INTEGER32, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, counterRL);
    counterActualValueRR.init(0x2306, 0x00, ODEntry::TYPE_INTEGER32, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, counterRR);
    actualSpeedFL.init(0x2310, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, controller,ODControllerValue::FL);
    actualSpeedFR.init(0x2312, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, controller,ODControllerValue::FR);
    actualSpeedRL.init(0x2314, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, controller,ODControllerValue::RL);
    actualSpeedRR.init(0x2316, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, controller,ODControllerValue::RR);
    actualTranslationalVelocity.init(0x2318, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, controller,ODControllerValue::TRANSLATIONAL);
    actualRotationalVelocity.init(0x2320, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, controller,ODControllerValue::ROATATIONAL);
    
    accelerationX.init(0x2400, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::ACCELERATION_X);
    accelerationY.init(0x2402, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::ACCELERATION_Y);
    accelerationZ.init(0x2404, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::ACCELERATION_Z);
    gyroX.init(0x2406, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::GYRO_X);
    gyroY.init(0x2408, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::GYRO_Y);
    gyroZ.init(0x2410, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::GYRO_Z);
    magnetometerX.init(0x2412, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::MAGNETOMETER_X);
    magnetometerY.init(0x2414, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::MAGNETOMETER_Y);
    magnetometerZ.init(0x2416, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::MAGNETOMETER_Z);
    roll.init(0x2418, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::ROLL);
    pitch.init(0x2420, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::PITCH);
    yaw.init(0x2422, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::YAW);
    rollRate.init(0x2424, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::ROLL_RATE);
    pitchRate.init(0x2426, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::PITCH_RATE);
    yawRate.init(0x2428, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, imu,ODImuValue::YAW_RATE);
    enableMotor.init(0x2504, 0x00, ODEntry::TYPE_INTEGER8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_TXPDO | ODEntry::ACCESS_RXPDO, 0, 0, 1);
    enableSteering.init(0x2506, 0x00, ODEntry::TYPE_INTEGER8, 0x08, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_TXPDO | ODEntry::ACCESS_RXPDO, 0, 0, 1);
    phaseVoltage.init(0x2508, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, controller,ODControllerValue::PHASE_VOLTAGE);
    batteryVoltage.init(0x2510, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, batteryVoltageSensor);
    actualSteeringAngle.init(0x2512, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, controller,ODControllerValue::STEERING_ANGLE);

    desiredSteeringAngle.init(0x2514, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_TXPDO | ODEntry::ACCESS_RXPDO, 0, -3142, 3142);
    desiredSteeringSpeed.init(0x2516, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_TXPDO | ODEntry::ACCESS_RXPDO, 0, -7000, 7000);
    desiredTranslationalVelocity.init(0x2518, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_TXPDO | ODEntry::ACCESS_RXPDO, 0, -20000, 20000);
    desiredTranslationalAcceleration.init(0x2520, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_WRITE | ODEntry::ACCESS_TXPDO | ODEntry::ACCESS_RXPDO, 0, -30000, 30000);
    ekfTranslationalVelocity.init(0x2522, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, motionEstimation,ODMotionEstimationValue::TRANSLATIONAL); //ODMotionEstimationValue::TRANSLATIONAL
    ekfRotationalVelocity.init(0x2524, 0x00, ODEntry::TYPE_INTEGER16, 0x10, ODEntry::ACCESS_READ | ODEntry::ACCESS_TXPDO, motionEstimation,ODMotionEstimationValue::ROATATIONAL);

    // initialise local values
    
    rxPDO1.clear();
    rxPDO2.clear();
    rxPDO3.clear();
    rxPDO4.clear();
    rxPDO1Length = 0;
    rxPDO2Length = 0;
    rxPDO3Length = 0;
    rxPDO4Length = 0;
    
    txPDO1.clear();
    txPDO2.clear();
    txPDO3.clear();
    txPDO4.clear();
    txPDO1Length = 0;
    txPDO2Length = 0;
    txPDO3Length = 0;
    txPDO4Length = 0;
}

ObjectDictionary::~ObjectDictionary() {}

/**
 * Searches the list of object dictionary entries for an object with given index and subindex,
 * and returns that object if it is found.
 * @param index the index of the object dictionary entry to find.
 * @param subindex the subindex of the object dictionary entry to find.
 * @return the object dictionary entry, or NULL if it is not found.
 */
ODEntry* ObjectDictionary::findODEntry(uint16_t index, uint8_t subindex) {
    
    uint16_t iMin = 0;
    uint16_t iMax = entries.size()-1;

    while (iMax >= iMin) {

        uint16_t i = (iMin+iMax)/2;

        if (entries[i]->getIndex() == index) {

            if (entries[i]->getSubindex() == subindex) {

                return entries[i];

            } else {

                if (entries[i]->getSubindex() < subindex) iMin = i+1; else iMax = i-1;
            }

        } else {

            if (entries[i]->getIndex() < index) iMin = i+1; else iMax = i-1;
        }
    }
    
    return NULL;
}

/**
 * Saves all parameters with an access flag 'backup' to nonvolatile memory.
 * @return a CANopen communication error, usually NO_COMMUNICATION_ERROR.
 */
uint32_t ObjectDictionary::saveParameters() {
    
    uint32_t abortCode = CANopen::NO_COMMUNICATION_ERROR;
    uint16_t address = 0x0000;
    
    // save the identity object first
    
    uint8_t length = 4;
    uint8_t buffer[length];
    
    vendorID.read(buffer, length);
    for (uint8_t j = 0; j < length; j++) {
        int32_t ack = eeprom.write(address, buffer[j]);
        if (ack != 0) abortCode = CANopen::TRANSFER_OR_STORE_ERROR;
        address++;
    }
    
    productCode.read(buffer, length);
    for (uint8_t j = 0; j < length; j++) {
        int32_t ack = eeprom.write(address, buffer[j]);
        if (ack != 0) abortCode = CANopen::TRANSFER_OR_STORE_ERROR;
        address++;
    }
    
    revisionNumber.read(buffer, length);
    for (uint8_t j = 0; j < length; j++) {
        int32_t ack = eeprom.write(address, buffer[j]);
        if (ack != 0) abortCode = CANopen::TRANSFER_OR_STORE_ERROR;
        address++;
    }
    
    serialNumber.read(buffer, length);
    for (uint8_t j = 0; j < length; j++) {
        int32_t ack = eeprom.write(address, buffer[j]);
        if (ack != 0) abortCode = CANopen::TRANSFER_OR_STORE_ERROR;
        address++;
    }
    
    // save all objects with the backup flag set
    
    for (uint16_t i = 0; i < entries.size(); i++) {
        
        if (entries[i]->getAccess() & ODEntry::ACCESS_BACKUP) {
            
            uint8_t length = entries[i]->getBitlength()/8;
            uint8_t buffer[length];
            
            entries[i]->read(buffer, length);
            
            for (uint8_t j = 0; j < length; j++) {
                int32_t ack = eeprom.write(address, buffer[j]);
                if (ack != 0) abortCode = CANopen::TRANSFER_OR_STORE_ERROR;
                address++;
            }
        }
    }
    
    return abortCode;
}

/**
 * Loads and restores all parameters with an access flag 'backup' from nonvolatile memory.
 * @return a CANopen communication error, such as NO_COMMUNICATION_ERROR or TRANSFER_OR_STORE_ERROR.
 */
uint32_t ObjectDictionary::loadParameters() {
    
    uint32_t abortCode = CANopen::NO_COMMUNICATION_ERROR;
    uint16_t address = 0x0000;
    
    // load the identity object first
    
    uint8_t length = 4;
    uint8_t buffer[length];
    
    for (uint8_t j = 0; j < length; j++) {
        int32_t ack = eeprom.read(address, buffer[j]);
        if (ack != 0) abortCode = CANopen::TRANSFER_OR_STORE_ERROR;
        address++;
    }
    
    uint32_t vendorID = static_cast<uint32_t>(buffer[0]) | (static_cast<uint32_t>(buffer[1]) << 8) | (static_cast<uint32_t>(buffer[2]) << 16) | (static_cast<uint32_t>(buffer[3]) << 24);
    
    for (uint8_t j = 0; j < length; j++) {
        int32_t ack = eeprom.read(address, buffer[j]);
        if (ack != 0) abortCode = CANopen::TRANSFER_OR_STORE_ERROR;
        address++;
    }
    
    uint32_t productCode = static_cast<uint32_t>(buffer[0]) | (static_cast<uint32_t>(buffer[1]) << 8) | (static_cast<uint32_t>(buffer[2]) << 16) | (static_cast<uint32_t>(buffer[3]) << 24);
    
    for (uint8_t j = 0; j < length; j++) {
        int32_t ack = eeprom.read(address, buffer[j]);
        if (ack != 0) abortCode = CANopen::TRANSFER_OR_STORE_ERROR;
        address++;
    }
    
    uint32_t revisionNumber = static_cast<uint32_t>(buffer[0]) | (static_cast<uint32_t>(buffer[1]) << 8) | (static_cast<uint32_t>(buffer[2]) << 16) | (static_cast<uint32_t>(buffer[3]) << 24);
    
    for (uint8_t j = 0; j < length; j++) {
        int32_t ack = eeprom.read(address, buffer[j]);
        if (ack != 0) abortCode = CANopen::TRANSFER_OR_STORE_ERROR;
        address++;
    }
    
    uint32_t serialNumber = static_cast<uint32_t>(buffer[0]) | (static_cast<uint32_t>(buffer[1]) << 8) | (static_cast<uint32_t>(buffer[2]) << 16) | (static_cast<uint32_t>(buffer[3]) << 24);
    
    // check if the identity object matches with the current firmware
    
    if ((vendorID == this->vendorID) && (productCode == this->productCode) && (revisionNumber == this->revisionNumber) && (serialNumber == this->serialNumber)) {
        
        // load all objects with the backup flag set
        
        for (uint16_t i = 0; i < entries.size(); i++) {
            
            if (entries[i]->getAccess() & ODEntry::ACCESS_BACKUP) {
                
                uint8_t length = entries[i]->getBitlength()/8;
                uint8_t buffer[length];
                
                for (uint8_t j = 0; j < length; j++) {
                    int32_t ack = eeprom.read(address, buffer[j]);
                    if (ack != 0) abortCode = CANopen::TRANSFER_OR_STORE_ERROR;
                    address++;
                }
                
                entries[i]->write(buffer, length);
            }
        }
        
    } else {
        
        abortCode = CANopen::TRANSFER_OR_STORE_ERROR;
    }
    
    return abortCode;
}

/**
 * Sets default values to object parameters.
 * @return a CANopen communication error, usually NO_COMMUNICATION_ERROR.
 */
uint32_t ObjectDictionary::loadDefaultParameters() {
    
    // set factory default parameters for all object dictionary entries
    
    for (uint16_t i = 0; i < entries.size(); i++) entries[i]->setDefault();
    
    // save parameters and return
    
    return saveParameters();
}

/**
 * Writes an object with given index and subindex.
 * @param index the index of the object dictionary entry to write.
 * @param subindex the subindex of the object dictionary entry to write.
 * @param buffer an array of bytes that defines this object's value.
 * @param length a reference to an integer holding the length of this object
 * in bytes. This parameter is set to the actual length by this method.
 * @return a CANopen communication error, such as NO_COMMUNICATION_ERROR,
 * READ_ONLY, VALUE_TOO_HIGH_ERROR, etc.
 */
uint32_t ObjectDictionary::writeObject(uint16_t index, uint8_t subindex, uint8_t buffer[], uint8_t& length) {

    bool indexFound = false;

    uint16_t iMin = 0;
    uint16_t iMax = entries.size()-1;

    while (iMax >= iMin) {

        uint16_t i = (iMin+iMax)/2;

        if (entries[i]->getIndex() == index) {

            indexFound = true;

            if (entries[i]->getSubindex() == subindex) {

                return entries[i]->write(buffer, length);

            } else {

                if (entries[i]->getSubindex() < subindex) iMin = i+1; else iMax = i-1;
            }

        } else {

            if (entries[i]->getIndex() < index) iMin = i+1; else iMax = i-1;
        }
    }

    if (indexFound) return CANopen::SUBINDEX_DOES_NOT_EXIST;
    else return CANopen::OBJECT_DOES_NOT_EXIST_ERROR;
}

/**
 * Reads an object with given index and subindex.
 * @param index the index of the object dictionary entry to read.
 * @param subindex the subindex of the object dictionary entry to read.
 * @param buffer an array of bytes where this value must be copied into.
 * @param length a reference to an integer holding the length of this object
 * in bytes. This parameter is set to the actual length by this method.
 * @return a CANopen communication error, such as NO_COMMUNICATION_ERROR,
 * ACCESS_ERROR, WRITE_ONLY, etc.
 */
uint32_t ObjectDictionary::readObject(uint16_t index, uint8_t subindex, uint8_t buffer[], uint8_t& length) {
    
    bool indexFound = false;

    uint16_t iMin = 0;
    uint16_t iMax = entries.size()-1;
    
    while (iMax >= iMin) {

        uint16_t i = (iMin+iMax)/2;

        if (entries[i]->getIndex() == index) {

            indexFound = true;

            if (entries[i]->getSubindex() == subindex) {
                
                return entries[i]->read(buffer, length);

            } else {

                if (entries[i]->getSubindex() < subindex) iMin = i+1; else iMax = i-1;
            }

        } else {

            if (entries[i]->getIndex() < index) iMin = i+1; else iMax = i-1;
        }
    }
    
    if (indexFound) return CANopen::SUBINDEX_DOES_NOT_EXIST;
    else return CANopen::OBJECT_DOES_NOT_EXIST_ERROR;
}

/**
 * Creates an internal list of mapped objects for fast PDO processing.
 * This method is called by the CANopen stack when switching to the operational mode.
 */
void ObjectDictionary::configureRxPDOs() {
    
    rxPDO1.clear();
    rxPDO2.clear();
    rxPDO3.clear();
    rxPDO4.clear();
    rxPDO1Length = 0;
    rxPDO2Length = 0;
    rxPDO3Length = 0;
    rxPDO4Length = 0;
    
    for (uint8_t i = 0; i < receivePDO1Mapping; i++) {
        uint16_t index = static_cast<uint16_t>((receivePDO1MappedObject[i] >> 16) & 0xFFFF);
        uint8_t subindex = static_cast<uint8_t>((receivePDO1MappedObject[i] >> 8) & 0xFF);
        ODEntry* entry = findODEntry(index, subindex);
        if (entry != NULL) {
            rxPDO1.push_back(entry);
            rxPDO1Length += entry->getBitlength()/8;
        }
    }
    
    for (uint8_t i = 0; i < receivePDO2Mapping; i++) {
        uint16_t index = static_cast<uint16_t>((receivePDO2MappedObject[i] >> 16) & 0xFFFF);
        uint8_t subindex = static_cast<uint8_t>((receivePDO2MappedObject[i] >> 8) & 0xFF);
        ODEntry* entry = findODEntry(index, subindex);
        if (entry != NULL) {
            rxPDO2.push_back(entry);
            rxPDO2Length += entry->getBitlength()/8;
        }
    }
    
    for (uint8_t i = 0; i < receivePDO3Mapping; i++) {
        uint16_t index = static_cast<uint16_t>((receivePDO3MappedObject[i] >> 16) & 0xFFFF);
        uint8_t subindex = static_cast<uint8_t>((receivePDO3MappedObject[i] >> 8) & 0xFF);
        ODEntry* entry = findODEntry(index, subindex);
        if (entry != NULL) {
            rxPDO3.push_back(entry);
            rxPDO3Length += entry->getBitlength()/8;
        }
    }
    
    for (uint8_t i = 0; i < receivePDO4Mapping; i++) {
        uint16_t index = static_cast<uint16_t>((receivePDO4MappedObject[i] >> 16) & 0xFFFF);
        uint8_t subindex = static_cast<uint8_t>((receivePDO4MappedObject[i] >> 8) & 0xFF);
        ODEntry* entry = findODEntry(index, subindex);
        if (entry != NULL) {
            rxPDO4.push_back(entry);
            rxPDO4Length += entry->getBitlength()/8;
        }
    }
}

/**
 * Creates an internal list of mapped objects for fast PDO processing.
 * This method is called by the CANopen stack when switching to the operational mode.
 */
void ObjectDictionary::configureTxPDOs() {
    
    txPDO1.clear();
    txPDO2.clear();
    txPDO3.clear();
    txPDO4.clear();
    txPDO1Length = 0;
    txPDO2Length = 0;
    txPDO3Length = 0;
    txPDO4Length = 0;
    
    for (uint8_t i = 0; i < transmitPDO1Mapping; i++) {
        uint16_t index = static_cast<uint16_t>((transmitPDO1MappedObject[i] >> 16) & 0xFFFF);
        uint8_t subindex = static_cast<uint8_t>((transmitPDO1MappedObject[i] >> 8) & 0xFF);
        ODEntry* entry = findODEntry(index, subindex);
        if (entry != NULL) {
            txPDO1.push_back(entry);
            txPDO1Length += entry->getBitlength()/8;
        }
    }
    
    for (uint8_t i = 0; i < transmitPDO2Mapping; i++) {
        uint16_t index = static_cast<uint16_t>((transmitPDO2MappedObject[i] >> 16) & 0xFFFF);
        uint8_t subindex = static_cast<uint8_t>((transmitPDO2MappedObject[i] >> 8) & 0xFF);
        ODEntry* entry = findODEntry(index, subindex);
        if (entry != NULL) {
            txPDO2.push_back(entry);
            txPDO2Length += entry->getBitlength()/8;
        }
    }
    
    for (uint8_t i = 0; i < transmitPDO3Mapping; i++) {
        uint16_t index = static_cast<uint16_t>((transmitPDO3MappedObject[i] >> 16) & 0xFFFF);
        uint8_t subindex = static_cast<uint8_t>((transmitPDO3MappedObject[i] >> 8) & 0xFF);
        ODEntry* entry = findODEntry(index, subindex);
        if (entry != NULL) {
            txPDO3.push_back(entry);
            txPDO3Length += entry->getBitlength()/8;
        }
    }
    
    for (uint8_t i = 0; i < transmitPDO4Mapping; i++) {
        uint16_t index = static_cast<uint16_t>((transmitPDO4MappedObject[i] >> 16) & 0xFFFF);
        uint8_t subindex = static_cast<uint8_t>((transmitPDO4MappedObject[i] >> 8) & 0xFF);
        ODEntry* entry = findODEntry(index, subindex);
        if (entry != NULL) {
            txPDO4.push_back(entry);
            txPDO4Length += entry->getBitlength()/8;
        }
    }
}

/**
 * Writes to the mapped objects of an RxPDO.
 * @param pdo the number of the RxPDO to process, either 1, 2, 3 or 4.
 * @param buffer the data buffer to read object values from.
 * @param length the length of the data buffer. This value must be equal or larger than the length
 * of mapped objects, and it returns the actual length of mapped objects.
 */
uint32_t ObjectDictionary::writeRxPDO(uint8_t pdo, uint8_t buffer[], uint8_t& length) {
    
    uint32_t abortCode = CANopen::NO_COMMUNICATION_ERROR;
    uint16_t index = 0;
    
    switch (pdo) {
        case 1:
            if (length < rxPDO1Length) {
                abortCode = CANopen::PDO_LENGTH_ERROR;
            } else {
                for (uint8_t i = 0; i < rxPDO1.size(); i++) {
                    rxPDO1[i]->write(&(buffer[index]), length);
                    index += rxPDO1[i]->getBitlength()/8;
                }
                length = index;
            }
            break;
        case 2:
            if (length < rxPDO2Length) {
                abortCode = CANopen::PDO_LENGTH_ERROR;
            } else {
                for (uint8_t i = 0; i < rxPDO2.size(); i++) {
                    rxPDO2[i]->write(&(buffer[index]), length);
                    index += rxPDO2[i]->getBitlength()/8;
                }
                length = index;
            }
            break;
        case 3:
            if (length < rxPDO3Length) {
                abortCode = CANopen::PDO_LENGTH_ERROR;
            } else {
                for (uint8_t i = 0; i < rxPDO3.size(); i++) {
                    rxPDO3[i]->write(&(buffer[index]), length);
                    index += rxPDO3[i]->getBitlength()/8;
                }
                length = index;
            }
            break;
        case 4:
            if (length < rxPDO4Length) {
                abortCode = CANopen::PDO_LENGTH_ERROR;
            } else {
                for (uint8_t i = 0; i < rxPDO4.size(); i++) {
                    rxPDO4[i]->write(&(buffer[index]), length);
                    index += rxPDO4[i]->getBitlength()/8;
                }
                length = index;
            }
            break;
        default:
            abortCode = CANopen::GENERAL_ERROR;
            break;
    }
    
    return abortCode;
}

/**
 * Reads from the mapped objects of a TxPDO.
 * @param pdo the number of the TxPDO to process, either 1, 2, 3 or 4.
 * @param buffer the data buffer to write object values into.
 * @param length the length of the data buffer. This value must be equal or larger than the length
 * of mapped objects, and it returns the actual length of mapped objects.
 */
uint32_t ObjectDictionary::readTxPDO(uint8_t pdo, uint8_t buffer[], uint8_t& length) {
    
    uint32_t abortCode = CANopen::NO_COMMUNICATION_ERROR;
    uint16_t index = 0;
    
    switch (pdo) {
        case 1:
            if (length < txPDO1Length) {
                abortCode = CANopen::PDO_LENGTH_ERROR;
            } else {
                for (uint8_t i = 0; i < txPDO1.size(); i++) {
                    txPDO1[i]->read(&(buffer[index]), length);
                    index += txPDO1[i]->getBitlength()/8;
                }
                length = index;
            }
            break;
        case 2:
            if (length < txPDO2Length) {
                abortCode = CANopen::PDO_LENGTH_ERROR;
            } else {
                for (uint8_t i = 0; i < txPDO2.size(); i++) {
                    txPDO2[i]->read(&(buffer[index]), length);
                    index += txPDO2[i]->getBitlength()/8;
                }
                length = index;
            }
            break;
        case 3:
            if (length < txPDO3Length) {
                abortCode = CANopen::PDO_LENGTH_ERROR;
            } else {
                for (uint8_t i = 0; i < txPDO3.size(); i++) {
                    txPDO3[i]->read(&(buffer[index]), length);
                    index += txPDO3[i]->getBitlength()/8;
                }
                length = index;
            }
            break;
        case 4:
            if (length < txPDO4Length) {
                abortCode = CANopen::PDO_LENGTH_ERROR;
            } else {
                for (uint8_t i = 0; i < txPDO4.size(); i++) {
                    txPDO4[i]->read(&(buffer[index]), length);
                    index += txPDO4[i]->getBitlength()/8;
                }
                length = index;
            }
            break;
        default:
            abortCode = CANopen::GENERAL_ERROR;
            break;
    }
    
    return abortCode;
}
