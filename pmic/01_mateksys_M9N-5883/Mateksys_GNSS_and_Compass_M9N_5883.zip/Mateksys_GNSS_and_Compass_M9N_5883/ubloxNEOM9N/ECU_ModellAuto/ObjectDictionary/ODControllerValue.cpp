/*
 * ODControllerValue.h
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 12.02.2021
 *      Author: Nicolas Borla
 */

#include "ODControllerValue.h"

using namespace std;

/**
 * Initializes the position actual value object dictionary entry.
 */
void ODControllerValue::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, Controller* controller, uint8_t valueID) {
    
    ODTypedEntry<int16_t>::init(index, subindex, type, bitlength, access);
    
    this->controller = controller;
    this->valueID = valueID;
}

/**
 * Reads the value of this object dictionary entry.
 */
uint32_t ODControllerValue::read(uint8_t buffer[], uint8_t& length) {
    
    if(valueID==ODControllerValue::FL){
        value = static_cast<int16_t>(controller->getActualVelocityFL()*100.0f);
    } 
    else if (valueID == ODControllerValue::FR){
        value = static_cast<int16_t>(controller->getActualVelocityFR()*100.0f);
    } 
    else if (valueID == ODControllerValue::RL){
        value = static_cast<int16_t>(controller->getActualVelocityRL()*100.0f);
    } 
    else if (valueID == ODControllerValue::RR){
        value = static_cast<int16_t>(controller->getActualVelocityRR()*100.0f);
    }
    else if (valueID == ODControllerValue::TRANSLATIONAL){
        value = static_cast<int16_t>(controller->getActualTranslationalVelocity()*1000.0f);
    }
    else if (valueID == ODControllerValue::ROATATIONAL){
        value = static_cast<int16_t>(controller->getActualRotationalVelocity()*1000.0f);
    }
    else if (valueID == ODControllerValue::PHASE_VOLTAGE){
        value = static_cast<int16_t>(controller->getMotorVoltage()*1000.0f);
    }
    else if (valueID == ODControllerValue::STEERING_ANGLE){
        value = static_cast<int16_t>(controller->getSteeringAngle()*1000.0f);
    } 
    else {
        value = 404.0f; // ID not recognised
    }
    
    //printf("%d\r\n",value);
    
    return ODTypedEntry<int16_t>::read(buffer, length);
}

/**
 * Reads the value of this object dictionary entry.
 */
int16_t ODControllerValue::read() {
    
    if(valueID==ODControllerValue::FL){
        value = static_cast<int16_t>(controller->getActualVelocityFL()*100.0f);
    } 
    else if (valueID == ODControllerValue::FR){
        value = static_cast<int16_t>(controller->getActualVelocityFR()*100.0f);
    } 
    else if (valueID == ODControllerValue::RL){
        value = static_cast<int16_t>(controller->getActualVelocityRL()*100.0f);
    } 
    else if (valueID == ODControllerValue::RR){
        value = static_cast<int16_t>(controller->getActualVelocityRR()*100.0f);
    }
    else if (valueID == ODControllerValue::TRANSLATIONAL){
        value = static_cast<int16_t>(controller->getActualTranslationalVelocity()*1000.0f);
    }
    else if (valueID == ODControllerValue::ROATATIONAL){
        value = static_cast<int16_t>(controller->getActualRotationalVelocity()*1000.0f);
    }
    else if (valueID == ODControllerValue::PHASE_VOLTAGE){
        value = static_cast<int16_t>(controller->getMotorVoltage()*1000.0f);
    } 
    else if (valueID == ODControllerValue::STEERING_ANGLE){
        value = static_cast<int16_t>(controller->getSteeringAngle()*1000.0f);
    }
    else {
        value = 404.0f; // ID not recognised
    }

    return value;
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
ODControllerValue::operator int16_t() {
    
    return read();
}
