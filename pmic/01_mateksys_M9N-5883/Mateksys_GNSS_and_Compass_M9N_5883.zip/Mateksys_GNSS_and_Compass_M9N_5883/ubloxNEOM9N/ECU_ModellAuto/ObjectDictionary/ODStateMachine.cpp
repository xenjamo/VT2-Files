/*
 * ODStateMachine.cpp
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 19.03.2021
 *      Author: Nicolas Borla
 */

#include "ODStateMachine.h"
#include "StateMachine.h"

using namespace std;

/**
 * Initializes the position actual value object dictionary entry.
 */
void ODStateMachine::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, StateMachine* stateMachine, uint8_t valueID) {
    
    ODTypedEntry<int16_t>::init(index, subindex, type, bitlength, access);
    
    this->stateMachine = stateMachine;
    this->valueID = valueID;
}

/**
 * Writes the value of this object dictionary entry.
 */
void ODStateMachine::write(int16_t value) {

    printf("value recived %d\r\n",value);
/*
    ODTypedEntry<int16_t>::write(value);
    
    if(valueID==ODStateMachine::WRITE_STEERING_ANGLE){
        stateMachine->setRemoteSteeringAngle(static_cast<double>(value/1000.0));
    } 
    else if(valueID==ODStateMachine::WRITE_STEERING_SPEED){
        stateMachine->setRemoteSteeringAngleVelocity(static_cast<double>(value/1000.0));
    }
    else if(valueID==ODStateMachine::WRITE_VELOCITY){
        stateMachine->setRemoteVelocity(static_cast<double>(value/1000.0));
    }
    else if(valueID==ODStateMachine::WRITE_ACCELERATION){
        stateMachine->setRemoteAcceleration(static_cast<double>(value/1000.0));
    }
    else {
        value = 0.0f; // ID not recognised
    }*/
}

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
ODStateMachine& ODStateMachine::operator=(int16_t value) {
    
    write(value);
    
    return *this;
}

/**
 * Reads the value of this object dictionary entry.
 */
uint32_t ODStateMachine::read(uint8_t buffer[], uint8_t& length) {
    /*
    if(valueID==ODStateMachine::FL){
        value = static_cast<int16_t>(controller->getActualVelocityFL()*1000.0f);
    } 
    else {
        value = 404.0f; // ID not recognised
    }
    */
    //printf("%d\r\n",value);
    
    return ODTypedEntry<int16_t>::read(buffer, length);
}

/**
 * Reads the value of this object dictionary entry.
 */
int16_t ODStateMachine::read() {
    
    /*
    if(valueID==ODStateMachine::FL){
        value = static_cast<int16_t>(controller->getActualVelocityFL()*1000.0f);
    } 
    else {
        value = 404.0f; // ID not recognised
    }
    */
    //printf("%d\r\n",value);

    return value;
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
ODStateMachine::operator int16_t() {
    
    return read();
}
