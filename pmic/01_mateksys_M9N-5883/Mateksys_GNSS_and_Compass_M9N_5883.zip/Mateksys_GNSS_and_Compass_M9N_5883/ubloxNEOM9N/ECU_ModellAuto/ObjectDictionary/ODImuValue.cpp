/*
 * ODImuValue.cpp
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 12.02.2021
 *      Author: Nicolas Borla
 */

#include "ODImuValue.h"
#include "OpenIMU300ZI.h"

using namespace std;

/**
 * Initializes the position actual value object dictionary entry.
 */
void ODImuValue::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, OpenIMU300ZI* imu, uint8_t valueID) {
    
    ODTypedEntry<int16_t>::init(index, subindex, type, bitlength, access);
    
    this->imu = imu;
    this->valueID = valueID;
}

/**
 * Reads the value of this object dictionary entry.
 */
uint32_t ODImuValue::read(uint8_t buffer[], uint8_t& length) {
    
    if(valueID==ODImuValue::ROLL){
        value = static_cast<int16_t>(imu->getRoll()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::PITCH){
        value = static_cast<int16_t>(imu->getPitch()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::YAW){
        value = static_cast<int16_t>(imu->getYaw()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::ROLL_RATE){
        value = static_cast<int16_t>(imu->getAngularVelocityX()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::PITCH_RATE){
        value = static_cast<int16_t>(imu->getAngularVelocityY()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::YAW_RATE){
        value = static_cast<int16_t>(imu->getAngularVelocityZ()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::ACCELERATION_X){
        value = static_cast<int16_t>(imu->getAccelerationX()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::ACCELERATION_Y){
        value = static_cast<int16_t>(imu->getAccelerationY()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::ACCELERATION_Z){
        value = static_cast<int16_t>(imu->getAccelerationZ()*INT_TO_DOUBLE_FACTOR);
    }
    else {
        value = 404.0f; // ID not recognised
    }
    
    //printf("%d\r\n",value);
    
    return ODTypedEntry<int16_t>::read(buffer, length);
}

/**
 * Reads the value of this object dictionary entry.
 */
int16_t ODImuValue::read() {
    
    if(valueID==ODImuValue::ROLL){
        value = static_cast<int16_t>(imu->getRoll()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::PITCH){
        value = static_cast<int16_t>(imu->getPitch()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::YAW){
        value = static_cast<int16_t>(imu->getYaw()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::ROLL_RATE){
        value = static_cast<int16_t>(imu->getAngularVelocityX()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::PITCH_RATE){
        value = static_cast<int16_t>(imu->getAngularVelocityY()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::YAW_RATE){
        value = static_cast<int16_t>(imu->getAngularVelocityZ()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::ACCELERATION_X){
        value = static_cast<int16_t>(imu->getAccelerationX()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::ACCELERATION_Y){
        value = static_cast<int16_t>(imu->getAccelerationY()*INT_TO_DOUBLE_FACTOR);
    }
    else if(valueID==ODImuValue::ACCELERATION_Z){
        value = static_cast<int16_t>(imu->getAccelerationZ()*INT_TO_DOUBLE_FACTOR);
    }
    else {
        value = 404.0f; // ID not recognised
    }

    return value;
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
ODImuValue::operator int16_t() {
    
    return read();
}
