/*
 * ODEntry.h
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#ifndef OD_ENTRY_H_
#define OD_ENTRY_H_

#include <cstdlib>
#include <string>
#include <vector>
#include <stdint.h>

using namespace std;

/**
 * The <code>ODEntry</code> class is the base class for object dictionary entries.
 */
class ODEntry {
    
    public:
        
        static const uint8_t TYPE_NULL = 0x00;              /**< CANopen object entry data type */
        static const uint8_t TYPE_BOOLEAN = 0x01;           /**< CANopen object entry data type */
        static const uint8_t TYPE_INTEGER8 = 0x02;          /**< CANopen object entry data type */
        static const uint8_t TYPE_INTEGER16 = 0x03;         /**< CANopen object entry data type */
        static const uint8_t TYPE_INTEGER32 = 0x04;         /**< CANopen object entry data type */
        static const uint8_t TYPE_UNSIGNED8 = 0x05;         /**< CANopen object entry data type */
        static const uint8_t TYPE_UNSIGNED16 = 0x06;        /**< CANopen object entry data type */
        static const uint8_t TYPE_UNSIGNED32 = 0x07;        /**< CANopen object entry data type */
        static const uint8_t TYPE_REAL32 = 0x08;            /**< CANopen object entry data type */
        static const uint8_t TYPE_VISIBLESTRING = 0x09;     /**< CANopen object entry data type */
        static const uint8_t TYPE_RECORD = 0x2A;            /**< CANopen object entry data type */
        
        static const uint8_t ACCESS_READ = 0x01;            /**< Object entry access method flag */
        static const uint8_t ACCESS_WRITE = 0x02;           /**< Object entry access method flag */
        static const uint8_t ACCESS_TXPDO = 0x04;           /**< Object entry access method flag */
        static const uint8_t ACCESS_RXPDO = 0x08;           /**< Object entry access method flag */
        static const uint8_t ACCESS_BACKUP = 0x10;          /**< Object entry access method flag */
        
                            ODEntry();
        virtual             ~ODEntry();
        virtual void        init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access);
        void                setIndex(uint16_t index);
        uint16_t            getIndex();
        void                setSubindex(uint8_t subindex);
        uint8_t             getSubindex();
        uint8_t             getType();
        uint8_t             getBitlength();
        void                setAccess(uint8_t access);
        uint8_t             getAccess();
        virtual void        setDefault();
        virtual uint32_t    write(uint8_t buffer[], uint8_t& length);
        virtual uint32_t    read(uint8_t buffer[], uint8_t& length);
        
    protected:
        
        uint16_t            index;
        uint8_t             subindex;
        uint8_t             type;
        uint8_t             bitlength;
        uint8_t             access;
};

#endif /* OD_ENTRY_H_ */
