/*
 * ODCounterActualValue.h
 * Copyright (c) 2016, ZHAW
 * All rights reserved.
 *
 *  Created on: 05.02.2021
 *      Author: Nicolas Borla
 */

#ifndef OD_COUNTER_ACTUAL_VALUE_H_
#define OD_COUNTER_ACTUAL_VALUE_H_

#include <cstdlib>
#include <stdint.h>
#include "ODTypedEntry.h"
#include "EncoderF767ZI.h"

using namespace std;

/**
 * The <code>ODCounterActualValue</code> class implements an object dictionary entry
 * to read and reset the encoder counter value.
 */
class ODCounterActualValue : public ODTypedEntry<int16_t> {
    
    public:
        
        using                       ODTypedEntry<int16_t>::init;
        void                        init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, EncoderCounter* counter);
        virtual void                write(int16_t value);
        ODCounterActualValue&       operator=(int16_t value);
        virtual uint32_t            read(uint8_t buffer[], uint8_t& length);
        virtual int16_t             read();
                                    operator int16_t();
        
    private:
        
        EncoderCounter*             counter;
};

#endif /* OD_COUNTER_ACTUAL_VALUE_H_ */
