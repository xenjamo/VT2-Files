/*
 * ODErrorRegister.h
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#ifndef OD_ERROR_REGISTER_H_
#define OD_ERROR_REGISTER_H_

#include <cstdlib>
#include <stdint.h>
#include "ODTypedEntry.h"

/**
 * The <code>ODErrorRegister</code> class implements an object dictionary entry
 * that implements an error register to map various errors into.
 */
class ODErrorRegister : public ODTypedEntry<uint8_t> {
    
    public:
        
        static const uint8_t    GENERIC_ERROR = 0x01;
        static const uint8_t    CURRENT_ERROR = 0x02;
        static const uint8_t    VOLTAGE_ERROR = 0x04;
        static const uint8_t    TEMPERATURE_ERROR = 0x08;
        static const uint8_t    COMMUNICATION_ERROR = 0x10;
        static const uint8_t    DEVICE_PROFILE_SPECIFIC_ERROR = 0x20;
        static const uint8_t    RESERVED_ERROR = 0x40;
        static const uint8_t    MOTION_ERROR = 0x80;
        
        ODErrorRegister&        operator=(uint8_t value);
                                operator uint8_t();
};

#endif /* OD_ERROR_REGISTER_H_ */
