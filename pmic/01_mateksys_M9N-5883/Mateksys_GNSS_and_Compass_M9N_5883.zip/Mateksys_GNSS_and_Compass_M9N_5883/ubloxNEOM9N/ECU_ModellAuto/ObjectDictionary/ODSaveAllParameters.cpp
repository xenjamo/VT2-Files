/*
 * ODSaveAllParameters.cpp
 * Copyright (c) 2015, ZHAW
 * All rights reserved.
 *
 *  Created on: 23.09.2015
 *      Author: Marcel Honegger
 */

#include "ObjectDictionary.h"
#include "CANopen.h"
#include "ODSaveAllParameters.h"

using namespace std;

void ODSaveAllParameters::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, uint32_t defaultValue, uint32_t minValue, uint32_t maxValue, ObjectDictionary* objectDictionary) {
    
    ODTypedEntry<uint32_t>::init(index, subindex, type, bitlength, access, defaultValue, minValue, maxValue);
    
    this->objectDictionary = objectDictionary;
}

/**
 * Writes the value of this object dictionary entry.
 */
uint32_t ODSaveAllParameters::write(uint8_t buffer[], uint8_t& length) {
    
    uint32_t abortCode = ODTypedEntry<uint32_t>::write(buffer, length);
    if (abortCode == CANopen::NO_COMMUNICATION_ERROR) abortCode = objectDictionary->saveParameters();
    
    return abortCode;
}

/**
 * Writes the value of this object dictionary entry.
 */
void ODSaveAllParameters::write(uint32_t value) {
    
    if (value == 0x65766173) {
        
        ODTypedEntry<uint32_t>::write(value);
        objectDictionary->saveParameters();
    }
}

/**
 * The '=' operator is a shorthand notation of the <code>write()</code> method.
 */
ODSaveAllParameters& ODSaveAllParameters::operator=(uint32_t value) {
    
    write(value);
    
    return *this;
}
