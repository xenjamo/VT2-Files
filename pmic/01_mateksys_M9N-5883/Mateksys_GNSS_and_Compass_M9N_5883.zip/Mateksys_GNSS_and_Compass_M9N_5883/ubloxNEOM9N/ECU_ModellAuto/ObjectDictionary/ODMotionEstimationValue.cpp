/*
 * ODMotionEstimationValue.cpp
 * Copyright (c) 2021, ZHAW
 * All rights reserved.
 *
 *  Created on: 19.06.2021
 *      Author: Nicolas Borla
 */

#include "ODMotionEstimationValue.h"
#include "MotionEstimation.h"

using namespace std;

/**
 * Initializes the position actual value object dictionary entry.
 */
void ODMotionEstimationValue::init(uint16_t index, uint8_t subindex, uint8_t type, uint8_t bitlength, uint8_t access, MotionEstimation* motionEstimation, uint8_t valueID) {
    
    ODTypedEntry<int16_t>::init(index, subindex, type, bitlength, access);
    
    this->motionEstimation = motionEstimation;
    this->valueID = valueID;
}

/**
 * Reads the value of this object dictionary entry.
 */
uint32_t ODMotionEstimationValue::read(uint8_t buffer[], uint8_t& length) {
    
    if (valueID == ODMotionEstimationValue::TRANSLATIONAL){
        value = static_cast<int16_t>(motionEstimation->getTranslationalVelocity()*100.0f);
    }
    else if (valueID == ODMotionEstimationValue::ROATATIONAL){
        value = static_cast<int16_t>(motionEstimation->getRotationalVelocity()*100.0f);
    }
    else {
        value = 404.0f; // ID not recognised
    }
    
    //printf("%d\r\n",value);
    
    return ODTypedEntry<int16_t>::read(buffer, length);
}

/**
 * Reads the value of this object dictionary entry.
 */
int16_t ODMotionEstimationValue::read() {
    
    if (valueID == ODMotionEstimationValue::TRANSLATIONAL){
        value = static_cast<int16_t>(motionEstimation->getTranslationalVelocity()*100.0f);
    }
    else if (valueID == ODMotionEstimationValue::ROATATIONAL){
        value = static_cast<int16_t>(motionEstimation->getRotationalVelocity()*100.0f);
    }
    else {
        value = 404.0f; // ID not recognised
    }

    return value;
}

/**
 * The empty operator is a shorthand notation of the <code>read()</code> method.
 */
ODMotionEstimationValue::operator int16_t() {
    
    return read();
}
