/*
 * OpenIMU300ZI.cpp
 * Copyright (c) 2018, ZHAW
 * All rights reserved.
 *
*/

#include "OpenIMU300ZI.h"


#define TRACE if(debugSerial) debugSerial->write("Trace "+name+" Time: "+to_string(debugTimer.read_ms())+" ms, Line: "+to_string(__LINE__));
#define PRINT(msg) if(debugSerial) debugSerial->write("Message of Line "+to_string(__LINE__)+":  "+string(msg));

using namespace std;

/**
 * Creates and initializes the driver to read a Graupner RC-Receiver. The Receiver provides an interface to read each channel. After instantiate the object, it has to be switched on 
 * (by using function switchOn()).
 * This class needs to be RealtimePriority, otherwise it will not work. Probabliy this is caused by the timer (uses microseconds).
 * @param Tx The Tx Pin, which is not used and not connected.  
 * @param Rx The Rx Pin to the SUMD signal of the Graupner Receiver (eg. GR16)
 * @param led whenever we read a new serial packet, this led toggles. Means it helps to check if the system is still working
 * @param name name of this instance
 * @param debugSerial Interface to plot the debug messages
 */
OpenIMU300ZI::OpenIMU300ZI(PinName mosi, PinName miso, PinName sclk, PinName ssel, DigitalOut &reset, string name, DebugOutput * debugSerial):
    Thread(osPriorityHigh1, OS_STACK_SIZE, NULL,  name.c_str()),
    spi(mosi, miso, sclk), //ssel of spi does not work properly, always fails on a hard fault
    slaveSelectLine(ssel),
    resetIMU(reset),
    debugLed(LED2){

    this->name = name;
    this->debugSerial = debugSerial; 

    
    debugTimer.start();
    resetIMU = 0; //Reset device while setting up SPI interface
    
    //wait_us(50000);
    Timer delayTimer;
    delayTimer.reset();
    delayTimer.start();
    while(delayTimer.read_ms() < 50); //wait for 50 ms
    

    spi.frequency(SPI_FREQUENCY);
    spi.format(16,3);
    //slaveSelect = 1;
    slaveSelectLine = 1;

    state = STATE_OFF;
    entryState = true;
    exitState = false;
    switchOnSet = false;   
    isInitalized = false;

    masterFailSet = false;
    hardwareErrorSet = false;
    softwareErrorSet = false;
    sensorStatusErrorSet = false;

    statusRaw = 0;
    xRateRaw = 0;
    yRateRaw = 0;
    zRateRaw = 0;
    xAccelerationValueRaw = 0;
    yAccelerationValueRaw = 0;
    zAccelerationValueRaw = 0;
    unitTemperatureRaw = 0;


    xPositionActualValue = 0;
    yPositionActualValue = 0;
    zPositionActualValue = 0;

    xVelocityActualValue = 0;
    yVelocityActualValue = 0;
    zVelocityActualValue = 0;
    xVelocityLastValue = 0;
    yVelocityLastValue = 0;
    zVelocityLastValue = 0;

    xAccelerationActualValue = 0;
    yAccelerationActualValue = 0;
    zAccelerationActualValue = 0;
    xAccelerationLastValue = 0;
    yAccelerationLastValue = 0;
    zAccelerationLastValue = 0;

    xRateActualValue = 0; //in [rad/s]
    yRateActualValue = 0; //in [rad/s]
    zRateActualValue = 0; //in [rad/s]
    xRateLastValue = 0; //in [rad/s]
    yRateLastValue = 0; //in [rad/s]
    zRateLastValue = 0; //in [rad/s]

    rollRaw = 0;
    pitchRaw = 0;
    yawRaw = 0;
    roll = 0; //in rad
    pitch = 0; //in rad
    yaw = 0; //in rad

    rollOffset = 0;
    pitchOffset = 0;
    yawOffset = 0;

    stepWidthIntegrationTimer.reset();
    stepWidthIntegrationTimer.start();


    delayTimer.reset();
    delayTimer.start();
    resetIMU = 1; //Clear reset pin;
    while(delayTimer.read_ms() < 750); //wait for 750 ms for start up of IMU (data sheet of IMU: expecting 250 - 500 ms)

    if(debugSerial){
        debugSerial->write(name+" is initialized...");
    }
    timeOutTimer.start();

    thread.start(callback(this, &OpenIMU300ZI::run));
    ticker.attach(callback(this, &OpenIMU300ZI::sendThreadFlag), PERIOD);

}

OpenIMU300ZI::~OpenIMU300ZI() {
    ticker.detach();
}



/**
 * @brief Receiver::switchOn enables the device if it's switch off. On success function isOperational() returns true
 */
void OpenIMU300ZI::switchOn(){
    switchOnSet = true;
}

/**
 * @brief Receiver::switchOff disables the device if it's switch on. On success function isOperational() returns true
 */
void OpenIMU300ZI::switchOff(){
    switchOffSet = true;
}

/**
 * Get the currently active state as string
 * @return state as string
 */
string OpenIMU300ZI::getStateString(){
    switch(state){
            case STATE_OFF: return "STATE_OFF"; break;
            case STATE_INIT: return "STATE_INIT"; break;
            case STATE_OPERATIONAL: return "STATE_OPERATIONAL"; break;
            case STATE_FAULT: return "STATE_FAULT"; break;
            default: return "dont know state";
    }
    return "wrong state";
}

/**
 * @brief Receiver::isOperational Check if receiver is in operational condition
 * @return true if is in an operational condition, false if not
 */
bool OpenIMU300ZI::isOperational(){
    return (state == STATE_OPERATIONAL ? true: false);
}

/**
 * This function writes all current position values into the given references. The position could either be reset (by function resetAllValues) or set to a target value (by function forcePositionValues).
 * @param xPosition: A reference to a double variable into which we should write the current xPosition-Value. This value is updated by the IMU (from zero or from the set value, as mentioned above). The value is in [m]. If the unit is not operational the function returns zero.
 * @param yPosition: A reference to a double variable into which we should write the current yPosition-Value. This value is updated by the IMU (from zero or from the set value, as mentioned above). The value is in [m]. If the unit is not operational the function returns zero.
 * @param zPosition: A reference to a double variable into which we should write the current zPosition-Value. This value is updated by the IMU (from zero or from the set value, as mentioned above). The value is in [m]. If the unit is not operational the function returns zero.
 * @return true if unit is operational, false if not
 */
bool OpenIMU300ZI::getPositionValues(double &xPosition, double &yPosition, double &zPosition){
    if(isOperational()){
        xPosition = xPositionActualValue;
        yPosition = yPositionActualValue;
        zPosition = zPositionActualValue;
        return true;
    } else { 
        xPosition = 0;
        yPosition = 0;
        zPosition = 0;
        return false;
    }
}

/**
 * This function writes all current angular values into the given references. The values could either be reset (by function resetAllValues) or set to a target value (by function forceAngularValues).
 * @param roll: A reference to a double variable into which we should write the current xAngular value (rotation around X-Axis, in [rad]). This value is updated by the IMU (from zero or from the set value, as mentioned above). If the unit is not operational the function returns zero.
 * @param pitch: A reference to a double variable into which we should write the current yAngular value (rotation around Y-Axis, in [rad]). This value is updated by the IMU (from zero or from the set value, as mentioned above). If the unit is not operational the function returns zero.
 * @param yaw: A reference to a double variable into which we should write the current zAngular value (rotation around Z-Axis, in [rad]). This value is updated by the IMU (from zero or from the set value, as mentioned above). If the unit is not operational the function returns zero.
 * @return true if unit is operational, false if not
 */
bool OpenIMU300ZI::getEulerAngles(double &roll, double &pitch, double &yaw){
    if(isOperational()){
        roll = this->roll;
        pitch  = this->pitch;
        yaw = this->yaw;
        return true;
    } else { 
        roll = 0;
        pitch = 0;
        yaw = 0;
        return false;
    }
}

/**
 * This function writes all current velocity values into the given references. The position could either be reset (by function resetAllValues) or set to a target value (by function forceVelocityValues).
 * @param xPosition: A reference to a double variable into which we should write the current xVelocity-Value. This value is updated by the IMU (from zero or from the set value, as mentioned above). The value is in [m/s]. If the unit is not operational the function returns zero.
 * @param yPosition: A reference to a double variable into which we should write the current yVelocity-Value. This value is updated by the IMU (from zero or from the set value, as mentioned above). The value is in [m/s]. If the unit is not operational the function returns zero.
 * @param zPosition: A reference to a double variable into which we should write the current zVelocity-Value. This value is updated by the IMU (from zero or from the set value, as mentioned above). The value is in [m/s]. If the unit is not operational the function returns zero.
 * @return true if unit is operational, false if not
 */
bool OpenIMU300ZI::getVelocityValues(double &xVelocity, double &yVelocity, double &zVelocity){
    if(isOperational()){
        xVelocity = xVelocityActualValue;
        yVelocity = yVelocityActualValue;
        zVelocity = zVelocityActualValue;
        return true;
    } else { 
        xVelocity = 0;
        yVelocity = 0;
        zVelocity = 0;
        return false;
    }
}

/**
 * A simple function to return the yaw angle.
 * @return yaw in [rad] if device is operational, otherwise return 0
 */
double OpenIMU300ZI::getYaw(){
    if(isOperational()){
        return yaw;
    } else {
        return 0;
    }
}

/**
 * A simple function to return the roll angle.
 * @return roll in [rad] if device is operational, otherwise return 0
 */
double OpenIMU300ZI::getRoll(){
    if(isOperational()){
        return roll;
    } else {
        return 0;
    }
}

/**
 * A simple function to return the pitch angle.
 * @return pitch in [rad] if device is operational, otherwise return 0
 */
double OpenIMU300ZI::getPitch(){
    if(isOperational()){
        return pitch;
    } else {
        return 0;
    }
}

/**
 * This function writes all current angular velocity values into the given references. The values could either be reset (by function resetAllValues) or set to a target value (by function forceAngularVelocityValues).
 * @param xAngularRate: A reference to a double variable into which we should write the current xAngular value (rotation around X-Axis, in [rad/s]). This value is updated by the IMU (from zero or from the set value, as mentioned above). If the unit is not operational the function returns zero.
 * @param yAngularRate: A reference to a double variable into which we should write the current yAngular value (rotation around Y-Axis, in [rad/s]). This value is updated by the IMU (from zero or from the set value, as mentioned above). If the unit is not operational the function returns zero.
 * @param zAngularRate: A reference to a double variable into which we should write the current zAngular value (rotation around Z-Axis, in [rad/s]). This value is updated by the IMU (from zero or from the set value, as mentioned above). If the unit is not operational the function returns zero.
 * @return true if unit is operational, false if not
 */
bool OpenIMU300ZI::getAngularVelocityValues(double &xAngularRate, double &yAngularRate, double &zAngularRate){
        if(isOperational()){
        xAngularRate = xRateActualValue;
        yAngularRate = yRateActualValue;
        zAngularRate = zRateActualValue;
        return true;
    } else { 
        xAngularRate = 0;
        yAngularRate = 0;
        zAngularRate = 0;
        return false;
    }
}

/**
 * A simple function to return the angular speed about X.
 * @return angular speed in [rad/s] if device is operational, otherwise return 0
 */
double OpenIMU300ZI::getAngularVelocityX(){
    if(isOperational()){
        return xRateActualValue;
    } else {
        return 0;
    }
}

/**
 * A simple function to return the angular speed about Y.
 * @return angular speed in [rad/s] if device is operational, otherwise return 0
 */
double OpenIMU300ZI::getAngularVelocityY(){
    if(isOperational()){
        return yRateActualValue;
    } else {
        return 0;
    }
}

/**
 * A simple function to return the angular speed about Z.
 * @return angular speed in [rad/s] if device is operational, otherwise return 0
 */
double OpenIMU300ZI::getAngularVelocityZ(){
    if(isOperational()){
        return zRateActualValue;
    } else {
        return 0;
    }
}

/**
 * A simple function to return the acceleration on X.
 * @return acceleration in [m/s²] if device is operational, otherwise return 0
 */
double OpenIMU300ZI::getAccelerationX(){
    if(isOperational()){
        return xAccelerationActualValue;
    } else {
        return 0;
    }
}

/**
 * A simple function to return the acceleration on Y.
 * @return acceleration in [m/s²] if device is operational, otherwise return 0
 */
double OpenIMU300ZI::getAccelerationY(){
    if(isOperational()){
        return yAccelerationActualValue;
    } else {
        return 0;
    }
}

/**
 * A simple function to return the acceleration on Z.
 * @return acceleration in [m/s²] if device is operational, otherwise return 0
 */
double OpenIMU300ZI::getAccelerationZ(){
    if(isOperational()){
        return zAccelerationActualValue;
    } else {
        return 0;
    }
}

/**
 * This function writes a given position into the actual values. This could be used as a correction function for example
 * @param xPosition: Value for the actual position in x-Direction, in [m]
 * @param yPosition: Value for the actual position in y-Direction, in [m]
 * @param zPosition: Value for the actual position in z-Direction, in [m]
 * @return true if unit is operational, false if not
 */
bool OpenIMU300ZI::forcePositionValues(double xPosition, double yPosition, double zPosition){
    xPositionActualValue = xPosition;
    yPositionActualValue = yPosition;
    zPositionActualValue = zPosition;
    return isOperational();
}

/**
 * This function writes a given velocity into the actual values. This could be used as a correction function for example
 * @param xVelocity: Value for the actual velocity in x-Direction, in [m/s]
 * @param yVelocity: Value for the actual velocity in y-Direction, in [m/s]
 * @param zVelocity: Value for the actual velocity in z-Direction, in [m/s]
 * @return true if unit is operational, false if not
 */
bool OpenIMU300ZI::forceVelocityValues(double xVelocity, double yVelocity, double zVelocity){
    xVelocityActualValue = xVelocity;
    yVelocityActualValue = yVelocity;
    zVelocityActualValue = zVelocity;
    return isOperational();
}      

/**
 * This function resets the current angular values of roll pitch and yaw to zero
 */
void OpenIMU300ZI::resetEuler(){
    rollOffset = (-1) * rollRaw * 2*3.141592634 / 65536.0;
    pitchOffset = (-1) * pitchRaw * 2*3.141592634 / 65536.0;
    yawOffset = (-1) * yawRaw * 2*3.141592634 / 65536.0;
}

/**
 * This function resets only the yaw-angle of the device. Since we're almost turning around this angle this is the most important one. More over 
 * we try to avoid reseting the roll and pitch, sind this corresponds to the gravity and are correct by the imu itselfe.
 */
void OpenIMU300ZI::resetYaw(){
    yawOffset = (-1) * yawRaw * 2*3.141592634 / 65536.0;
}

/**
 * integrates between two values. Using the trapezodial methode
 * @param lastValue The last known value  [unit/s] or [unit/s^2]
 * @param actualValue The current value in [unit/s] or [unit/s^2]
 * @param stepWdith for the integartion, in [s]
 * @return the area (trapezodial described with this two points). Return value is in [unit] or in [unit/s] depends on input
 */
double OpenIMU300ZI::integrateTrapezoidal(double lastValue, double actualValue, double stepWidth){
    return 0.5 * stepWidth * (lastValue + actualValue) ; //Here the expection would be:  0.5 * stepWidth * (lastValue + actualValue) but I didn't found the reaseon why we mustn't mulitply by 0.5
}


/**
 * Sets the unit to a target orientation. This means rotating the axis of the system. Only defined values are possible
 */
void OpenIMU300ZI::setUnitOrientation( UnitOrientation targetOrientation ){
    uint8_t msbTarget = targetOrientation>>8;
    uint8_t lsbTarget = targetOrientation & 0xFF;
    writeDataToRegister(RegisterMap::UNIT_ORIENTATION_MSB, msbTarget);
    writeDataToRegister(RegisterMap::UNIT_ORIENTATION_MSB, lsbTarget);
}


/**
 * Read target value from a register of the IMU
 * @return The register value (if there is a valid one)
 */
int16_t  OpenIMU300ZI::readDataFromRegister (RegisterMap targetRegister){
    slaveSelectLine = 0;
    spi.write(targetRegister<<8);
    int16_t response = spi.write(0x00);
    slaveSelectLine = 1;

    if(response != 0){
        //If we received ANY answer, we'll reset the watchdog timer
        watchDogDataReceived.reset();
    }

    return response;
}

/**
 * This function reads all values from the IMU, which are triggerd by the common register 0x3e (see documentation <a href="https://openimu.readthedocs.io/en/latest/software/SPImessaging.html">here</a> for more details)
 * @warning This function modifies the membervariables of the object
 */
void OpenIMU300ZI::burstRead(){
    slaveSelectLine = 0;
    spi.write(RegisterMap::BURST_READ<<8);
    statusRaw = spi.write(0x00);
    xRateRaw = spi.write(0x00);
    yRateRaw = spi.write(0x00);
    zRateRaw = spi.write(0x00);
    xAccelerationValueRaw = spi.write(0x00);
    yAccelerationValueRaw = spi.write(0x00);
    zAccelerationValueRaw = spi.write(0x00);
    unitTemperatureRaw = spi.write(0x00);

    rollRaw = spi.write(0x00);
    pitchRaw = spi.write(0x00);
    yawRaw = spi.write(0x00);
    
    int16_t checkForValidResponse = 0;
    checkForValidResponse |= statusRaw;
    checkForValidResponse |= xRateRaw;
    checkForValidResponse |= yRateRaw;
    checkForValidResponse |= zRateRaw;
    checkForValidResponse |= xAccelerationValueRaw;
    checkForValidResponse |= yAccelerationValueRaw;
    checkForValidResponse |= zAccelerationValueRaw;
    checkForValidResponse |= unitTemperatureRaw;

    if(checkForValidResponse != 0){
        watchDogDataReceived.reset();
    } else{
        //Do nothing. It seems as the response is note valid. No one of the results is not equals to zero. So we 
        //don't reset the watchdog timer. If this will happen to many times in a serie, we'll change the state to 
        //state fault.
    }
    slaveSelectLine = 1;

}


/**
 * Writes a given value into a target register
 * @targetRegister Address of Register to write at
 * @valueToWrite Target value for this register
 */
void OpenIMU300ZI::writeDataToRegister (RegisterMap targetRegister, uint8_t valueToWrite){
    //A write operation on the OpenIMU device is indicated by a register value with the MSB = 1, so lets set to 1
    slaveSelectLine = 0;

    Timer delayTimer;
    delayTimer.reset();
    delayTimer.start();
    while(delayTimer.read_us() < 10); //wait for a short time until slave select is zero for sure

    uint16_t valueToSend = (targetRegister<<8) | 0x80;
    valueToSend |= valueToWrite;
    spi.write(valueToSend);
    slaveSelectLine = 1;

    //Give the IMU a bit of time to apply command
    delayTimer.reset();
    delayTimer.start();
    while(delayTimer.read_us() < 50); //wait for 50 us
}

/**
 * Resets all the values (acceleartion, velocity and position to zero). Calculating the way starts from zero again
 */
void OpenIMU300ZI::resetAllValues(){

    xPositionActualValue = 0;
    yPositionActualValue = 0;
    zPositionActualValue = 0;

    xVelocityActualValue = 0;
    yVelocityActualValue = 0;
    zVelocityActualValue = 0;

    xVelocityLastValue = 0;
    yVelocityLastValue = 0;
    zVelocityLastValue = 0;

    xAccelerationLastValue = 0;
    yAccelerationLastValue = 0;
    zAccelerationLastValue = 0;
    
    xAccelerationActualValue = 0;
    yAccelerationActualValue = 0;
    zAccelerationActualValue = 0;

    resetEuler();

}

/**
 * This method is called by the ticker timer interrupt service routine.
 * It sends a flag to the thread to make it run again.
 */
void OpenIMU300ZI::sendThreadFlag() {
    
    thread.flags_set(threadFlag);
}


/**
 * The Callback function for the thread.
 */
void OpenIMU300ZI::run(){

    while(true){

        // wait for the periodic thread flag
        ThisThread::flags_wait_any(threadFlag);

        switch(state){
            case STATE_OFF:

                if(entryState){
                    entryState = false;
                    switchOnSet = false;
                    watchDogDataReceived.stop();
                    watchDogDataReceived.reset();
                }

                /*Criteria to leave state */
                if(switchOnSet){
                    state = STATE_INIT;
                    exitState = true;
                    switchOnSet = false;
                
                } else {
                    //Periodical part
                }
                

                if(exitState){
                    entryState = true;
                    //spi.select();
                }
            break;

            case STATE_INIT:
                if(entryState){
                    isInitalized = false;
                    writeDataToRegister(RegisterMap::ACCEL_LOW_PASS_FILTER, FilterOptions::UNFILTERED);
                    writeDataToRegister(RegisterMap::RATE__LOW_PASS_FILTER, FilterOptions::UNFILTERED);
                    setUnitOrientation(UnitOrientation::MODE_NORMAL);
                    isInitalized = true;
                    entryState = false;
                } 

                /*Criteria to leave state */
                if(isInitalized){
                    state = STATE_OPERATIONAL;
                    exitState = true;
                    isInitalized = false;

                } else if( switchOffSet) {
                    state = STATE_OFF;
                    exitState = true;
                    
                } else {
                    //Do nothing but wait
                }

                if(exitState){
                    entryState = true;
                    watchDogDataReceived.start();
                    stepWidthIntegrationTimer.reset();
                    stepWidthIntegrationTimer.stop();
                }
                break;

            case STATE_OPERATIONAL:
                if(entryState){
                    entryState = false;
                    stepWidthIntegrationTimer.reset();
                    stepWidthIntegrationTimer.start();
                    switchOffSet = false;
                }

                if(switchOffSet){
                    state = STATE_OFF;
                    exitState = true;

                } else { //Periodical part, 
                    burstRead();
                    masterFailSet = ( (statusRaw & BitMasksMasterStatus::MASTER_FAIL) != 0 ? true: false);
                    hardwareErrorSet = ( (statusRaw & BitMasksMasterStatus::HARDWARE_ERROR) != 0 ? true: false);
                    softwareErrorSet = ( (statusRaw & BitMasksMasterStatus::SOFTWARE_ERROR) != 0 ? true: false);
                    sensorStatusErrorSet = ( (statusRaw & BitMasksMasterStatus::SOFTWARE_ERROR) != 0 ? true: false);
                }

                //Change to state fault imediately (in the next cycle), if a fault is signalized by the received status
                if(hardwareErrorSet){
                    exitState = true;
                    state = STATE_FAULT;
                    if(debugSerial){
                        debugSerial->write("Hardware error on IMU detected, at "+to_string(debugTimer.read_ms())+"ms." );
                    }

                } else if(softwareErrorSet){
                    exitState = true;
                    state = STATE_FAULT;
                    if(debugSerial){
                        debugSerial->write("Software error on IMU detected, at "+to_string(debugTimer.read_ms())+" ms." );
                    }

                } else if(sensorStatusErrorSet){
                    exitState = true;
                    state = STATE_FAULT;
                    if(debugSerial){
                        debugSerial->write("Sensor status error on IMU detected, at "+to_string(debugTimer.read_ms()) + " ms.");
                    }

                } else if(masterFailSet){
                    exitState = true;
                    state = STATE_FAULT;
                    if(debugSerial){
                        debugSerial->write("Master fail on IMU detected, at "+to_string(debugTimer.read_ms()) + " ms.");
                    }

                } else { //We found no error in the received data, so lets calculate all the stuff
                    double h = 1.0 * stepWidthIntegrationTimer.read_us()/1000000;
                    stepWidthIntegrationTimer.reset();

                    //Make correct alignement of axis, since IMU orientation does not work on OpenIMU Firmware

                    xAccelerationLastValue = xAccelerationActualValue;
                    yAccelerationLastValue = yAccelerationActualValue;
                    zAccelerationLastValue = zAccelerationActualValue;

                    xAccelerationActualValue = (-9.81)*xAccelerationValueRaw/4000.0;
                    yAccelerationActualValue = 9.81*yAccelerationValueRaw/4000.0;
                    zAccelerationActualValue = 9.81*zAccelerationValueRaw/4000.0;

                    xVelocityLastValue = xVelocityActualValue;
                    yVelocityLastValue = yVelocityActualValue;
                    zVelocityLastValue = zVelocityActualValue;
            
                    xVelocityActualValue = integrateTrapezoidal(xAccelerationLastValue, xAccelerationActualValue, h) + xVelocityLastValue;
                    yVelocityActualValue = integrateTrapezoidal(yAccelerationLastValue, yAccelerationActualValue, h) + yVelocityLastValue;
                    zVelocityActualValue = integrateTrapezoidal(zAccelerationLastValue, zAccelerationActualValue, h) + zVelocityLastValue;

                    xPositionActualValue = xPositionActualValue + integrateTrapezoidal(xVelocityLastValue, xVelocityActualValue, h);
                    yPositionActualValue = yPositionActualValue + integrateTrapezoidal(yVelocityLastValue, yVelocityActualValue, h);
                    zPositionActualValue = zPositionActualValue + integrateTrapezoidal(zVelocityLastValue, zVelocityActualValue, h);

                    xRateLastValue = xRateActualValue;
                    yRateLastValue = yRateActualValue;
                    zRateLastValue = zRateActualValue;

                    xRateActualValue = 1.0*xRateRaw / 64 * DEG_TO_RAD; //64 LSB/ DEG
                    yRateActualValue = 1.0*yRateRaw / 64 * DEG_TO_RAD;
                    zRateActualValue = 1.0*zRateRaw /64 * DEG_TO_RAD;
                    
                    roll = rollRaw * 2*3.141592634 / 65536.0 + rollOffset;
                    pitch = pitchRaw * (-2.0 )*3.141592634 / 65536.0 + pitchOffset + CONST_2_PI;
                    yaw = yawRaw * (-2.0) *3.141592634 / 65536.0 + yawOffset + CONST_2_PI;
                    
                   // debugSerial->write("zRaw: "+to_string(zAccelerationValueRaw) + "  roll: "+to_string(roll*RAD_TO_DEG)+ "  pitch: "+to_string(pitch*RAD_TO_DEG)+ "  yaw: "+to_string(yaw*RAD_TO_DEG));

                } 

                if(exitState){
                    masterFailSet = false;
                    hardwareErrorSet = false;
                    softwareErrorSet = false;
                    sensorStatusErrorSet = false;
                    entryState = true;
                    watchDogDataReceived.reset();
                    watchDogDataReceived.stop();
                }
            break;

            case STATE_FAULT:
                if(entryState){
                    entryState = false;
                    switchOnSet = false;
                    watchDogDataReceived.stop();
                    watchDogDataReceived.reset();
                    if(debugSerial){
                        debugSerial->write(name+" entered state Fault. after "+to_string(debugTimer.read_ms()) + " ms.");
                    }
                }


                /*Criteria to leave state */
                if(switchOnSet){
                    state = STATE_INIT;
                    exitState = true;
                
                } else {
                    //Periodical part
                }

                if(exitState){
                    entryState = true;
                }
            break;            

            default:
                if(debugSerial){ //debugSerial is not null
                    debugSerial->write("Something went wrong, we're in default state in "+name+ " after "+to_string(debugTimer.read_ms()) + " ms.");
                } 
                watchDogDataReceived.stop();
                watchDogDataReceived.reset();           
                state = STATE_FAULT; //for savety reasons we're do as we're currently expecting data and don't received any
                entryState = true;
                break;
        }



        if(watchDogDataReceived.read_ms() >= UPDATE_CYCLE_DATA*10){ //If we didn't received any data for more than 10 periodes lets go to fault state
            state = STATE_FAULT;
            entryState = true;
            if(debugSerial){ //debugSerial is not null
                debugSerial->write(name+": Watchdog connection lost triggerd...");
            } 
        }
        exitState = false;

    }
}