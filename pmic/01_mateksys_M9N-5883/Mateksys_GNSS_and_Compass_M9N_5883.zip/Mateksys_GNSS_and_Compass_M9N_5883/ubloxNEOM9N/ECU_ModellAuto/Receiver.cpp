/*
 * Receiver.cpp
 * Copyright (c) 2018, ZHAW
 * All rights reserved.
 *
*/

#include "Receiver.h"
#include <cstdint>
#define TRACE if(debugSerial) debugSerial->printf("Trace %s, Time: %d ms, Line: %d\r\n",name.c_str(), debugTimer.read_ms(),__LINE__);


using namespace std;

/**
 * Creates and initializes the driver to read a Graupner RC-Receiver. The Receiver provides an interface to read each channel. After instantiate the object, it has to be switched on 
 * (by using function switchOn()).
 * @param Tx The Tx Pin, which is not used and not connected.  
 * @param Rx The Rx Pin to the SUMD signal of the Graupner Receiver (eg. GR16)
 * @param led whenever we read a new serial packet, this led toggles. Means it helps to check if the system is still working
 * @param name name of this instance
 * @param debugSerial Interface to plot the debug messages
 */
Receiver::Receiver(PinName Tx, PinName Rx, string name, PinName led, Serial * debugSerial):
    Thread(osPriorityHigh, OS_STACK_SIZE*2, NULL,  name.c_str()),
    receiverSerialConnection(Tx, Rx, BAUD_RATE_GRAUPNER_SUMD_PROTOCOLL),
    interpreter(GRAUPNER_ID),
    receivingLED(led), 
    debugLed(LED2){

    this->name = name;
    this->debugSerial = debugSerial;    

    receivedValuesInUse = false;
    newDataAvailable = false;
    state = STATE_OFF;
    switchOnSet = false;
    switchOffSet = false;
    entryState = true;
    attemptFailed = 0;
    lastAttemptFailed = false;
    dataIsValid = false;
    failSafeModeActive = false;
    doesntHitStartByte = false;
    lengthOfSerialStream = 2*NUMBER_OF_CHANNELS + LENGTH_OF_HEADER + LENGTH_OF_CRC;  
    timeOutTimer.start();
    isFailSafeTimer.reset();
    isFailSafeTimer.stop();

    debugTimer.start();

    buffer  = new (uint8_t[lengthOfSerialStream]);
    message  = new (uint8_t[lengthOfSerialStream]);

    if(debugSerial){
            debugSerial->printf("%s initialized for %d bytes... \r\n", name.c_str(), lengthOfSerialStream);
    }

    thread.start(callback(this, &Receiver::run));
    ticker.attach(callback(this, &Receiver::sendThreadFlag), PERIOD);

}

Receiver::~Receiver() {
    ticker.detach();
}

/**
 * @brief Receiver::switchOn enables the device if it's switch of. On success function isOperational() returns true
 */
void Receiver::switchOn(){
    switchOnSet = true;
}

/**
 * @brief Receiver::switchOff disable the device if it's switch of.
 */
void Receiver::switchOff(){
    switchOffSet = true;

    // added by jonas
    state = STATE_OFF;
    entryState = true;
    exitState = false;
}


/**
 * This function checks if the receiver is in the fail save mode. This would happen if the connection to the remote controll is lost
 * @return true if in fails safe mode, false if not. There is a delay some time. This avoids enteryng STATE_FAULT in case only one transmission was bad
 * at the momement 5 periodes (50 ms) are acepted
 */
bool Receiver::isFailSafe(){
    if(interpreter.IsFailsafe()) {
        //Do nothing
    } else {
        isFailSafeTimer.reset();
        isFailSafeTimer.start();
    }
    return ( isFailSafeTimer.read_ms() > 5 * PERIODE_OF_SIGNAL ? true : false) ; 
}

/**
 * @brief Receiver::isOperational Check if receiver is in operational condition
 * @return true if is in an operational condition, false if not
 */
bool Receiver::isOperational(){
    return (state==STATE_PROCESSING_DATA) || (state == STATE_WAITING_FOR_DATA);
}

/**
 * @brief Receiver::startByteStream Callback function for a complete serial stream. This function copies the buffer to a new array. If we're currently handling the last data,
 * we sleep additional half of the periode of the singla in the next run periode. So we can avoid calling the ISR everytime simultanious to the threads run function
 * @warning This is an ISR, means you should not do long callculations here
 * @param empty Unused parameter to be compliant with the calling routine of the Serial::read(...) function
 */
void Receiver::byteStreamComplete(int empty){
    watchDogDataReceived.reset();
    receivingLED.write(!receivingLED);
    /* Check if ringbuffer will be full within this periode */
    // Ok if we don't do anything it will be full within this cycle, so lets keep the most recent cyle and clear the rest
    newDataAvailable = true;
}
    
void Receiver::rxStreamRequested(){
    receiverSerialConnection.abort_read();
    LowPowerTimer delayTimer;
    delayTimer.reset();
    delayTimer.start();
    while(delayTimer.read_us()<11); //Receiveng the startbit tooks 8.68 us. so with 13 us we'll land in the middle of the byte. As tests have shown 11 us is good value
    receiverSerialConnection.read(buffer, lengthOfSerialStream, callback(this, &Receiver::byteStreamComplete), SERIAL_EVENT_RX_COMPLETE);
}

/**
 * @brief Receiver::getLatestData get the latest read data. 
 * @param buf Buffer as target, must be at least as long as data. is filled with "-empty-" if buffer never was filled before. Otherwise contains last valid value
 * @return true if current value is valid (less than MAX_NUMBER_OF_FAILED_TRANSMISSONS old), otherwise false. Note even if it's not valid, the buffer is filled with the last valid value
 */
// bool Receiver::getLatestData(char *buf){
//     memcpy(message, debugBuffer, lengthOfSerialStream);
//     return dataIsValid;
// }




/**
 * @brief Receiver::getChannelValue returns the raw channel value for the servo 
 * @return Value of the servo in: [0x1C20, 0x41A0] for the values in [-150%, 150%]. returns zero in case of data is not valid or if selected channel does not exist
 */
float Receiver::getChannelValue(uint8_t channel){
    if(!dataIsValid){
        // return 0x2EE0; //This is the neutral position of the servo
        return 0.0;
    } else {}

    if(channel < NUMBER_OF_CHANNELS){
        return normalizeValue(channelData[channel]);
    } else {
        return 0.0;
    }
}

float Receiver::normalizeValue(uint16_t data) {

    float valueToNorm = static_cast<float>(data);

    return (valueToNorm - MIN_GRAUPNER_VALUE)/(MAX_GRAUPNER_VALUE - MIN_GRAUPNER_VALUE)*2.0 - 1.0;
}

int Receiver::getState() {
    return state;
}

/**
 * This method is called by the ticker timer interrupt service routine.
 * It sends a flag to the thread to make it run again.
 */
void Receiver::sendThreadFlag() {
    
    thread.flags_set(threadFlag);
}

/**
 * The Callback function for the thread.
 */
void Receiver::run(){

    
    while(true){

        // wait for the periodic thread flag
        ThisThread::flags_wait_any(threadFlag);

        switch(state){
            case STATE_OFF: 
                if(entryState){
                    entryState = false;
                    switchOnSet = false;
                    dataIsValid = false;
                    switchOffSet = false;   
                    timeOutTimer.reset();
                    timeOutTimer.stop(); 
                    isFailSafeTimer.reset();
                    isFailSafeTimer.stop();
                    //TRACE
                }

                /*Criteria to leave state */
                if(switchOnSet){
                    state = STATE_WAITING_FOR_DATA;
                    exitState = true;
                    switchOnSet = false;
                
                } else {
                    //Periodical part
                }
                

                if(exitState){
                    entryState = true;
                    isFailSafeTimer.start();
                }
            break;

            case STATE_WAITING_FOR_DATA:
                if(entryState){
                    //Make sure no read process is ongoing
                    receiverSerialConnection.abort_read();
                    entryState = false;
                    switchOffSet = false;
                    lastAttemptFailed = false;
                    newDataAvailable = false;
                    doesntHitStartByte = false;
                    receiverSerialConnection.attach(callback(this, &Receiver::rxStreamRequested));
                    timeOutTimer.reset();
                } 

                /*Criteria to leave state */

                if(newDataAvailable){
                    //Modifying a vector in the isr is not possible, so lets do it here
                    for(int16_t count = 0; count < lengthOfSerialStream; count++){
                        multiMessageBuffer.push_back(buffer[count]);
                    }   

                    if(multiMessageBuffer.size() >= 2*lengthOfSerialStream){
                        /*Just process data if we have at least two messages in que, to avoid a broken message */
                        state = STATE_PROCESSING_DATA;
                        exitState = true;

                    } else {
                        entryState = true;
                    }

                } else if(lastAttemptFailed && (attemptFailed >= MAX_NUMBER_OF_FAILED_TRANSMISSONS) ) {
                    exitState = true;
                    state = STATE_FAULT;
                    //TRACE

                } else if(lastAttemptFailed){
                    entryState = true; //Reenter the state to restart the read process
                    //TRACE

                } else if(timeOutTimer.read_ms() > 2*PERIODE_OF_SIGNAL){
                    //TRACE
                    //Something went wrong, we didn't catch an interrupt, lets try again.
                    entryState = true;

                } else if(switchOffSet){
                    switchOffSet = false;
                    exitState = true;
                    receiverSerialConnection.abort_read();
                    state = STATE_OFF;
                    timeOutTimer.reset();
                    timeOutTimer.stop();

                } else {
                    //Periodical part
                }

                if(exitState){
                    entryState = true;
                    //TRACE
                }
                break;

            case STATE_PROCESSING_DATA:{
                bool parsedSuccesfully = false;
                if(entryState){
                    entryState = false;
                    parsedSuccesfully = true;
                    dataIsValid = true;
                    watchDogDataReceived.reset();
                    watchDogDataReceived.start();

                    uint16_t beginnOfMessage = 0;
                    bool    validFrameFound = false;
                    for(uint16_t count = 0; count < multiMessageBuffer.size()-1; count ++){
                        if ( (multiMessageBuffer[count] == GRAUPNER_ID) && ((multiMessageBuffer[count+1] == FRAME_IS_VALID))){
                            beginnOfMessage = count;
                            validFrameFound = true;
                            break;
                           
                        } else if ( (multiMessageBuffer[count] == GRAUPNER_ID) && ((multiMessageBuffer[count+1] == IS_FAIL_SAVE_MODE))){
                            beginnOfMessage = count;
                            validFrameFound = true;
                            break;
                        } else{} //Do nothign validFrameFound is allready false
                    }



                    uint8_t message[lengthOfSerialStream];
                    if(validFrameFound){
                        for(uint16_t count = beginnOfMessage; count < beginnOfMessage + lengthOfSerialStream; count++){
                            if(count >= multiMessageBuffer.size()){
                                validFrameFound = false;

                            } else{
                                message[count-beginnOfMessage] = multiMessageBuffer[count];
                            }
                        }
                    }
                    
                    if(switchOffSet){
                        //In case we've planned to switch off, do nothing

                    //Check if we still have a valid frame
                    } else if(validFrameFound) {
                        multiMessageBuffer.erase(multiMessageBuffer.begin(), multiMessageBuffer.begin() + beginnOfMessage + lengthOfSerialStream);
                        multiMessageBuffer.shrink_to_fit();

                        //Clear the whole vector if we're too much in the delay
                        if(multiMessageBuffer.size() >= 5*lengthOfSerialStream){
                            multiMessageBuffer.clear();
                            multiMessageBuffer.shrink_to_fit();
                        } else{}

                        for(uint32_t count = 0; count < lengthOfSerialStream; count ++){
                            interpreter.digestValue(message[count]);
                        }
   
                        
                        if(interpreter.HasNewValues()){
                            debugLed = 1;
                            parsedSuccesfully =  true;
                        } else {
                            debugLed = 0 ;
                            parsedSuccesfully =  false;
                            if(debugSerial)debugSerial->printf("Receiver got a non valid signal after %d ms \r\n", debugTimer.read_ms());
                        }
                  

                    } else {
                        TRACE
                        parsedSuccesfully = false;
                        debugLed = 0;
                    }
                }

                if(switchOffSet) {                
                    switchOffSet = false;
                    exitState = true;
                    receiverSerialConnection.abort_read();
                    state = STATE_OFF;
                    timeOutTimer.reset();
                    timeOutTimer.stop();     
                    multiMessageBuffer.clear();
                    multiMessageBuffer.shrink_to_fit();
                    
                } else if(parsedSuccesfully && !interpreter.IsFailsafe()){
                    for(uint16_t count = 0; count < NUMBER_OF_CHANNELS; count++){
                        //Copy data
                        channelData[count] = interpreter.GetChannelValue(count);
                    }
                    state = STATE_WAITING_FOR_DATA;
                    exitState = true;
                    attemptFailed = 0;

                } else if(parsedSuccesfully){
                    //Do everything similar, but keep the last values
                    state = STATE_WAITING_FOR_DATA;
                    exitState = true;
                    attemptFailed = 0;

                } else if(attemptFailed >= MAX_NUMBER_OF_FAILED_TRANSMISSONS){
                    exitState = true;
                    state = STATE_FAULT;
                
                } else {
                    attemptFailed++;
                    state = STATE_WAITING_FOR_DATA;
                    exitState = true;
                }

                if(exitState){
                    entryState = true;
                }
            } break;

            case STATE_FAULT:
                if(entryState){
                    entryState = false;
                    switchOnSet = false;
                    dataIsValid = false;
                    watchDogDataReceived.stop();
                    watchDogDataReceived.reset();
                    isFailSafeTimer.reset();
                    isFailSafeTimer.stop();
                    if(debugSerial){
                        debugSerial->printf("%s entered state Fault. after %d ms\r\n",name.c_str(),debugTimer.read_ms());
                    }
                }


                /*Criteria to leave state */
                if(switchOnSet){
                    state = STATE_WAITING_FOR_DATA;
                    exitState = true;
                    TRACE
                    attemptFailed = 0;
                
                } else {
                    //Periodical part
                }

                if(exitState){
                    entryState = true;
                }
            break;            

            default:
                if(debugSerial){ //debugSerial is not null
                    debugSerial->printf("Something went wrong, we're in default state in %s after %d ms\r\n", name.c_str(), debugTimer.read_ms());
                } 
                watchDogDataReceived.stop();
                watchDogDataReceived.reset();   
                isFailSafeTimer.reset();
                isFailSafeTimer.stop();        
                state = STATE_FAULT; //for savety reasons we're do as we're currently expecting data and don't received any
                entryState = true;
                break;
        }



        if(watchDogDataReceived.read_ms() >= MAX_TIME_NO_NEW_DATA_RECEIVED){
            state = STATE_FAULT;
            entryState = true;
            if(debugSerial){ //debugSerial is not null
                debugSerial->printf("%s: Watchdog connection lost triggerd...\r\n", name.c_str());
            } 
        }
        exitState = false;
    }
}