#include "PX4Flow.h"

PX4Flow::PX4Flow( I2C& i2c): i2c(i2c)
{
    i2c_commands = INTEGRAL_FRAME;
    
    iframe.avg_flow_x        = 0;
    iframe.avg_flow_y        = 0;
    iframe.avg_qual          = 0;
    iframe.valid_frame_count = 0;
    iframe.frame_count       = 0;

}

PX4Flow::~PX4Flow() {}

bool PX4Flow::update_integral()
{  
    // send 0x16 to PX4FLOW module and receive back 7 Bytes data
    int b1 = i2c.write(PX4FLOW_ADDRESS, &i2c_commands, 1);
    if( b1 == 0 ) {
        // dout1.write(1);
        b1 = i2c.read(PX4FLOW_ADDRESS, bufferI, 7);
        // dout1.write(0);
        if(b1 == 0 ) {
            // assign the data
            iframe.avg_flow_x        = (int16_t)(read16(bufferI, AVG_FLOW_X       ));
            iframe.avg_flow_y        = (int16_t)(read16(bufferI, AVG_FLOW_Y       ));
            iframe.avg_qual          = (uint8_t)( read8(bufferI, AVG_QUAL         ));
            iframe.valid_frame_count = (uint8_t)( read8(bufferI, VALID_FRAME_COUNT));
            iframe.frame_count       = (uint8_t)( read8(bufferI, FRAME_COUNT_     ));
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

float PX4Flow::avg_flow_x()
{
    return (float)iframe.avg_flow_x*0.3333333f;
}
    
float PX4Flow::avg_flow_y()
{
    return (float)iframe.avg_flow_y*0.3333333f;
}

uint8_t PX4Flow::avg_qual()
{
    return iframe.avg_qual;
}

uint8_t PX4Flow::valid_frame_count()
{
    return iframe.valid_frame_count;
}
    
uint8_t PX4Flow::frame_count()
{
    return iframe.frame_count;
}
    
uint8_t PX4Flow::avg_qual_scaled(){
    
    uint8_t avg_qual_scaled = 0;
    if(iframe.frame_count > 0) {
        avg_qual_scaled = (uint8_t)( (float)iframe.avg_qual * ( (float)iframe.valid_frame_count / (float)iframe.frame_count ) );
    }        
    return avg_qual_scaled;
}

uint8_t PX4Flow::read8(char *buffer, const unsigned int& idx)
{
    return uint8_t( buffer[idx] );
}

uint16_t PX4Flow::read16(char *buffer, const unsigned int& idx)
{
    return uint16_t( read8( buffer, idx ) | (read8(buffer, idx + 1 ) << 8 ) );
}

uint32_t PX4Flow::read32(char *buffer, const unsigned int& idx)
{
    return uint32_t( (buffer[idx] << 0) | (buffer[idx + 1] << 8) | (buffer[idx+2] << 16) | (buffer[idx+3] << 24) );
}

