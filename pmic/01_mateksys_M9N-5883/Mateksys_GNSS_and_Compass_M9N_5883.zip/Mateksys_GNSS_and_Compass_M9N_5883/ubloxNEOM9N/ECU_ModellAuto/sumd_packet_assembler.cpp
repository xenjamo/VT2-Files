// A packet assembler that un-marshals a Graupner SUMD packet.

#include "sumd_packet_assembler.h"

#include <string.h>

#define STATUS_OFFSET 0
#define CHANNEL_COUNT_OFFSET 1
#define CHANNEL_DATA_START_OFFSET 2
#define MIN_CHANNELS 2
#define CRC_POLYNOME 0x1021

SumdUnmarshaler::SumdUnmarshaler(uint8_t vendor_id)
    : vendor_id_(vendor_id),
      state_(STATE_READ_VENDOR_ID),
      index_(0),
      byte_count_(0),
      crc_(0),
      crc_start_offset_(0),
      has_new_values_(false),
      is_fail_safe_(true),
      channel_count_(0) {
  memset(channel_values_, 0, sizeof(channel_values_));
  SetState(STATE_READ_VENDOR_ID, /* value = */ 0);
}

void SumdUnmarshaler::digestValue(uint8_t value) {
  switch (state_) {
    case STATE_READ_VENDOR_ID:
      if (value == vendor_id_) {
        SetState(STATE_READ_HEADER, value);
        Crc(value);
      }
      break;
    case STATE_READ_HEADER:
      switch (index_) {
        case STATUS_OFFSET:
          if (value & 0x01) {  // Test whether OK bit is set.
            AddValue(value);
          } else {
            SetState(STATE_READ_VENDOR_ID, value);
          }
          break;
        case CHANNEL_COUNT_OFFSET:
          if (value >= MIN_CHANNELS && value <= MAX_CHANNELS) {
            AddValue(value);
            SetState(STATE_READ_VALUES, value);
          } else {
            SetState(STATE_READ_VENDOR_ID, value);
          }
          break;
        default:
          SetState(STATE_READ_VENDOR_ID, value);
      }
      break;
    case STATE_READ_VALUES:
      if (byte_count_ > 0) {
        AddValue(value);
        --byte_count_;
      }
      if (byte_count_ == 0) {
        SetState(STATE_READ_CRC, value);
      }
      break;
    case STATE_READ_CRC:
      if (byte_count_ > 0) {
        AddValue(value);
        --byte_count_;
      }
      if (byte_count_ == 0) {
        if (CheckCrc()) {
          CopyChannelValues();
        }
        SetState(STATE_READ_VENDOR_ID, value);
      }
      break;
  }
}


/**
 * Returns true in case of fail (eg. connection lost)
 */
bool SumdUnmarshaler::IsFailsafe() const {
  return is_fail_safe_;
}

bool SumdUnmarshaler::HasNewValues() {
  bool ret_value_ = has_new_values_;
  has_new_values_ = false;
  return ret_value_;
}

uint8_t SumdUnmarshaler::GetChannelCount() const {
  return channel_count_;
}

uint16_t SumdUnmarshaler::GetChannelValue(uint8_t channel) const {
  if (channel >= channel_count_) {
    return 0;
  }

  return channel_values_[channel];
}

void SumdUnmarshaler::SetState(State state, uint8_t value) {
  if (state == state_) {
    return;
  }

  state_ = state;
  switch (state_) {
    case STATE_READ_VENDOR_ID:
      crc_ = 0;
      break;
    case STATE_READ_HEADER:
      index_ = 0;
      break;
    case STATE_READ_VALUES:
      byte_count_ = 2 * value;  // Need to read two bytes per value.
      break;
    case STATE_READ_CRC:
      byte_count_ = 2;
      crc_start_offset_ = index_;
      break;
  }
}

void SumdUnmarshaler::AddValue(uint8_t value) {
  raw_data_[index_] = value;
  ++index_;
  Crc(value);
}

bool SumdUnmarshaler::CheckCrc() {
  return crc_ == 0;
}

void SumdUnmarshaler::CopyChannelValues() {
  is_fail_safe_ = raw_data_[STATUS_OFFSET] & 0x80;  
  channel_count_ = raw_data_[CHANNEL_COUNT_OFFSET];
  uint8_t index = CHANNEL_DATA_START_OFFSET;
  for (uint8_t i = 0; i < channel_count_; ++i) {
    channel_values_[i] =
        (static_cast<uint16_t>(raw_data_[index]) << 8) + raw_data_[index + 1];
    index += 2;
  }
  has_new_values_ = true;
}

void SumdUnmarshaler::Crc(uint8_t value) {
  crc_ = crc_ ^ (static_cast<uint16_t>(value) << 8);
  for (uint8_t i = 0; i < 8; i++) {
    if (crc_ & 0x8000) {
      crc_ = (crc_ << 1) ^ CRC_POLYNOME;
    } else {
      crc_ <<= 1;
    }
  }
}
