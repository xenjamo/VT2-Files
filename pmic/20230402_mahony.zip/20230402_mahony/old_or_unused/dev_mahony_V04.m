clc, clear variables
%%

% data = readmatrix('putty_09.log');
data = readmatrix('putty_10.log');

time = data(:,10) * 1e-3;
time = time - time(1);
Ts = median(diff(time));
ind_gyro = 1:3;
ind_acc  = 4:6;
ind_mag  = 7:9;
ind_quat = 11:14;
ind_rpy  = 15:17;

figure(1)
plot(diff(time))

figure(2)
tiledlayout_ = tiledlayout(3,1); tiledlayout_.TileSpacing = 'compact';
ax(1) = nexttile;
plot(ax(1), time, data(:,ind_gyro) * 180/pi), grid on, ylabel('Gyro (deg/sec)')
ax(2) = nexttile;
plot(ax(2), time, data(:,ind_acc)), grid on, ylabel('Acc (m/s^2)')
ax(3) = nexttile;
plot(ax(3), time, data(:,ind_mag)), grid on, ylabel('Mag'), xlabel('Time (sec)')
linkaxes(ax, 'x'), clear ax, xlim([0, max(time)])

figure(3)
plot(time, cumtrapz(time, data(:,ind_gyro)) * 180/pi), grid on
ylabel('Gyro Integral (deg)'), xlabel('Time (sec)')

% Kp * (1 + 1/(Tn*s)) = kp + ki <->
% kp = Kp
% ki = Kp / Tn = kp / (1 / (2*pi*wn)) = kp * 2*pi*wn
p = 1;         % pole at p rad/s
kp = 2 * p;
ki = kp^2 / 4;
N = size(data, 1);
quat = eye(4,1);
bias = zeros(3,1);
Eva = [0 0 1].';
quat_ = zeros(N, 4);
bias_ = zeros(N, 3);

% betaflight
for i = 1:N
    g_n = [         2*(quat(2)*quat(4) - quat(1)*quat(3)); ...
                    2*(quat(3)*quat(4) + quat(1)*quat(2)); ...
            quat(1)^2 - quat(2)^2 - quat(3)^2 + quat(4)^2];

    acc_n = data(i, ind_acc).';
    acc_n = acc_n ./ norm(acc_n);
    e = cross(acc_n, g_n);
    
    bias = bias + ki * e * Ts;

    Q = [[-quat(2), -quat(3), -quat(4)]; ...
         [ quat(1), -quat(4),  quat(3)]; ...
         [ quat(4),  quat(1), -quat(2)]; ...
         [-quat(3),  quat(2),  quat(1)]];

    dquat = Ts * 0.5 * Q * ( data(i,ind_gyro).' + bias + kp * e );
    quat = quat + dquat;
    quat = quat ./ norm(quat);

    quat_(i,:) = quat.';
    bias_(i,:) = bias.';
end

% % betaflight
% for i = 1:N
%     CBE = quat2CBE(quat);
%     
%     a = data(i, ind_acc).';
%     a = a ./ norm(a);
%     e = cross(a, CBE(:,3));
%     
%     bias = bias + ki * e * Ts;
% 
%     g = data(i, ind_gyro).' + kp * e + bias;
% 
%     quat = quat + 1/2 * Ts * quat2QprodL( quat ) * [0; g];
%     quat = quat ./ norm(quat);
% 
%     quat_(i,:) = quat.';
%     bias_(i,:) = bias.';
% end

rpy_ = quat2rpy(quat_);

[z_, y_, x_] = quat2angle(quat_, "ZYX");
rpy_matlab = fliplr([z_, y_, x_]);

figure(44)
tiledlayout_ = tiledlayout(3,1); tiledlayout_.TileSpacing = 'compact';
ax(1) = nexttile;
plot(time, wrapToPi(cumtrapz(time, data(:,ind_gyro(1)))) * 180/pi), grid on, hold on
plot(time, wrapToPi(rpy_(:,1)) * 180/pi)
plot(time, wrapToPi(data(:,ind_rpy(1))) * 180/pi)
plot(time, wrapToPi(rpy_matlab(:,1)) * 180/pi), hold off
ylabel('Gyro Integral (deg)'), xlabel('Time (sec)')
ax(2) = nexttile;
plot(time, wrapToPi(cumtrapz(time, data(:,ind_gyro(2)))) * 180/pi), grid on, hold on
plot(time, wrapToPi(rpy_(:,2)) * 180/pi)
plot(time, wrapToPi(data(:,ind_rpy(2))) * 180/pi)
plot(time, wrapToPi(rpy_matlab(:,2)) * 180/pi), hold off
ylabel('Gyro Integral (deg)'), xlabel('Time (sec)')
ax(3) = nexttile;
plot(time, wrapToPi(cumtrapz(time, data(:,ind_gyro(3)))) * 180/pi), grid on, hold on
plot(time, wrapToPi(rpy_(:,3)) * 180/pi)
plot(time, wrapToPi(data(:,ind_rpy(3))) * 180/pi)
plot(time, wrapToPi(rpy_matlab(:,3)) * 180/pi), hold off
ylabel('Gyro Integral (deg)'), xlabel('Time (sec)')
linkaxes(ax, 'x'), clear ax, xlim([0, max(time)])

figure(55)
plot(time, bias_ * 180/pi), grid on
ylabel('Gyro Bias (deg/s)'), xlabel('Time (sec)')

figure(66)
subplot(211)
plot(time, data(:,ind_quat)), grid on
ylabel('Quaternion')
subplot(212)
plot(time, quat_), grid on
ylabel('Quaternion'), xlabel('Time (sec)')
